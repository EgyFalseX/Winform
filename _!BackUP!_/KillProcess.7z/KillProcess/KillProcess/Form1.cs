﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;//for the DllImport function


namespace KillProcess
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    public partial class Form1 : Form
    {

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr FindWindow(string ClassName, string WindowName);
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);
        [DllImport("USER32.DLL")]
        public static extern int SendMessage(IntPtr hwnd, int msg, int character, IntPtr lpsText);
        [DllImport("user32.dll")]
        static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);

        //these are the internal messages used in C++ and in windows
        //they're already defined in some header files in C++ ".h" but because we are in .net environment
        //we need to define them here, you can pass the number to the API function directly, but this is better
        //for understanding
        private const int WM_CLOSE = 0x10;
        private const int WM_QUIT = 0x12;
        private const uint WM_MOUSEMOVE = 0x200;
        public const int WM_PAINT = 0xF;

        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Kills window by window title
        /// </summary>
        /// <param name="WindowTitle">The title of the window you want to kill</param>
        private void KillWindow(string WindowTitle)
        {
            IntPtr hWnd = FindWindow(null, WindowTitle);

            if (hWnd != IntPtr.Zero)
            {
                SendMessage(hWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                //SendMessage(hWnd, WM_QUIT, IntPtr.Zero, IntPtr.Zero);

                //now close it's tray icon
                RefreshTaskbarNotificationArea();
            }
            else
                MessageBox.Show("Can't find window " + "\"" + WindowTitle + "\"");
        }
        /// <summary>
        /// Kills window by process
        /// </summary>
        /// <param name="WindowTitle">The title of the window you want to kill</param>
        private void KillWindow(Process prc)
        {
            IntPtr hWnd = prc.MainWindowHandle;

            if (hWnd != IntPtr.Zero)
            {
                SendMessage(hWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                //SendMessage(hWnd, WM_QUIT, IntPtr.Zero, IntPtr.Zero);

                //now close it's tray icon
                RefreshTaskbarNotificationArea();
            }
            else
                MessageBox.Show("Can't kill process " + "\"" + prc.ProcessName + "\"");
                throw new Exception("Can't kill process " + "\"" + prc.ProcessName + "\"");
        }

        private static IntPtr GetNotifyWindow()
        {
            IntPtr shellTrayHwnd = FindWindow("Shell_TrayWnd", null);
            IntPtr trayNotifyHwnd = FindWindowEx(shellTrayHwnd, IntPtr.Zero, "TrayNotifyWnd", null);
            IntPtr sysPagerHwnd = FindWindowEx(trayNotifyHwnd, IntPtr.Zero, "SysPager", null);
            return FindWindowEx(sysPagerHwnd, IntPtr.Zero, "ToolbarWindow32", null);
        }
        /// <summary>
        /// Refreshes the task bar notification area, removing any unused icons
        /// </summary>
        private static void RefreshTaskbarNotificationArea()
        {
            IntPtr shellTrayHwnd = FindWindow("Shell_TrayWnd", null);
            IntPtr WndNotificationArea = GetNotifyWindow();
            //SendMessage(WndNotificationArea, WM_PAINT, 0, IntPtr.Zero);//repaint the window
            RECT rect;
            GetClientRect(WndNotificationArea, out rect);
            for (int x = 0; x < rect.Right; x += 4)
            {
                for (int y = 0; y < rect.Bottom; y += 4)
                {
                    SendMessage(WndNotificationArea, WM_MOUSEMOVE, 0, (y << 16) + x);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "")
                KillWindow(textBox1.Text);
        }
    }
}
