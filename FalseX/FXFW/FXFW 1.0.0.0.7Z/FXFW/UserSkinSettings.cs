using System;

namespace FXFW
{
    [Serializable]
    public class UserSkinSettings
    {
        public string SkinName;
    }
}
