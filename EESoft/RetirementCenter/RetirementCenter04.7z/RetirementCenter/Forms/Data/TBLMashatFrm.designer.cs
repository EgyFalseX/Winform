﻿namespace RetirementCenter
{
    partial class TBLMashatFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule1 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule2 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule3 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule4 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule5 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule6 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule7 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule8 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule9 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule10 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule11 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule12 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule13 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule14 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            this.groupControlMain = new DevExpress.XtraEditors.GroupControl();
            this.btnDelete = new DevExpress.XtraEditors.SimpleButton();
            this.btnNew = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.LUEEmp = new DevExpress.XtraEditors.GridLookUpEdit();
            this.LSMSDATA = new DevExpress.Data.Linq.LinqServerModeSource();
            this.repositoryItemLookUpEditSyndicateId = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.gridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colMMashatName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSyndicate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSubCommitte = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsarfnumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMashHala = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colyasref = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMMashatNId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.tbMMashatName = new DevExpress.XtraEditors.TextEdit();
            this.dsRetirementCenter = new RetirementCenter.DataSources.dsRetirementCenter();
            this.gcCommands = new DevExpress.XtraEditors.GroupControl();
            this.btnUpdate = new DevExpress.XtraEditors.SimpleButton();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.LUESubCommitteId = new DevExpress.XtraEditors.LookUpEdit();
            this.LSMSCDSubCommitte = new DevExpress.Data.Linq.LinqServerModeSource();
            this.LUESyndicateId = new DevExpress.XtraEditors.LookUpEdit();
            this.LSMSCDSyndicate = new DevExpress.Data.Linq.LinqServerModeSource();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.LUEMashHalaId = new DevExpress.XtraEditors.LookUpEdit();
            this.LSMSCDMashHala = new DevExpress.Data.Linq.LinqServerModeSource();
            this.xtraTabControlMain = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPageMain = new DevExpress.XtraTab.XtraTabPage();
            this.ceEnableEdafat = new DevExpress.XtraEditors.CheckEdit();
            this.pnlEdafat = new DevExpress.XtraEditors.PanelControl();
            this.lueDofatSarfId = new DevExpress.XtraEditors.LookUpEdit();
            this.LSMSTBLDofatSarf = new DevExpress.Data.Linq.LinqServerModeSource();
            this.luesarfTypeId = new DevExpress.XtraEditors.LookUpEdit();
            this.tbestktaa = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.defiledate = new DevExpress.XtraEditors.DateEdit();
            this.tBLMashatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.deWorkeEndDate = new DevExpress.XtraEditors.DateEdit();
            this.ceSarfExpetion = new DevExpress.XtraEditors.CheckEdit();
            this.ceyasref = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.lueEndworkId = new DevExpress.XtraEditors.LookUpEdit();
            this.cDEndworkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsQueries = new RetirementCenter.DataSources.dsQueries();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.tbMMashatNId = new DevExpress.XtraEditors.TextEdit();
            this.tbKideNumber = new DevExpress.XtraEditors.TextEdit();
            this.textEdit2 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.tbsarfnumber = new DevExpress.XtraEditors.TextEdit();
            this.xtraTabPageNoSarf = new DevExpress.XtraTab.XtraTabPage();
            this.gridControlTBLNoSarfDetels = new DevExpress.XtraGrid.GridControl();
            this.LSMSTBLNoSarfDetels = new DevExpress.Data.Linq.LinqServerModeSource();
            this.gridViewTBLNoSarfDetels = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.coldatehala = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colyasref1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.coldatein1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.coluserin1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.xtraTabPagePrivateSarf = new DevExpress.XtraTab.XtraTabPage();
            this.cemcompletesarf = new DevExpress.XtraEditors.CheckEdit();
            this.pnlPrivateSarf = new DevExpress.XtraEditors.PanelControl();
            this.tbmelrasm = new DevExpress.XtraEditors.TextEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.tbmmony = new DevExpress.XtraEditors.TextEdit();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.tbmestktaat = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.tbmeshtrakat = new DevExpress.XtraEditors.TextEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPageRemarks = new DevExpress.XtraTab.XtraTabPage();
            this.gridControlRemarks = new DevExpress.XtraGrid.GridControl();
            this.tBLMRemarksBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewRemarks = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colmewmark = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSave = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.coldatein = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.coluserin = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEditeRemarkuserin = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.xtraTabPageSyndicateTransfer = new DevExpress.XtraTab.XtraTabPage();
            this.gridControlSyndicateTransfer = new DevExpress.XtraGrid.GridControl();
            this.tBLSyndicateTransferBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewSyndicateTransfer = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colNewSyndicateId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditSyndicateId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.LSMSCDSyndicateTransfer = new DevExpress.Data.Linq.LinqServerModeSource();
            this.repositoryItemGridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colSyndicate1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNewSubCommitteId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditSubCommitteId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.LSMSCDSubCommitteTransfer = new DevExpress.Data.Linq.LinqServerModeSource();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colSubCommitte1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTransferrem = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEditTransferrem = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.colOldSyndicateId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colOldSubCommitteId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTransferDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditTransferSave = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemMemoEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.xtraTabPageWarasa = new DevExpress.XtraTab.XtraTabPage();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnAddTBLWarasa = new DevExpress.XtraEditors.SimpleButton();
            this.gridControlTBLWarasa = new DevExpress.XtraGrid.GridControl();
            this.tBLWarasaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewTBLWarasa = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colpersonName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWarasaType1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.LSMSCDWarasaType = new DevExpress.Data.Linq.LinqServerModeSource();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colpersonNID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colpersonbirth = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEditWarasaDMY = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.colpersonmobile = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colpersonAddres = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.colyasref2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colSyndicateId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditWarasaSyndicateId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colSyndicate2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSubCommitteId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditWarasaSubCommitteId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView5 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colSubCommitte2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditWarasaQuickSave = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditWarasaEdit = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditWarasaDel = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.colRealName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditWarasauserin = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditWarasaSarf = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditWarasaRemark = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.colresponsiblesarf = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colresponsiblesarfId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditresponsiblesarfId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.LSMSTBLWarasa = new DevExpress.Data.Linq.LinqServerModeSource();
            this.gridView6 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colpersonName1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPageChangeToWarasa = new DevExpress.XtraTab.XtraTabPage();
            this.LUEChangeHala = new DevExpress.XtraEditors.LookUpEdit();
            this.btnChangeHala = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPageReSarf = new DevExpress.XtraTab.XtraTabPage();
            this.gridControlResarf = new DevExpress.XtraGrid.GridControl();
            this.tBLReSarfBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewResarf = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colDofatSarfId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditDofatSarfId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView7 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colDofatSarf = new DevExpress.XtraGrid.Columns.GridColumn();
            this.coldatefrom = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEditResarfDMY = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.coldateto = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colreestktaa = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEditResarff2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colremarks = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditResarfSave = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditResarfDel = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemMemoEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.LSMSCDsarfType = new DevExpress.Data.Linq.LinqServerModeSource();
            this.tBLEdafatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dxValidationProviderMain = new DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider(this.components);
            this.tblMashatTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLMashatTableAdapter();
            this.tBLMashatTablebbindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblNoSarfDetelsTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLNoSarfDetelsTableAdapter();
            this.tblNoSarfDetelsTablebindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBLMRemarksTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLMRemarksTableAdapter();
            this.usersTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.UsersTableAdapter();
            this.cDEndworkTableAdapter = new RetirementCenter.DataSources.dsQueriesTableAdapters.CDEndworkTableAdapter();
            this.tblMashatLOGTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLMashatLOGTableAdapter();
            this.tBLEdafatTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLEdafatTableAdapter();
            this.dxValidationProviderEdafat = new DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider(this.components);
            this.tBLSyndicateTransferTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLSyndicateTransferTableAdapter();
            this.tBLWarasaTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLWarasaTableAdapter();
            this.tblNoSarfWarsaTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLNoSarfWarsaTableAdapter();
            this.tblEdafatWarsaTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLEdafatWarsaTableAdapter();
            this.tBLEdafatWarsaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.colWarasaType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tBLReSarfTableAdapter = new RetirementCenter.DataSources.dsRetirementCenterTableAdapters.TBLReSarfTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlMain)).BeginInit();
            this.groupControlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LUEEmp.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSDATA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditSyndicateId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbMMashatName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsRetirementCenter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcCommands)).BeginInit();
            this.gcCommands.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LUESubCommitteId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSubCommitte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LUESyndicateId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSyndicate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LUEMashHalaId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDMashHala)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlMain)).BeginInit();
            this.xtraTabControlMain.SuspendLayout();
            this.xtraTabPageMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ceEnableEdafat.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlEdafat)).BeginInit();
            this.pnlEdafat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lueDofatSarfId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSTBLDofatSarf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luesarfTypeId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbestktaa.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.defiledate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.defiledate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMashatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deWorkeEndDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deWorkeEndDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceSarfExpetion.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceyasref.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueEndworkId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDEndworkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsQueries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbMMashatNId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbKideNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbsarfnumber.Properties)).BeginInit();
            this.xtraTabPageNoSarf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlTBLNoSarfDetels)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSTBLNoSarfDetels)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTBLNoSarfDetels)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            this.xtraTabPagePrivateSarf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cemcompletesarf.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlPrivateSarf)).BeginInit();
            this.pnlPrivateSarf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbmelrasm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmmony.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmestktaat.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmeshtrakat.Properties)).BeginInit();
            this.xtraTabPageRemarks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlRemarks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMRemarksBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewRemarks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditeRemarkuserin)).BeginInit();
            this.xtraTabPageSyndicateTransfer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlSyndicateTransfer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLSyndicateTransferBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSyndicateTransfer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSyndicateId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSyndicateTransfer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSubCommitteId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSubCommitteTransfer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEditTransferrem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit4.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditTransferSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).BeginInit();
            this.xtraTabPageWarasa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlTBLWarasa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLWarasaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTBLWarasa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasaWarasaTypeId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDWarasaType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditWarasaDMY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditWarasaDMY.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasaSyndicateId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasaSubCommitteId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaQuickSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaDel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit5.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasauserin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaSarf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaRemark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditresponsiblesarfId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSTBLWarasa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).BeginInit();
            this.xtraTabPageChangeToWarasa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LUEChangeHala.Properties)).BeginInit();
            this.xtraTabPageReSarf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlResarf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLReSarfBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewResarf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditDofatSarfId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditResarfDMY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditResarfDMY.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEditResarff2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit6.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditResarfSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditResarfDel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDsarfType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLEdafatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProviderMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMashatTablebbindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblNoSarfDetelsTablebindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProviderEdafat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLEdafatWarsaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControlMain
            // 
            this.groupControlMain.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupControlMain.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupControlMain.AppearanceCaption.Options.UseFont = true;
            this.groupControlMain.AppearanceCaption.Options.UseTextOptions = true;
            this.groupControlMain.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupControlMain.Controls.Add(this.btnDelete);
            this.groupControlMain.Controls.Add(this.btnNew);
            this.groupControlMain.Controls.Add(this.labelControl1);
            this.groupControlMain.Controls.Add(this.LUEEmp);
            this.groupControlMain.Location = new System.Drawing.Point(1, 6);
            this.groupControlMain.Margin = new System.Windows.Forms.Padding(0);
            this.groupControlMain.Name = "groupControlMain";
            this.groupControlMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupControlMain.Size = new System.Drawing.Size(887, 111);
            this.groupControlMain.TabIndex = 0;
            this.groupControlMain.Text = "الاعضاء";
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnDelete.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnDelete.Appearance.Options.UseFont = true;
            this.btnDelete.Enabled = false;
            this.btnDelete.Image = global::RetirementCenter.Properties.Resources.DeleteObject;
            this.btnDelete.Location = new System.Drawing.Point(223, 35);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(0);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(77, 40);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Tag = "delete";
            this.btnDelete.Text = "حذف";
            this.btnDelete.ToolTip = "اضعط هنا لحذف المختار";
            this.btnDelete.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.btnDelete.ToolTipTitle = "حذف F8";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnNew
            // 
            this.btnNew.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnNew.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnNew.Appearance.Options.UseFont = true;
            this.btnNew.Location = new System.Drawing.Point(308, 52);
            this.btnNew.Margin = new System.Windows.Forms.Padding(0);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(231, 32);
            this.btnNew.TabIndex = 1;
            this.btnNew.Tag = "new";
            this.btnNew.Text = "اضافة جديد";
            this.btnNew.ToolTip = "اضعط هنا لبدء اضافة جديد";
            this.btnNew.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.btnNew.ToolTipTitle = "اضافة F5";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl1.Location = new System.Drawing.Point(547, 31);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(40, 17);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "الاعضاء";
            // 
            // LUEEmp
            // 
            this.LUEEmp.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LUEEmp.Location = new System.Drawing.Point(307, 30);
            this.LUEEmp.Margin = new System.Windows.Forms.Padding(0);
            this.LUEEmp.Name = "LUEEmp";
            this.LUEEmp.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.LUEEmp.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LUEEmp.Properties.DataSource = this.LSMSDATA;
            this.LUEEmp.Properties.DisplayMember = "MMashatName";
            this.LUEEmp.Properties.NullText = "";
            this.LUEEmp.Properties.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEditSyndicateId});
            this.LUEEmp.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.LUEEmp.Properties.ValueMember = "MMashatId";
            this.LUEEmp.Properties.View = this.gridLookUpEdit1View;
            this.LUEEmp.Size = new System.Drawing.Size(231, 20);
            this.LUEEmp.TabIndex = 0;
            this.LUEEmp.EditValueChanged += new System.EventHandler(this.LUEEmp_EditValueChanged);
            // 
            // LSMSDATA
            // 
            this.LSMSDATA.ElementType = typeof(RetirementCenter.DataSources.Linq.vTBLMashat);
            this.LSMSDATA.KeyExpression = "MMashatId";
            // 
            // repositoryItemLookUpEditSyndicateId
            // 
            this.repositoryItemLookUpEditSyndicateId.AutoHeight = false;
            this.repositoryItemLookUpEditSyndicateId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEditSyndicateId.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Syndicate", "الفرعية", 20, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.repositoryItemLookUpEditSyndicateId.DisplayMember = "Syndicate";
            this.repositoryItemLookUpEditSyndicateId.Name = "repositoryItemLookUpEditSyndicateId";
            this.repositoryItemLookUpEditSyndicateId.NullText = "";
            this.repositoryItemLookUpEditSyndicateId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemLookUpEditSyndicateId.ValueMember = "SyndicateId";
            // 
            // gridLookUpEdit1View
            // 
            this.gridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colMMashatName,
            this.colSyndicate,
            this.colSubCommitte,
            this.colsarfnumber,
            this.colMashHala,
            this.colyasref,
            this.colMMashatNId});
            this.gridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridLookUpEdit1View.Name = "gridLookUpEdit1View";
            this.gridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridLookUpEdit1View.OptionsView.ColumnAutoWidth = false;
            this.gridLookUpEdit1View.OptionsView.ShowAutoFilterRow = true;
            this.gridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // colMMashatName
            // 
            this.colMMashatName.AppearanceCell.Options.UseTextOptions = true;
            this.colMMashatName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMMashatName.AppearanceHeader.Options.UseTextOptions = true;
            this.colMMashatName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMMashatName.Caption = "الاسم";
            this.colMMashatName.FieldName = "MMashatName";
            this.colMMashatName.Name = "colMMashatName";
            this.colMMashatName.Visible = true;
            this.colMMashatName.VisibleIndex = 0;
            // 
            // colSyndicate
            // 
            this.colSyndicate.AppearanceCell.Options.UseTextOptions = true;
            this.colSyndicate.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicate.AppearanceHeader.Options.UseTextOptions = true;
            this.colSyndicate.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicate.Caption = "الفرعية";
            this.colSyndicate.FieldName = "Syndicate";
            this.colSyndicate.Name = "colSyndicate";
            this.colSyndicate.Visible = true;
            this.colSyndicate.VisibleIndex = 1;
            // 
            // colSubCommitte
            // 
            this.colSubCommitte.AppearanceCell.Options.UseTextOptions = true;
            this.colSubCommitte.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitte.AppearanceHeader.Options.UseTextOptions = true;
            this.colSubCommitte.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitte.Caption = "اللجنة";
            this.colSubCommitte.FieldName = "SubCommitte";
            this.colSubCommitte.Name = "colSubCommitte";
            this.colSubCommitte.Visible = true;
            this.colSubCommitte.VisibleIndex = 2;
            // 
            // colsarfnumber
            // 
            this.colsarfnumber.AppearanceCell.Options.UseTextOptions = true;
            this.colsarfnumber.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colsarfnumber.AppearanceHeader.Options.UseTextOptions = true;
            this.colsarfnumber.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colsarfnumber.Caption = "رقم الصرف";
            this.colsarfnumber.FieldName = "sarfnumber";
            this.colsarfnumber.Name = "colsarfnumber";
            this.colsarfnumber.Visible = true;
            this.colsarfnumber.VisibleIndex = 3;
            // 
            // colMashHala
            // 
            this.colMashHala.AppearanceCell.Options.UseTextOptions = true;
            this.colMashHala.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMashHala.AppearanceHeader.Options.UseTextOptions = true;
            this.colMashHala.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMashHala.Caption = "نوع البيان";
            this.colMashHala.FieldName = "MashHala";
            this.colMashHala.Name = "colMashHala";
            this.colMashHala.Visible = true;
            this.colMashHala.VisibleIndex = 4;
            // 
            // colyasref
            // 
            this.colyasref.AppearanceCell.Options.UseTextOptions = true;
            this.colyasref.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colyasref.AppearanceHeader.Options.UseTextOptions = true;
            this.colyasref.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colyasref.Caption = "يصرف";
            this.colyasref.FieldName = "yasref";
            this.colyasref.Name = "colyasref";
            this.colyasref.Visible = true;
            this.colyasref.VisibleIndex = 5;
            // 
            // colMMashatNId
            // 
            this.colMMashatNId.AppearanceCell.Options.UseTextOptions = true;
            this.colMMashatNId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMMashatNId.AppearanceHeader.Options.UseTextOptions = true;
            this.colMMashatNId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMMashatNId.Caption = "الرقم القومي";
            this.colMMashatNId.FieldName = "MMashatNId";
            this.colMMashatNId.Name = "colMMashatNId";
            this.colMMashatNId.Visible = true;
            this.colMMashatNId.VisibleIndex = 6;
            // 
            // labelControl2
            // 
            this.labelControl2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl2.Location = new System.Drawing.Point(817, 5);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(36, 17);
            this.labelControl2.TabIndex = 0;
            this.labelControl2.Text = "الاسم";
            // 
            // tbMMashatName
            // 
            this.tbMMashatName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMMashatName.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.MMashatName", true));
            this.tbMMashatName.EnterMoveNextControl = true;
            this.tbMMashatName.Location = new System.Drawing.Point(296, 8);
            this.tbMMashatName.Margin = new System.Windows.Forms.Padding(0);
            this.tbMMashatName.Name = "tbMMashatName";
            this.tbMMashatName.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.tbMMashatName.Properties.Appearance.Options.UseFont = true;
            this.tbMMashatName.Size = new System.Drawing.Size(446, 22);
            this.tbMMashatName.TabIndex = 0;
            conditionValidationRule1.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule1.ErrorText = "يجب ادخال الاسم";
            conditionValidationRule1.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.tbMMashatName, conditionValidationRule1);
            this.tbMMashatName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // dsRetirementCenter
            // 
            this.dsRetirementCenter.DataSetName = "dsRetirementCenter";
            this.dsRetirementCenter.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gcCommands
            // 
            this.gcCommands.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gcCommands.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gcCommands.AppearanceCaption.ForeColor = System.Drawing.Color.Red;
            this.gcCommands.AppearanceCaption.Options.UseFont = true;
            this.gcCommands.AppearanceCaption.Options.UseForeColor = true;
            this.gcCommands.AppearanceCaption.Options.UseTextOptions = true;
            this.gcCommands.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gcCommands.Controls.Add(this.btnUpdate);
            this.gcCommands.Controls.Add(this.btnSave);
            this.gcCommands.Enabled = false;
            this.gcCommands.Location = new System.Drawing.Point(1, 397);
            this.gcCommands.Margin = new System.Windows.Forms.Padding(0);
            this.gcCommands.Name = "gcCommands";
            this.gcCommands.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gcCommands.Size = new System.Drawing.Size(880, 60);
            this.gcCommands.TabIndex = 2;
            this.gcCommands.Text = "F5 جديد - F6 حفظ - F8 حذف - F10 تعديل";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnUpdate.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnUpdate.Appearance.Options.UseFont = true;
            this.btnUpdate.Enabled = false;
            this.btnUpdate.Location = new System.Drawing.Point(424, 23);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(0);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(231, 32);
            this.btnUpdate.TabIndex = 0;
            this.btnUpdate.Tag = "update";
            this.btnUpdate.Text = "حفظ كتعديل";
            this.btnUpdate.ToolTip = "اضعط هنا لحفظ التعديلات";
            this.btnUpdate.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.btnUpdate.ToolTipTitle = "تعديل F10";
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSave.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnSave.Appearance.Options.UseFont = true;
            this.btnSave.Location = new System.Drawing.Point(186, 23);
            this.btnSave.Margin = new System.Windows.Forms.Padding(0);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(231, 32);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "save";
            this.btnSave.Text = "حفظ جديد";
            this.btnSave.ToolTip = "اضعط هنا لحفظ جديد";
            this.btnSave.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.btnSave.ToolTipTitle = "حفظ جديد F6";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // labelControl21
            // 
            this.labelControl21.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl21.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl21.Location = new System.Drawing.Point(488, 40);
            this.labelControl21.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(79, 17);
            this.labelControl21.TabIndex = 27;
            this.labelControl21.Text = "اللجنة النقابية";
            // 
            // labelControl11
            // 
            this.labelControl11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl11.Location = new System.Drawing.Point(771, 40);
            this.labelControl11.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(80, 17);
            this.labelControl11.TabIndex = 28;
            this.labelControl11.Text = "النقابة الفرعية";
            // 
            // LUESubCommitteId
            // 
            this.LUESubCommitteId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LUESubCommitteId.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.SubCommitteId", true));
            this.LUESubCommitteId.EnterMoveNextControl = true;
            this.LUESubCommitteId.Location = new System.Drawing.Point(296, 39);
            this.LUESubCommitteId.Margin = new System.Windows.Forms.Padding(0);
            this.LUESubCommitteId.Name = "LUESubCommitteId";
            this.LUESubCommitteId.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.LUESubCommitteId.Properties.Appearance.Options.UseFont = true;
            this.LUESubCommitteId.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LUESubCommitteId.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SubCommitte", "الاسم", 40, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.LUESubCommitteId.Properties.DataSource = this.LSMSCDSubCommitte;
            this.LUESubCommitteId.Properties.DisplayMember = "SubCommitte";
            this.LUESubCommitteId.Properties.NullText = "";
            this.LUESubCommitteId.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.LUESubCommitteId.Properties.ValueMember = "SubCommitteId";
            this.LUESubCommitteId.Size = new System.Drawing.Size(162, 22);
            this.LUESubCommitteId.TabIndex = 2;
            conditionValidationRule2.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule2.ErrorText = "يجب ادخال اللجنة النقابية";
            conditionValidationRule2.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.LUESubCommitteId, conditionValidationRule2);
            this.LUESubCommitteId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // LSMSCDSubCommitte
            // 
            this.LSMSCDSubCommitte.ElementType = typeof(RetirementCenter.DataSources.Linq.CDSubCommitte);
            this.LSMSCDSubCommitte.KeyExpression = "[SubCommitteId]";
            // 
            // LUESyndicateId
            // 
            this.LUESyndicateId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LUESyndicateId.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.SyndicateId", true));
            this.LUESyndicateId.EnterMoveNextControl = true;
            this.LUESyndicateId.Location = new System.Drawing.Point(581, 41);
            this.LUESyndicateId.Margin = new System.Windows.Forms.Padding(0);
            this.LUESyndicateId.Name = "LUESyndicateId";
            this.LUESyndicateId.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.LUESyndicateId.Properties.Appearance.Options.UseFont = true;
            this.LUESyndicateId.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LUESyndicateId.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Syndicate", "الاسم", 40, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.LUESyndicateId.Properties.DataSource = this.LSMSCDSyndicate;
            this.LUESyndicateId.Properties.DisplayMember = "Syndicate";
            this.LUESyndicateId.Properties.NullText = "";
            this.LUESyndicateId.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.LUESyndicateId.Properties.ValueMember = "SyndicateId";
            this.LUESyndicateId.Size = new System.Drawing.Size(161, 22);
            this.LUESyndicateId.TabIndex = 1;
            conditionValidationRule3.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule3.ErrorText = "يجب ادخال النقابة الفرعية";
            conditionValidationRule3.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.LUESyndicateId, conditionValidationRule3);
            this.LUESyndicateId.EditValueChanged += new System.EventHandler(this.LUESyndicateId_EditValueChanged);
            this.LUESyndicateId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // LSMSCDSyndicate
            // 
            this.LSMSCDSyndicate.ElementType = typeof(RetirementCenter.DataSources.Linq.CDSyndicate);
            this.LSMSCDSyndicate.KeyExpression = "[SyndicateId]";
            // 
            // labelControl9
            // 
            this.labelControl9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl9.Location = new System.Drawing.Point(801, 75);
            this.labelControl9.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(52, 17);
            this.labelControl9.TabIndex = 31;
            this.labelControl9.Text = "نوع البيان";
            // 
            // LUEMashHalaId
            // 
            this.LUEMashHalaId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LUEMashHalaId.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.MashHalaId", true));
            this.LUEMashHalaId.EnterMoveNextControl = true;
            this.LUEMashHalaId.Location = new System.Drawing.Point(581, 76);
            this.LUEMashHalaId.Margin = new System.Windows.Forms.Padding(0);
            this.LUEMashHalaId.Name = "LUEMashHalaId";
            this.LUEMashHalaId.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.LUEMashHalaId.Properties.Appearance.Options.UseFont = true;
            this.LUEMashHalaId.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LUEMashHalaId.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MashHala", "الاسم", 40, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.LUEMashHalaId.Properties.DataSource = this.LSMSCDMashHala;
            this.LUEMashHalaId.Properties.DisplayMember = "MashHala";
            this.LUEMashHalaId.Properties.NullText = "";
            this.LUEMashHalaId.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.LUEMashHalaId.Properties.ValueMember = "MashHalaId";
            this.LUEMashHalaId.Size = new System.Drawing.Size(161, 22);
            this.LUEMashHalaId.TabIndex = 3;
            conditionValidationRule4.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule4.ErrorText = "يجب ادخال الوظيفه";
            conditionValidationRule4.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.LUEMashHalaId, conditionValidationRule4);
            this.LUEMashHalaId.EditValueChanged += new System.EventHandler(this.LUEMashHalaId_EditValueChanged);
            this.LUEMashHalaId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // LSMSCDMashHala
            // 
            this.LSMSCDMashHala.ElementType = typeof(RetirementCenter.DataSources.Linq.CDMashHala);
            this.LSMSCDMashHala.KeyExpression = "[MashHalaId]";
            // 
            // xtraTabControlMain
            // 
            this.xtraTabControlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xtraTabControlMain.Enabled = false;
            this.xtraTabControlMain.HeaderAutoFill = DevExpress.Utils.DefaultBoolean.True;
            this.xtraTabControlMain.Location = new System.Drawing.Point(1, 120);
            this.xtraTabControlMain.Name = "xtraTabControlMain";
            this.xtraTabControlMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.xtraTabControlMain.SelectedTabPage = this.xtraTabPageMain;
            this.xtraTabControlMain.Size = new System.Drawing.Size(880, 274);
            this.xtraTabControlMain.TabIndex = 1;
            this.xtraTabControlMain.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPageMain,
            this.xtraTabPageNoSarf,
            this.xtraTabPagePrivateSarf,
            this.xtraTabPageRemarks,
            this.xtraTabPageSyndicateTransfer,
            this.xtraTabPageWarasa,
            this.xtraTabPageChangeToWarasa,
            this.xtraTabPageReSarf});
            this.xtraTabControlMain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // xtraTabPageMain
            // 
            this.xtraTabPageMain.AutoScroll = true;
            this.xtraTabPageMain.Controls.Add(this.ceEnableEdafat);
            this.xtraTabPageMain.Controls.Add(this.pnlEdafat);
            this.xtraTabPageMain.Controls.Add(this.defiledate);
            this.xtraTabPageMain.Controls.Add(this.deWorkeEndDate);
            this.xtraTabPageMain.Controls.Add(this.ceSarfExpetion);
            this.xtraTabPageMain.Controls.Add(this.ceyasref);
            this.xtraTabPageMain.Controls.Add(this.tbMMashatName);
            this.xtraTabPageMain.Controls.Add(this.LUESubCommitteId);
            this.xtraTabPageMain.Controls.Add(this.labelControl7);
            this.xtraTabPageMain.Controls.Add(this.labelControl13);
            this.xtraTabPageMain.Controls.Add(this.labelControl5);
            this.xtraTabPageMain.Controls.Add(this.labelControl4);
            this.xtraTabPageMain.Controls.Add(this.labelControl15);
            this.xtraTabPageMain.Controls.Add(this.labelControl14);
            this.xtraTabPageMain.Controls.Add(this.labelControl3);
            this.xtraTabPageMain.Controls.Add(this.lueEndworkId);
            this.xtraTabPageMain.Controls.Add(this.LUEMashHalaId);
            this.xtraTabPageMain.Controls.Add(this.labelControl11);
            this.xtraTabPageMain.Controls.Add(this.labelControl6);
            this.xtraTabPageMain.Controls.Add(this.LUESyndicateId);
            this.xtraTabPageMain.Controls.Add(this.labelControl9);
            this.xtraTabPageMain.Controls.Add(this.labelControl21);
            this.xtraTabPageMain.Controls.Add(this.labelControl2);
            this.xtraTabPageMain.Controls.Add(this.tbMMashatNId);
            this.xtraTabPageMain.Controls.Add(this.tbKideNumber);
            this.xtraTabPageMain.Controls.Add(this.textEdit2);
            this.xtraTabPageMain.Controls.Add(this.textEdit1);
            this.xtraTabPageMain.Controls.Add(this.tbsarfnumber);
            this.xtraTabPageMain.Font = new System.Drawing.Font("Tahoma", 10F);
            this.xtraTabPageMain.Name = "xtraTabPageMain";
            this.xtraTabPageMain.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPageMain.Text = "بيانات اساسية";
            // 
            // ceEnableEdafat
            // 
            this.ceEnableEdafat.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ceEnableEdafat.EnterMoveNextControl = true;
            this.ceEnableEdafat.Location = new System.Drawing.Point(151, 101);
            this.ceEnableEdafat.Name = "ceEnableEdafat";
            this.ceEnableEdafat.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.ceEnableEdafat.Properties.Appearance.Options.UseBackColor = true;
            this.ceEnableEdafat.Properties.AutoWidth = true;
            this.ceEnableEdafat.Properties.Caption = "اضغط لتفعيل الاضافات";
            this.ceEnableEdafat.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ceEnableEdafat.Size = new System.Drawing.Size(125, 19);
            this.ceEnableEdafat.TabIndex = 14;
            this.ceEnableEdafat.CheckedChanged += new System.EventHandler(this.ceEnableEdafat_CheckedChanged);
            // 
            // pnlEdafat
            // 
            this.pnlEdafat.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlEdafat.Controls.Add(this.lueDofatSarfId);
            this.pnlEdafat.Controls.Add(this.luesarfTypeId);
            this.pnlEdafat.Controls.Add(this.tbestktaa);
            this.pnlEdafat.Controls.Add(this.labelControl10);
            this.pnlEdafat.Controls.Add(this.labelControl12);
            this.pnlEdafat.Controls.Add(this.labelControl8);
            this.pnlEdafat.Enabled = false;
            this.pnlEdafat.Location = new System.Drawing.Point(10, 98);
            this.pnlEdafat.Name = "pnlEdafat";
            this.pnlEdafat.Size = new System.Drawing.Size(271, 143);
            this.pnlEdafat.TabIndex = 15;
            // 
            // lueDofatSarfId
            // 
            this.lueDofatSarfId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lueDofatSarfId.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLEdafat.DofatSarfId", true));
            this.lueDofatSarfId.EnterMoveNextControl = true;
            this.lueDofatSarfId.Location = new System.Drawing.Point(5, 36);
            this.lueDofatSarfId.Margin = new System.Windows.Forms.Padding(0);
            this.lueDofatSarfId.Name = "lueDofatSarfId";
            this.lueDofatSarfId.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.lueDofatSarfId.Properties.Appearance.Options.UseFont = true;
            this.lueDofatSarfId.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lueDofatSarfId.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("DofatSarf", "الاسم", 40, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.lueDofatSarfId.Properties.DataSource = this.LSMSTBLDofatSarf;
            this.lueDofatSarfId.Properties.DisplayMember = "DofatSarf";
            this.lueDofatSarfId.Properties.NullText = "";
            this.lueDofatSarfId.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lueDofatSarfId.Properties.ValueMember = "DofatSarfId";
            this.lueDofatSarfId.Size = new System.Drawing.Size(162, 22);
            this.lueDofatSarfId.TabIndex = 0;
            conditionValidationRule5.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule5.ErrorText = "يجب ادخال دفعة الصرف";
            conditionValidationRule5.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderEdafat.SetValidationRule(this.lueDofatSarfId, conditionValidationRule5);
            // 
            // LSMSTBLDofatSarf
            // 
            this.LSMSTBLDofatSarf.ElementType = typeof(RetirementCenter.DataSources.Linq.TBLDofatSarf);
            this.LSMSTBLDofatSarf.KeyExpression = "[DofatSarfId]";
            // 
            // luesarfTypeId
            // 
            this.luesarfTypeId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.luesarfTypeId.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLEdafat.sarfTypeId", true));
            this.luesarfTypeId.EnterMoveNextControl = true;
            this.luesarfTypeId.Location = new System.Drawing.Point(5, 72);
            this.luesarfTypeId.Margin = new System.Windows.Forms.Padding(0);
            this.luesarfTypeId.Name = "luesarfTypeId";
            this.luesarfTypeId.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.luesarfTypeId.Properties.Appearance.Options.UseFont = true;
            this.luesarfTypeId.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.luesarfTypeId.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MashHala", "الاسم", 40, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.luesarfTypeId.Properties.DataSource = this.LSMSCDMashHala;
            this.luesarfTypeId.Properties.DisplayMember = "MashHala";
            this.luesarfTypeId.Properties.NullText = "";
            this.luesarfTypeId.Properties.ReadOnly = true;
            this.luesarfTypeId.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.luesarfTypeId.Properties.ValueMember = "MashHalaId";
            this.luesarfTypeId.Size = new System.Drawing.Size(162, 22);
            this.luesarfTypeId.TabIndex = 1;
            conditionValidationRule6.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule6.ErrorText = "يجب ادخال فئة الصرف";
            conditionValidationRule6.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderEdafat.SetValidationRule(this.luesarfTypeId, conditionValidationRule6);
            // 
            // tbestktaa
            // 
            this.tbestktaa.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbestktaa.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLEdafat.estktaa", true));
            this.tbestktaa.EnterMoveNextControl = true;
            this.tbestktaa.Location = new System.Drawing.Point(5, 108);
            this.tbestktaa.Margin = new System.Windows.Forms.Padding(0);
            this.tbestktaa.Name = "tbestktaa";
            this.tbestktaa.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.tbestktaa.Properties.Appearance.Options.UseFont = true;
            this.tbestktaa.Properties.Mask.EditMask = "f2";
            this.tbestktaa.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.tbestktaa.Size = new System.Drawing.Size(162, 22);
            this.tbestktaa.TabIndex = 2;
            conditionValidationRule7.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule7.ErrorText = "يجب ادخال الاستقطاع";
            conditionValidationRule7.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderEdafat.SetValidationRule(this.tbestktaa, conditionValidationRule7);
            // 
            // labelControl10
            // 
            this.labelControl10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl10.Location = new System.Drawing.Point(188, 37);
            this.labelControl10.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(68, 17);
            this.labelControl10.TabIndex = 38;
            this.labelControl10.Text = "دفعة الصرف";
            // 
            // labelControl12
            // 
            this.labelControl12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl12.Location = new System.Drawing.Point(197, 73);
            this.labelControl12.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(59, 17);
            this.labelControl12.TabIndex = 38;
            this.labelControl12.Text = "فئة الصرف";
            // 
            // labelControl8
            // 
            this.labelControl8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl8.Location = new System.Drawing.Point(196, 109);
            this.labelControl8.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(60, 17);
            this.labelControl8.TabIndex = 39;
            this.labelControl8.Text = "الاستقطاع";
            // 
            // defiledate
            // 
            this.defiledate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.defiledate.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tBLMashatBindingSource, "filedate", true));
            this.defiledate.EditValue = null;
            this.defiledate.EnterMoveNextControl = true;
            this.defiledate.Location = new System.Drawing.Point(287, 180);
            this.defiledate.Name = "defiledate";
            this.defiledate.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.defiledate.Properties.Appearance.Options.UseFont = true;
            this.defiledate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.defiledate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.defiledate.Size = new System.Drawing.Size(162, 22);
            this.defiledate.TabIndex = 10;
            conditionValidationRule8.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule8.ErrorText = "يجب ادخال تاريخ ورود الملف";
            conditionValidationRule8.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.defiledate, conditionValidationRule8);
            // 
            // tBLMashatBindingSource
            // 
            this.tBLMashatBindingSource.DataMember = "TBLMashat";
            this.tBLMashatBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // deWorkeEndDate
            // 
            this.deWorkeEndDate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.deWorkeEndDate.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.WorkeEndDate", true));
            this.deWorkeEndDate.EditValue = null;
            this.deWorkeEndDate.EnterMoveNextControl = true;
            this.deWorkeEndDate.Location = new System.Drawing.Point(287, 143);
            this.deWorkeEndDate.Name = "deWorkeEndDate";
            this.deWorkeEndDate.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.deWorkeEndDate.Properties.Appearance.Options.UseFont = true;
            this.deWorkeEndDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deWorkeEndDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deWorkeEndDate.Size = new System.Drawing.Size(162, 22);
            this.deWorkeEndDate.TabIndex = 8;
            conditionValidationRule9.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule9.ErrorText = "يجب ادخال تاريخ نهاية الخدمة";
            conditionValidationRule9.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.deWorkeEndDate, conditionValidationRule9);
            // 
            // ceSarfExpetion
            // 
            this.ceSarfExpetion.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ceSarfExpetion.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.SarfExpetion", true));
            this.ceSarfExpetion.EnterMoveNextControl = true;
            this.ceSarfExpetion.Location = new System.Drawing.Point(186, 37);
            this.ceSarfExpetion.Name = "ceSarfExpetion";
            this.ceSarfExpetion.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.ceSarfExpetion.Properties.Appearance.Options.UseFont = true;
            this.ceSarfExpetion.Properties.AutoWidth = true;
            this.ceSarfExpetion.Properties.Caption = "اسـتـثـنـاء";
            this.ceSarfExpetion.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ceSarfExpetion.Size = new System.Drawing.Size(88, 24);
            this.ceSarfExpetion.TabIndex = 13;
            // 
            // ceyasref
            // 
            this.ceyasref.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ceyasref.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.yasref", true));
            this.ceyasref.EnterMoveNextControl = true;
            this.ceyasref.Location = new System.Drawing.Point(393, 106);
            this.ceyasref.Name = "ceyasref";
            this.ceyasref.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.ceyasref.Properties.Appearance.Options.UseFont = true;
            this.ceyasref.Properties.AutoWidth = true;
            this.ceyasref.Properties.Caption = "يصرف ";
            this.ceyasref.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ceyasref.Size = new System.Drawing.Size(65, 24);
            this.ceyasref.TabIndex = 6;
            this.ceyasref.CheckedChanged += new System.EventHandler(this.ceyasref_CheckedChanged);
            // 
            // labelControl7
            // 
            this.labelControl7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl7.Location = new System.Drawing.Point(474, 183);
            this.labelControl7.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(93, 17);
            this.labelControl7.TabIndex = 35;
            this.labelControl7.Text = "تاريخ ورود الملف";
            // 
            // labelControl13
            // 
            this.labelControl13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl13.Location = new System.Drawing.Point(779, 110);
            this.labelControl13.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(74, 17);
            this.labelControl13.TabIndex = 35;
            this.labelControl13.Text = "الرقم القومي";
            // 
            // labelControl5
            // 
            this.labelControl5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl5.Location = new System.Drawing.Point(464, 146);
            this.labelControl5.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(103, 17);
            this.labelControl5.TabIndex = 35;
            this.labelControl5.Text = "تاريخ نهاية الخدمة";
            // 
            // labelControl4
            // 
            this.labelControl4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl4.Location = new System.Drawing.Point(801, 146);
            this.labelControl4.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(52, 17);
            this.labelControl4.TabIndex = 35;
            this.labelControl4.Text = "رقم القيد";
            // 
            // labelControl15
            // 
            this.labelControl15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl15.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl15.Location = new System.Drawing.Point(657, 219);
            this.labelControl15.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(31, 17);
            this.labelControl15.TabIndex = 35;
            this.labelControl15.Text = "عنوان";
            // 
            // labelControl14
            // 
            this.labelControl14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl14.Location = new System.Drawing.Point(819, 219);
            this.labelControl14.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(32, 17);
            this.labelControl14.TabIndex = 35;
            this.labelControl14.Text = "موبيل";
            // 
            // labelControl3
            // 
            this.labelControl3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            this.labelControl3.Location = new System.Drawing.Point(506, 75);
            this.labelControl3.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(61, 17);
            this.labelControl3.TabIndex = 35;
            this.labelControl3.Text = "رقم الصرف";
            // 
            // lueEndworkId
            // 
            this.lueEndworkId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lueEndworkId.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.EndworkId", true));
            this.lueEndworkId.EnterMoveNextControl = true;
            this.lueEndworkId.Location = new System.Drawing.Point(580, 182);
            this.lueEndworkId.Margin = new System.Windows.Forms.Padding(0);
            this.lueEndworkId.Name = "lueEndworkId";
            this.lueEndworkId.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.lueEndworkId.Properties.Appearance.Options.UseFont = true;
            this.lueEndworkId.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)});
            this.lueEndworkId.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("EndworkReson", "الاسم", 40, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.lueEndworkId.Properties.DataSource = this.cDEndworkBindingSource;
            this.lueEndworkId.Properties.DisplayMember = "EndworkReson";
            this.lueEndworkId.Properties.NullText = "";
            this.lueEndworkId.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lueEndworkId.Properties.ValueMember = "EndworkId";
            this.lueEndworkId.Size = new System.Drawing.Size(162, 22);
            this.lueEndworkId.TabIndex = 9;
            conditionValidationRule10.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule10.ErrorText = "يجب ادخال سبب انهاء الخدمة";
            conditionValidationRule10.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.lueEndworkId, conditionValidationRule10);
            this.lueEndworkId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // cDEndworkBindingSource
            // 
            this.cDEndworkBindingSource.DataMember = "CDEndwork";
            this.cDEndworkBindingSource.DataSource = this.dsQueries;
            // 
            // dsQueries
            // 
            this.dsQueries.DataSetName = "dsQueries";
            this.dsQueries.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // labelControl6
            // 
            this.labelControl6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl6.Location = new System.Drawing.Point(749, 183);
            this.labelControl6.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(104, 17);
            this.labelControl6.TabIndex = 31;
            this.labelControl6.Text = "سبب انهاء الخدمة";
            // 
            // tbMMashatNId
            // 
            this.tbMMashatNId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMMashatNId.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.MMashatNId", true));
            this.tbMMashatNId.EnterMoveNextControl = true;
            this.tbMMashatNId.Location = new System.Drawing.Point(581, 111);
            this.tbMMashatNId.Margin = new System.Windows.Forms.Padding(0);
            this.tbMMashatNId.Name = "tbMMashatNId";
            this.tbMMashatNId.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.tbMMashatNId.Properties.Appearance.Options.UseFont = true;
            this.tbMMashatNId.Properties.DisplayFormat.FormatString = "n0";
            this.tbMMashatNId.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.tbMMashatNId.Properties.EditFormat.FormatString = "n0";
            this.tbMMashatNId.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.tbMMashatNId.Properties.Mask.EditMask = "[0-9]+";
            this.tbMMashatNId.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
            this.tbMMashatNId.Properties.MaxLength = 14;
            this.tbMMashatNId.Size = new System.Drawing.Size(162, 22);
            this.tbMMashatNId.TabIndex = 5;
            conditionValidationRule11.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule11.ErrorText = "يجب ادخال الرقم القومي";
            conditionValidationRule11.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.tbMMashatNId, conditionValidationRule11);
            this.tbMMashatNId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // tbKideNumber
            // 
            this.tbKideNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbKideNumber.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.KideNumber", true));
            this.tbKideNumber.EnterMoveNextControl = true;
            this.tbKideNumber.Location = new System.Drawing.Point(580, 147);
            this.tbKideNumber.Margin = new System.Windows.Forms.Padding(0);
            this.tbKideNumber.Name = "tbKideNumber";
            this.tbKideNumber.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.tbKideNumber.Properties.Appearance.Options.UseFont = true;
            this.tbKideNumber.Size = new System.Drawing.Size(162, 22);
            this.tbKideNumber.TabIndex = 7;
            conditionValidationRule12.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule12.ErrorText = "يجب ادخال رقم القيد";
            conditionValidationRule12.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.tbKideNumber, conditionValidationRule12);
            this.tbKideNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // textEdit2
            // 
            this.textEdit2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textEdit2.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.MMashataddres", true));
            this.textEdit2.EnterMoveNextControl = true;
            this.textEdit2.Location = new System.Drawing.Point(287, 218);
            this.textEdit2.Margin = new System.Windows.Forms.Padding(0);
            this.textEdit2.Name = "textEdit2";
            this.textEdit2.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textEdit2.Properties.Appearance.Options.UseFont = true;
            this.textEdit2.Size = new System.Drawing.Size(362, 22);
            this.textEdit2.TabIndex = 12;
            this.textEdit2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // textEdit1
            // 
            this.textEdit1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textEdit1.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.MMashatMobil", true));
            this.textEdit1.EnterMoveNextControl = true;
            this.textEdit1.Location = new System.Drawing.Point(694, 218);
            this.textEdit1.Margin = new System.Windows.Forms.Padding(0);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textEdit1.Properties.Appearance.Options.UseFont = true;
            this.textEdit1.Size = new System.Drawing.Size(114, 22);
            this.textEdit1.TabIndex = 11;
            this.textEdit1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // tbsarfnumber
            // 
            this.tbsarfnumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbsarfnumber.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.sarfnumber", true));
            this.tbsarfnumber.EnterMoveNextControl = true;
            this.tbsarfnumber.Location = new System.Drawing.Point(296, 74);
            this.tbsarfnumber.Margin = new System.Windows.Forms.Padding(0);
            this.tbsarfnumber.Name = "tbsarfnumber";
            this.tbsarfnumber.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.tbsarfnumber.Properties.Appearance.Options.UseFont = true;
            this.tbsarfnumber.Size = new System.Drawing.Size(162, 22);
            this.tbsarfnumber.TabIndex = 4;
            conditionValidationRule13.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule13.ErrorText = "يجب ادخال رقم الصرف";
            conditionValidationRule13.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.tbsarfnumber, conditionValidationRule13);
            this.tbsarfnumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // xtraTabPageNoSarf
            // 
            this.xtraTabPageNoSarf.Controls.Add(this.gridControlTBLNoSarfDetels);
            this.xtraTabPageNoSarf.Name = "xtraTabPageNoSarf";
            this.xtraTabPageNoSarf.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPageNoSarf.Text = "عدم الصرف";
            // 
            // gridControlTBLNoSarfDetels
            // 
            this.gridControlTBLNoSarfDetels.DataSource = this.LSMSTBLNoSarfDetels;
            this.gridControlTBLNoSarfDetels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlTBLNoSarfDetels.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gridControlTBLNoSarfDetels.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlTBLNoSarfDetels.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlTBLNoSarfDetels.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlTBLNoSarfDetels.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gridControlTBLNoSarfDetels.Location = new System.Drawing.Point(0, 0);
            this.gridControlTBLNoSarfDetels.MainView = this.gridViewTBLNoSarfDetels;
            this.gridControlTBLNoSarfDetels.Name = "gridControlTBLNoSarfDetels";
            this.gridControlTBLNoSarfDetels.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit2,
            this.repositoryItemButtonEdit1,
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemDateEdit3,
            this.repositoryItemLookUpEdit1});
            this.gridControlTBLNoSarfDetels.Size = new System.Drawing.Size(874, 246);
            this.gridControlTBLNoSarfDetels.TabIndex = 1;
            this.gridControlTBLNoSarfDetels.UseEmbeddedNavigator = true;
            this.gridControlTBLNoSarfDetels.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewTBLNoSarfDetels});
            // 
            // LSMSTBLNoSarfDetels
            // 
            this.LSMSTBLNoSarfDetels.ElementType = typeof(RetirementCenter.DataSources.Linq.TBLNoSarfDetel);
            this.LSMSTBLNoSarfDetels.KeyExpression = "[MMashatId], [yasref], [datehala]";
            // 
            // gridViewTBLNoSarfDetels
            // 
            this.gridViewTBLNoSarfDetels.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.coldatehala,
            this.gridColumn2,
            this.colyasref1,
            this.coldatein1,
            this.coluserin1});
            this.gridViewTBLNoSarfDetels.GridControl = this.gridControlTBLNoSarfDetels;
            this.gridViewTBLNoSarfDetels.Name = "gridViewTBLNoSarfDetels";
            this.gridViewTBLNoSarfDetels.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewTBLNoSarfDetels.OptionsBehavior.Editable = false;
            this.gridViewTBLNoSarfDetels.OptionsView.ColumnAutoWidth = false;
            this.gridViewTBLNoSarfDetels.RowHeight = 32;
            // 
            // coldatehala
            // 
            this.coldatehala.AppearanceCell.Options.UseTextOptions = true;
            this.coldatehala.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatehala.AppearanceHeader.Options.UseTextOptions = true;
            this.coldatehala.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatehala.Caption = "التاريخ";
            this.coldatehala.ColumnEdit = this.repositoryItemDateEdit1;
            this.coldatehala.FieldName = "datehala";
            this.coldatehala.Name = "coldatehala";
            this.coldatehala.Visible = true;
            this.coldatehala.VisibleIndex = 1;
            this.coldatehala.Width = 87;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd/MM/yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "ملاحظات";
            this.gridColumn2.ColumnEdit = this.repositoryItemMemoEdit2;
            this.gridColumn2.FieldName = "halarem";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 382;
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // colyasref1
            // 
            this.colyasref1.AppearanceCell.Options.UseTextOptions = true;
            this.colyasref1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colyasref1.AppearanceHeader.Options.UseTextOptions = true;
            this.colyasref1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colyasref1.Caption = "الصرف";
            this.colyasref1.ColumnEdit = this.repositoryItemCheckEdit1;
            this.colyasref1.FieldName = "yasref";
            this.colyasref1.Name = "colyasref1";
            this.colyasref1.Visible = true;
            this.colyasref1.VisibleIndex = 0;
            this.colyasref1.Width = 44;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // coldatein1
            // 
            this.coldatein1.AppearanceCell.Options.UseTextOptions = true;
            this.coldatein1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatein1.AppearanceHeader.Options.UseTextOptions = true;
            this.coldatein1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatein1.Caption = "تاريخ الادخال";
            this.coldatein1.ColumnEdit = this.repositoryItemDateEdit3;
            this.coldatein1.FieldName = "datein";
            this.coldatein1.Name = "coldatein1";
            this.coldatein1.OptionsColumn.AllowEdit = false;
            this.coldatein1.OptionsColumn.ReadOnly = true;
            this.coldatein1.Visible = true;
            this.coldatein1.VisibleIndex = 3;
            this.coldatein1.Width = 129;
            // 
            // repositoryItemDateEdit3
            // 
            this.repositoryItemDateEdit3.AutoHeight = false;
            this.repositoryItemDateEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit3.DisplayFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit3.EditFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit3.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit3.Mask.EditMask = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit3.Name = "repositoryItemDateEdit3";
            this.repositoryItemDateEdit3.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // coluserin1
            // 
            this.coluserin1.AppearanceCell.Options.UseTextOptions = true;
            this.coluserin1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coluserin1.AppearanceHeader.Options.UseTextOptions = true;
            this.coluserin1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coluserin1.Caption = "مسئول الادخال";
            this.coluserin1.ColumnEdit = this.repositoryItemLookUpEdit1;
            this.coluserin1.FieldName = "userin";
            this.coluserin1.Name = "coluserin1";
            this.coluserin1.OptionsColumn.AllowEdit = false;
            this.coluserin1.OptionsColumn.ReadOnly = true;
            this.coluserin1.Visible = true;
            this.coluserin1.VisibleIndex = 4;
            this.coluserin1.Width = 139;
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("RealName", "الاسم", 20, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.repositoryItemLookUpEdit1.DataSource = this.usersBindingSource;
            this.repositoryItemLookUpEdit1.DisplayMember = "RealName";
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            this.repositoryItemLookUpEdit1.NullText = "";
            this.repositoryItemLookUpEdit1.ValueMember = "UserID";
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "Users";
            this.usersBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            this.repositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // xtraTabPagePrivateSarf
            // 
            this.xtraTabPagePrivateSarf.Controls.Add(this.cemcompletesarf);
            this.xtraTabPagePrivateSarf.Controls.Add(this.pnlPrivateSarf);
            this.xtraTabPagePrivateSarf.Name = "xtraTabPagePrivateSarf";
            this.xtraTabPagePrivateSarf.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPagePrivateSarf.Text = "صرف خاص";
            // 
            // cemcompletesarf
            // 
            this.cemcompletesarf.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cemcompletesarf.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.mcompletesarf", true));
            this.cemcompletesarf.Location = new System.Drawing.Point(525, 36);
            this.cemcompletesarf.Name = "cemcompletesarf";
            this.cemcompletesarf.Properties.Caption = "تفعيل صرف كامل";
            this.cemcompletesarf.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.cemcompletesarf.Size = new System.Drawing.Size(108, 19);
            this.cemcompletesarf.TabIndex = 0;
            this.cemcompletesarf.CheckedChanged += new System.EventHandler(this.cemcompletesarf_CheckedChanged);
            // 
            // pnlPrivateSarf
            // 
            this.pnlPrivateSarf.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlPrivateSarf.Controls.Add(this.tbmelrasm);
            this.pnlPrivateSarf.Controls.Add(this.labelControl19);
            this.pnlPrivateSarf.Controls.Add(this.tbmmony);
            this.pnlPrivateSarf.Controls.Add(this.labelControl20);
            this.pnlPrivateSarf.Controls.Add(this.tbmestktaat);
            this.pnlPrivateSarf.Controls.Add(this.labelControl18);
            this.pnlPrivateSarf.Controls.Add(this.tbmeshtrakat);
            this.pnlPrivateSarf.Controls.Add(this.labelControl17);
            this.pnlPrivateSarf.Location = new System.Drawing.Point(242, 61);
            this.pnlPrivateSarf.Name = "pnlPrivateSarf";
            this.pnlPrivateSarf.Size = new System.Drawing.Size(391, 125);
            this.pnlPrivateSarf.TabIndex = 1;
            // 
            // tbmelrasm
            // 
            this.tbmelrasm.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.melrasm", true));
            this.tbmelrasm.EditValue = "0";
            this.tbmelrasm.Location = new System.Drawing.Point(39, 84);
            this.tbmelrasm.Name = "tbmelrasm";
            this.tbmelrasm.Properties.Mask.EditMask = "f2";
            this.tbmelrasm.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.tbmelrasm.Size = new System.Drawing.Size(100, 20);
            this.tbmelrasm.TabIndex = 3;
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(70, 65);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(23, 13);
            this.labelControl19.TabIndex = 0;
            this.labelControl19.Text = "رسم";
            // 
            // tbmmony
            // 
            this.tbmmony.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.mmony", true));
            this.tbmmony.EditValue = "0";
            this.tbmmony.Location = new System.Drawing.Point(145, 39);
            this.tbmmony.Name = "tbmmony";
            this.tbmmony.Properties.Mask.EditMask = "f2";
            this.tbmmony.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.tbmmony.Size = new System.Drawing.Size(100, 20);
            this.tbmmony.TabIndex = 0;
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(187, 20);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(27, 13);
            this.labelControl20.TabIndex = 0;
            this.labelControl20.Text = "المبلغ";
            // 
            // tbmestktaat
            // 
            this.tbmestktaat.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.mestktaat", true));
            this.tbmestktaat.EditValue = "0";
            this.tbmestktaat.Location = new System.Drawing.Point(145, 84);
            this.tbmestktaat.Name = "tbmestktaat";
            this.tbmestktaat.Properties.Mask.EditMask = "f2";
            this.tbmestktaat.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.tbmestktaat.Size = new System.Drawing.Size(100, 20);
            this.tbmestktaat.TabIndex = 2;
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(176, 65);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(42, 13);
            this.labelControl18.TabIndex = 0;
            this.labelControl18.Text = "استقطاع";
            // 
            // tbmeshtrakat
            // 
            this.tbmeshtrakat.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.meshtrakat", true));
            this.tbmeshtrakat.EditValue = "0";
            this.tbmeshtrakat.Location = new System.Drawing.Point(251, 84);
            this.tbmeshtrakat.Name = "tbmeshtrakat";
            this.tbmeshtrakat.Properties.Mask.EditMask = "f2";
            this.tbmeshtrakat.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.tbmeshtrakat.Size = new System.Drawing.Size(100, 20);
            this.tbmeshtrakat.TabIndex = 1;
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(282, 65);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(43, 13);
            this.labelControl17.TabIndex = 0;
            this.labelControl17.Text = "اشتراكات";
            // 
            // xtraTabPageRemarks
            // 
            this.xtraTabPageRemarks.Controls.Add(this.gridControlRemarks);
            this.xtraTabPageRemarks.Name = "xtraTabPageRemarks";
            this.xtraTabPageRemarks.PageVisible = false;
            this.xtraTabPageRemarks.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPageRemarks.Text = "الملاحظات";
            // 
            // gridControlRemarks
            // 
            this.gridControlRemarks.DataSource = this.tBLMRemarksBindingSource;
            this.gridControlRemarks.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlRemarks.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gridControlRemarks.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlRemarks.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlRemarks.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlRemarks.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gridControlRemarks.Location = new System.Drawing.Point(0, 0);
            this.gridControlRemarks.MainView = this.gridViewRemarks;
            this.gridControlRemarks.Name = "gridControlRemarks";
            this.gridControlRemarks.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit1,
            this.repositoryItemButtonEditSave,
            this.repositoryItemDateEdit2,
            this.repositoryItemLookUpEditeRemarkuserin});
            this.gridControlRemarks.Size = new System.Drawing.Size(874, 246);
            this.gridControlRemarks.TabIndex = 0;
            this.gridControlRemarks.UseEmbeddedNavigator = true;
            this.gridControlRemarks.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewRemarks});
            // 
            // tBLMRemarksBindingSource
            // 
            this.tBLMRemarksBindingSource.DataMember = "TBLMRemarks";
            this.tBLMRemarksBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // gridViewRemarks
            // 
            this.gridViewRemarks.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colmewmark,
            this.gridColumn1,
            this.coldatein,
            this.coluserin});
            this.gridViewRemarks.GridControl = this.gridControlRemarks;
            this.gridViewRemarks.Name = "gridViewRemarks";
            this.gridViewRemarks.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewRemarks.OptionsView.ColumnAutoWidth = false;
            this.gridViewRemarks.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            this.gridViewRemarks.RowHeight = 32;
            this.gridViewRemarks.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.gridViewRemarks_InitNewRow);
            // 
            // colmewmark
            // 
            this.colmewmark.AppearanceCell.Options.UseTextOptions = true;
            this.colmewmark.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colmewmark.AppearanceHeader.Options.UseTextOptions = true;
            this.colmewmark.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colmewmark.Caption = "ملاحظات";
            this.colmewmark.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colmewmark.FieldName = "mewmark";
            this.colmewmark.Name = "colmewmark";
            this.colmewmark.Visible = true;
            this.colmewmark.VisibleIndex = 0;
            this.colmewmark.Width = 468;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "حفظ";
            this.gridColumn1.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 80;
            // 
            // repositoryItemButtonEditSave
            // 
            this.repositoryItemButtonEditSave.AutoHeight = false;
            this.repositoryItemButtonEditSave.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEditSave.Name = "repositoryItemButtonEditSave";
            this.repositoryItemButtonEditSave.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSave.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSave_ButtonClick);
            // 
            // coldatein
            // 
            this.coldatein.AppearanceCell.Options.UseTextOptions = true;
            this.coldatein.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatein.AppearanceHeader.Options.UseTextOptions = true;
            this.coldatein.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatein.Caption = "تاريخ الادخال";
            this.coldatein.ColumnEdit = this.repositoryItemDateEdit2;
            this.coldatein.FieldName = "datein";
            this.coldatein.Name = "coldatein";
            this.coldatein.OptionsColumn.AllowEdit = false;
            this.coldatein.OptionsColumn.ReadOnly = true;
            this.coldatein.Visible = true;
            this.coldatein.VisibleIndex = 2;
            this.coldatein.Width = 108;
            // 
            // repositoryItemDateEdit2
            // 
            this.repositoryItemDateEdit2.AutoHeight = false;
            this.repositoryItemDateEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.DisplayFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit2.EditFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit2.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit2.Mask.EditMask = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit2.Name = "repositoryItemDateEdit2";
            this.repositoryItemDateEdit2.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // coluserin
            // 
            this.coluserin.AppearanceCell.Options.UseTextOptions = true;
            this.coluserin.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coluserin.AppearanceHeader.Options.UseTextOptions = true;
            this.coluserin.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coluserin.Caption = "مسئول الادخال";
            this.coluserin.ColumnEdit = this.repositoryItemLookUpEditeRemarkuserin;
            this.coluserin.FieldName = "userin";
            this.coluserin.Name = "coluserin";
            this.coluserin.OptionsColumn.AllowEdit = false;
            this.coluserin.OptionsColumn.ReadOnly = true;
            this.coluserin.Visible = true;
            this.coluserin.VisibleIndex = 3;
            this.coluserin.Width = 134;
            // 
            // repositoryItemLookUpEditeRemarkuserin
            // 
            this.repositoryItemLookUpEditeRemarkuserin.AutoHeight = false;
            this.repositoryItemLookUpEditeRemarkuserin.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEditeRemarkuserin.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("RealName", "الاسم", 20, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.repositoryItemLookUpEditeRemarkuserin.DataSource = this.usersBindingSource;
            this.repositoryItemLookUpEditeRemarkuserin.DisplayMember = "RealName";
            this.repositoryItemLookUpEditeRemarkuserin.Name = "repositoryItemLookUpEditeRemarkuserin";
            this.repositoryItemLookUpEditeRemarkuserin.NullText = "";
            this.repositoryItemLookUpEditeRemarkuserin.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemLookUpEditeRemarkuserin.ValueMember = "UserID";
            // 
            // xtraTabPageSyndicateTransfer
            // 
            this.xtraTabPageSyndicateTransfer.Controls.Add(this.gridControlSyndicateTransfer);
            this.xtraTabPageSyndicateTransfer.Name = "xtraTabPageSyndicateTransfer";
            this.xtraTabPageSyndicateTransfer.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPageSyndicateTransfer.Text = "تحويل النقابة";
            // 
            // gridControlSyndicateTransfer
            // 
            this.gridControlSyndicateTransfer.DataSource = this.tBLSyndicateTransferBindingSource;
            this.gridControlSyndicateTransfer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlSyndicateTransfer.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gridControlSyndicateTransfer.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlSyndicateTransfer.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlSyndicateTransfer.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlSyndicateTransfer.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gridControlSyndicateTransfer.Location = new System.Drawing.Point(0, 0);
            this.gridControlSyndicateTransfer.MainView = this.gridViewSyndicateTransfer;
            this.gridControlSyndicateTransfer.Name = "gridControlSyndicateTransfer";
            this.gridControlSyndicateTransfer.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit3,
            this.repositoryItemButtonEditTransferSave,
            this.repositoryItemDateEdit4,
            this.repositoryItemLookUpEdit2,
            this.repositoryItemGridLookUpEditSyndicateId,
            this.repositoryItemGridLookUpEditSubCommitteId,
            this.repositoryItemMemoExEditTransferrem});
            this.gridControlSyndicateTransfer.Size = new System.Drawing.Size(874, 246);
            this.gridControlSyndicateTransfer.TabIndex = 1;
            this.gridControlSyndicateTransfer.UseEmbeddedNavigator = true;
            this.gridControlSyndicateTransfer.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewSyndicateTransfer});
            // 
            // tBLSyndicateTransferBindingSource
            // 
            this.tBLSyndicateTransferBindingSource.DataMember = "TBLSyndicateTransfer";
            this.tBLSyndicateTransferBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // gridViewSyndicateTransfer
            // 
            this.gridViewSyndicateTransfer.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colNewSyndicateId,
            this.colNewSubCommitteId,
            this.colTransferrem,
            this.colOldSyndicateId,
            this.colOldSubCommitteId,
            this.colTransferDate,
            this.gridColumn6,
            this.gridColumn5,
            this.gridColumn4});
            this.gridViewSyndicateTransfer.GridControl = this.gridControlSyndicateTransfer;
            this.gridViewSyndicateTransfer.Name = "gridViewSyndicateTransfer";
            this.gridViewSyndicateTransfer.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewSyndicateTransfer.OptionsView.ColumnAutoWidth = false;
            this.gridViewSyndicateTransfer.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            this.gridViewSyndicateTransfer.RowHeight = 32;
            this.gridViewSyndicateTransfer.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.gridViewSyndicateTransfer_InitNewRow);
            // 
            // colNewSyndicateId
            // 
            this.colNewSyndicateId.AppearanceCell.Options.UseTextOptions = true;
            this.colNewSyndicateId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNewSyndicateId.AppearanceHeader.Options.UseTextOptions = true;
            this.colNewSyndicateId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNewSyndicateId.Caption = "النقابة الجديدة";
            this.colNewSyndicateId.ColumnEdit = this.repositoryItemGridLookUpEditSyndicateId;
            this.colNewSyndicateId.FieldName = "NewSyndicateId";
            this.colNewSyndicateId.Name = "colNewSyndicateId";
            this.colNewSyndicateId.Visible = true;
            this.colNewSyndicateId.VisibleIndex = 0;
            this.colNewSyndicateId.Width = 118;
            // 
            // repositoryItemGridLookUpEditSyndicateId
            // 
            this.repositoryItemGridLookUpEditSyndicateId.AutoHeight = false;
            this.repositoryItemGridLookUpEditSyndicateId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditSyndicateId.DataSource = this.LSMSCDSyndicateTransfer;
            this.repositoryItemGridLookUpEditSyndicateId.DisplayMember = "Syndicate";
            this.repositoryItemGridLookUpEditSyndicateId.Name = "repositoryItemGridLookUpEditSyndicateId";
            this.repositoryItemGridLookUpEditSyndicateId.NullText = "";
            this.repositoryItemGridLookUpEditSyndicateId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditSyndicateId.ValueMember = "SyndicateId";
            this.repositoryItemGridLookUpEditSyndicateId.View = this.repositoryItemGridLookUpEdit1View;
            // 
            // LSMSCDSyndicateTransfer
            // 
            this.LSMSCDSyndicateTransfer.ElementType = typeof(RetirementCenter.DataSources.Linq.CDSyndicate);
            this.LSMSCDSyndicateTransfer.KeyExpression = "[SyndicateId]";
            // 
            // repositoryItemGridLookUpEdit1View
            // 
            this.repositoryItemGridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colSyndicate1});
            this.repositoryItemGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemGridLookUpEdit1View.Name = "repositoryItemGridLookUpEdit1View";
            this.repositoryItemGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemGridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // colSyndicate1
            // 
            this.colSyndicate1.AppearanceCell.Options.UseTextOptions = true;
            this.colSyndicate1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicate1.AppearanceHeader.Options.UseTextOptions = true;
            this.colSyndicate1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicate1.Caption = "الفرعية";
            this.colSyndicate1.FieldName = "Syndicate";
            this.colSyndicate1.Name = "colSyndicate1";
            this.colSyndicate1.Visible = true;
            this.colSyndicate1.VisibleIndex = 0;
            // 
            // colNewSubCommitteId
            // 
            this.colNewSubCommitteId.AppearanceCell.Options.UseTextOptions = true;
            this.colNewSubCommitteId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNewSubCommitteId.AppearanceHeader.Options.UseTextOptions = true;
            this.colNewSubCommitteId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNewSubCommitteId.Caption = "اللجنة الجديدة";
            this.colNewSubCommitteId.ColumnEdit = this.repositoryItemGridLookUpEditSubCommitteId;
            this.colNewSubCommitteId.FieldName = "NewSubCommitteId";
            this.colNewSubCommitteId.Name = "colNewSubCommitteId";
            this.colNewSubCommitteId.Visible = true;
            this.colNewSubCommitteId.VisibleIndex = 1;
            this.colNewSubCommitteId.Width = 126;
            // 
            // repositoryItemGridLookUpEditSubCommitteId
            // 
            this.repositoryItemGridLookUpEditSubCommitteId.AutoHeight = false;
            this.repositoryItemGridLookUpEditSubCommitteId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditSubCommitteId.DataSource = this.LSMSCDSubCommitteTransfer;
            this.repositoryItemGridLookUpEditSubCommitteId.DisplayMember = "SubCommitte";
            this.repositoryItemGridLookUpEditSubCommitteId.Name = "repositoryItemGridLookUpEditSubCommitteId";
            this.repositoryItemGridLookUpEditSubCommitteId.NullText = "";
            this.repositoryItemGridLookUpEditSubCommitteId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditSubCommitteId.ValueMember = "SubCommitteId";
            this.repositoryItemGridLookUpEditSubCommitteId.View = this.gridView1;
            this.repositoryItemGridLookUpEditSubCommitteId.Enter += new System.EventHandler(this.repositoryItemGridLookUpEditSubCommitteId_Enter);
            // 
            // LSMSCDSubCommitteTransfer
            // 
            this.LSMSCDSubCommitteTransfer.ElementType = typeof(RetirementCenter.DataSources.Linq.CDSubCommitte);
            this.LSMSCDSubCommitteTransfer.KeyExpression = "[SubCommitteId]";
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colSubCommitte1});
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // colSubCommitte1
            // 
            this.colSubCommitte1.AppearanceCell.Options.UseTextOptions = true;
            this.colSubCommitte1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitte1.AppearanceHeader.Options.UseTextOptions = true;
            this.colSubCommitte1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitte1.Caption = "الجنة";
            this.colSubCommitte1.FieldName = "SubCommitte";
            this.colSubCommitte1.Name = "colSubCommitte1";
            this.colSubCommitte1.Visible = true;
            this.colSubCommitte1.VisibleIndex = 0;
            // 
            // colTransferrem
            // 
            this.colTransferrem.AppearanceCell.Options.UseTextOptions = true;
            this.colTransferrem.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTransferrem.AppearanceHeader.Options.UseTextOptions = true;
            this.colTransferrem.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTransferrem.Caption = "ملاحظات";
            this.colTransferrem.ColumnEdit = this.repositoryItemMemoExEditTransferrem;
            this.colTransferrem.FieldName = "Transferrem";
            this.colTransferrem.Name = "colTransferrem";
            this.colTransferrem.Visible = true;
            this.colTransferrem.VisibleIndex = 3;
            // 
            // repositoryItemMemoExEditTransferrem
            // 
            this.repositoryItemMemoExEditTransferrem.AutoHeight = false;
            this.repositoryItemMemoExEditTransferrem.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEditTransferrem.Name = "repositoryItemMemoExEditTransferrem";
            // 
            // colOldSyndicateId
            // 
            this.colOldSyndicateId.AppearanceCell.Options.UseTextOptions = true;
            this.colOldSyndicateId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colOldSyndicateId.AppearanceHeader.Options.UseTextOptions = true;
            this.colOldSyndicateId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colOldSyndicateId.Caption = "النقابة السابقة";
            this.colOldSyndicateId.ColumnEdit = this.repositoryItemGridLookUpEditSyndicateId;
            this.colOldSyndicateId.FieldName = "OldSyndicateId";
            this.colOldSyndicateId.Name = "colOldSyndicateId";
            this.colOldSyndicateId.OptionsColumn.AllowEdit = false;
            this.colOldSyndicateId.OptionsColumn.ReadOnly = true;
            this.colOldSyndicateId.Visible = true;
            this.colOldSyndicateId.VisibleIndex = 5;
            this.colOldSyndicateId.Width = 110;
            // 
            // colOldSubCommitteId
            // 
            this.colOldSubCommitteId.AppearanceCell.Options.UseTextOptions = true;
            this.colOldSubCommitteId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colOldSubCommitteId.AppearanceHeader.Options.UseTextOptions = true;
            this.colOldSubCommitteId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colOldSubCommitteId.Caption = "اللجنة السابقة";
            this.colOldSubCommitteId.ColumnEdit = this.repositoryItemGridLookUpEditSubCommitteId;
            this.colOldSubCommitteId.FieldName = "OldSubCommitteId";
            this.colOldSubCommitteId.Name = "colOldSubCommitteId";
            this.colOldSubCommitteId.OptionsColumn.AllowEdit = false;
            this.colOldSubCommitteId.OptionsColumn.ReadOnly = true;
            this.colOldSubCommitteId.Visible = true;
            this.colOldSubCommitteId.VisibleIndex = 6;
            this.colOldSubCommitteId.Width = 104;
            // 
            // colTransferDate
            // 
            this.colTransferDate.AppearanceCell.Options.UseTextOptions = true;
            this.colTransferDate.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTransferDate.AppearanceHeader.Options.UseTextOptions = true;
            this.colTransferDate.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTransferDate.Caption = "التاريخ";
            this.colTransferDate.FieldName = "TransferDate";
            this.colTransferDate.Name = "colTransferDate";
            this.colTransferDate.Visible = true;
            this.colTransferDate.VisibleIndex = 2;
            this.colTransferDate.Width = 87;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "مسئول الادخال";
            this.gridColumn6.ColumnEdit = this.repositoryItemLookUpEdit2;
            this.gridColumn6.FieldName = "userin";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.ReadOnly = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 8;
            this.gridColumn6.Width = 134;
            // 
            // repositoryItemLookUpEdit2
            // 
            this.repositoryItemLookUpEdit2.AutoHeight = false;
            this.repositoryItemLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit2.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("RealName", "الاسم", 20, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.repositoryItemLookUpEdit2.DataSource = this.usersBindingSource;
            this.repositoryItemLookUpEdit2.DisplayMember = "RealName";
            this.repositoryItemLookUpEdit2.Name = "repositoryItemLookUpEdit2";
            this.repositoryItemLookUpEdit2.NullText = "";
            this.repositoryItemLookUpEdit2.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemLookUpEdit2.ValueMember = "UserID";
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "تاريخ الادخال";
            this.gridColumn5.ColumnEdit = this.repositoryItemDateEdit4;
            this.gridColumn5.FieldName = "datein";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.ReadOnly = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 7;
            this.gridColumn5.Width = 108;
            // 
            // repositoryItemDateEdit4
            // 
            this.repositoryItemDateEdit4.AutoHeight = false;
            this.repositoryItemDateEdit4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit4.DisplayFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit4.EditFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit4.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit4.Mask.EditMask = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit4.Name = "repositoryItemDateEdit4";
            this.repositoryItemDateEdit4.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "حفظ";
            this.gridColumn4.ColumnEdit = this.repositoryItemButtonEditTransferSave;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 77;
            // 
            // repositoryItemButtonEditTransferSave
            // 
            this.repositoryItemButtonEditTransferSave.AutoHeight = false;
            this.repositoryItemButtonEditTransferSave.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEditTransferSave.Name = "repositoryItemButtonEditTransferSave";
            this.repositoryItemButtonEditTransferSave.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditTransferSave.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditTransferSave_ButtonClick);
            // 
            // repositoryItemMemoEdit3
            // 
            this.repositoryItemMemoEdit3.Name = "repositoryItemMemoEdit3";
            // 
            // xtraTabPageWarasa
            // 
            this.xtraTabPageWarasa.Controls.Add(this.panelControl1);
            this.xtraTabPageWarasa.Controls.Add(this.gridControlTBLWarasa);
            this.xtraTabPageWarasa.Name = "xtraTabPageWarasa";
            this.xtraTabPageWarasa.PageVisible = false;
            this.xtraTabPageWarasa.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPageWarasa.Text = "الورثة";
            // 
            // panelControl1
            // 
            this.panelControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.panelControl1.Controls.Add(this.btnAddTBLWarasa);
            this.panelControl1.Location = new System.Drawing.Point(3, 206);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(867, 37);
            this.panelControl1.TabIndex = 2;
            // 
            // btnAddTBLWarasa
            // 
            this.btnAddTBLWarasa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnAddTBLWarasa.Image = global::RetirementCenter.Properties.Resources.Add;
            this.btnAddTBLWarasa.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleLeft;
            this.btnAddTBLWarasa.Location = new System.Drawing.Point(760, 5);
            this.btnAddTBLWarasa.Name = "btnAddTBLWarasa";
            this.btnAddTBLWarasa.Size = new System.Drawing.Size(102, 28);
            this.btnAddTBLWarasa.TabIndex = 1;
            this.btnAddTBLWarasa.Text = "اضافة جديد";
            this.btnAddTBLWarasa.Click += new System.EventHandler(this.btnAddTBLWarasa_Click);
            // 
            // gridControlTBLWarasa
            // 
            this.gridControlTBLWarasa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridControlTBLWarasa.DataSource = this.tBLWarasaBindingSource;
            this.gridControlTBLWarasa.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gridControlTBLWarasa.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlTBLWarasa.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlTBLWarasa.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlTBLWarasa.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gridControlTBLWarasa.Location = new System.Drawing.Point(3, 3);
            this.gridControlTBLWarasa.MainView = this.gridViewTBLWarasa;
            this.gridControlTBLWarasa.Name = "gridControlTBLWarasa";
            this.gridControlTBLWarasa.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditWarasaEdit,
            this.repositoryItemDateEdit5,
            this.repositoryItemButtonEditWarasaDel,
            this.repositoryItemMemoExEdit1,
            this.repositoryItemCheckEdit2,
            this.repositoryItemDateEditWarasaDMY,
            this.repositoryItemButtonEditWarasaSarf,
            this.repositoryItemButtonEditWarasaQuickSave,
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId,
            this.repositoryItemGridLookUpEditWarasauserin,
            this.repositoryItemGridLookUpEditWarasaSyndicateId,
            this.repositoryItemGridLookUpEditWarasaSubCommitteId,
            this.repositoryItemButtonEditWarasaRemark,
            this.repositoryItemGridLookUpEditresponsiblesarfId});
            this.gridControlTBLWarasa.Size = new System.Drawing.Size(867, 197);
            this.gridControlTBLWarasa.TabIndex = 1;
            this.gridControlTBLWarasa.UseEmbeddedNavigator = true;
            this.gridControlTBLWarasa.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewTBLWarasa});
            // 
            // tBLWarasaBindingSource
            // 
            this.tBLWarasaBindingSource.DataMember = "TBLWarasa";
            this.tBLWarasaBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // gridViewTBLWarasa
            // 
            this.gridViewTBLWarasa.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colpersonName,
            this.colWarasaType1,
            this.colpersonNID,
            this.colpersonbirth,
            this.colpersonmobile,
            this.colpersonAddres,
            this.colyasref2,
            this.colSyndicateId,
            this.colSubCommitteId,
            this.gridColumn10,
            this.gridColumn7,
            this.gridColumn3,
            this.gridColumn8,
            this.colRealName,
            this.gridColumn9,
            this.gridColumn11,
            this.colresponsiblesarf,
            this.colresponsiblesarfId});
            this.gridViewTBLWarasa.GridControl = this.gridControlTBLWarasa;
            this.gridViewTBLWarasa.Name = "gridViewTBLWarasa";
            this.gridViewTBLWarasa.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewTBLWarasa.OptionsView.ColumnAutoWidth = false;
            this.gridViewTBLWarasa.OptionsView.ShowDetailButtons = false;
            this.gridViewTBLWarasa.RowHeight = 26;
            // 
            // colpersonName
            // 
            this.colpersonName.AppearanceCell.Options.UseTextOptions = true;
            this.colpersonName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonName.AppearanceHeader.Options.UseTextOptions = true;
            this.colpersonName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonName.Caption = "الاسم";
            this.colpersonName.FieldName = "personName";
            this.colpersonName.Name = "colpersonName";
            this.colpersonName.Visible = true;
            this.colpersonName.VisibleIndex = 0;
            this.colpersonName.Width = 116;
            // 
            // colWarasaType1
            // 
            this.colWarasaType1.AppearanceCell.Options.UseTextOptions = true;
            this.colWarasaType1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWarasaType1.AppearanceHeader.Options.UseTextOptions = true;
            this.colWarasaType1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWarasaType1.Caption = "الفئة";
            this.colWarasaType1.ColumnEdit = this.repositoryItemGridLookUpEditWarasaWarasaTypeId;
            this.colWarasaType1.FieldName = "WarasaTypeId";
            this.colWarasaType1.Name = "colWarasaType1";
            this.colWarasaType1.Visible = true;
            this.colWarasaType1.VisibleIndex = 1;
            // 
            // repositoryItemGridLookUpEditWarasaWarasaTypeId
            // 
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.AutoHeight = false;
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.DataSource = this.LSMSCDWarasaType;
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.DisplayMember = "WarasaType";
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.Name = "repositoryItemGridLookUpEditWarasaWarasaTypeId";
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.NullText = "";
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.ValueMember = "WarasaTypeId";
            this.repositoryItemGridLookUpEditWarasaWarasaTypeId.View = this.gridView2;
            // 
            // LSMSCDWarasaType
            // 
            this.LSMSCDWarasaType.ElementType = typeof(RetirementCenter.DataSources.Linq.CDWarasaType);
            this.LSMSCDWarasaType.KeyExpression = "WarasaTypeId";
            // 
            // gridView2
            // 
            this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // colpersonNID
            // 
            this.colpersonNID.AppearanceCell.Options.UseTextOptions = true;
            this.colpersonNID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonNID.AppearanceHeader.Options.UseTextOptions = true;
            this.colpersonNID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonNID.Caption = "الرقم القومي";
            this.colpersonNID.FieldName = "personNID";
            this.colpersonNID.Name = "colpersonNID";
            this.colpersonNID.Visible = true;
            this.colpersonNID.VisibleIndex = 2;
            // 
            // colpersonbirth
            // 
            this.colpersonbirth.AppearanceCell.Options.UseTextOptions = true;
            this.colpersonbirth.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonbirth.AppearanceHeader.Options.UseTextOptions = true;
            this.colpersonbirth.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonbirth.Caption = "تاريخ الميلاد";
            this.colpersonbirth.ColumnEdit = this.repositoryItemDateEditWarasaDMY;
            this.colpersonbirth.FieldName = "personbirth";
            this.colpersonbirth.Name = "colpersonbirth";
            this.colpersonbirth.Visible = true;
            this.colpersonbirth.VisibleIndex = 3;
            // 
            // repositoryItemDateEditWarasaDMY
            // 
            this.repositoryItemDateEditWarasaDMY.AutoHeight = false;
            this.repositoryItemDateEditWarasaDMY.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEditWarasaDMY.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditWarasaDMY.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditWarasaDMY.EditFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditWarasaDMY.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditWarasaDMY.Mask.EditMask = "dd/MM/yyyy";
            this.repositoryItemDateEditWarasaDMY.Name = "repositoryItemDateEditWarasaDMY";
            this.repositoryItemDateEditWarasaDMY.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // colpersonmobile
            // 
            this.colpersonmobile.AppearanceCell.Options.UseTextOptions = true;
            this.colpersonmobile.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonmobile.AppearanceHeader.Options.UseTextOptions = true;
            this.colpersonmobile.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonmobile.Caption = "موبيل";
            this.colpersonmobile.FieldName = "personmobile";
            this.colpersonmobile.Name = "colpersonmobile";
            this.colpersonmobile.Visible = true;
            this.colpersonmobile.VisibleIndex = 4;
            this.colpersonmobile.Width = 82;
            // 
            // colpersonAddres
            // 
            this.colpersonAddres.AppearanceCell.Options.UseTextOptions = true;
            this.colpersonAddres.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonAddres.AppearanceHeader.Options.UseTextOptions = true;
            this.colpersonAddres.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonAddres.Caption = "العنوان";
            this.colpersonAddres.ColumnEdit = this.repositoryItemMemoExEdit1;
            this.colpersonAddres.FieldName = "personAddres";
            this.colpersonAddres.Name = "colpersonAddres";
            this.colpersonAddres.Visible = true;
            this.colpersonAddres.VisibleIndex = 5;
            this.colpersonAddres.Width = 76;
            // 
            // repositoryItemMemoExEdit1
            // 
            this.repositoryItemMemoExEdit1.AutoHeight = false;
            this.repositoryItemMemoExEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit1.Name = "repositoryItemMemoExEdit1";
            // 
            // colyasref2
            // 
            this.colyasref2.AppearanceCell.Options.UseTextOptions = true;
            this.colyasref2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colyasref2.AppearanceHeader.Options.UseTextOptions = true;
            this.colyasref2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colyasref2.Caption = "يصرف";
            this.colyasref2.ColumnEdit = this.repositoryItemCheckEdit2;
            this.colyasref2.FieldName = "yasref";
            this.colyasref2.Name = "colyasref2";
            this.colyasref2.OptionsColumn.AllowEdit = false;
            this.colyasref2.OptionsColumn.ReadOnly = true;
            this.colyasref2.Visible = true;
            this.colyasref2.VisibleIndex = 6;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // colSyndicateId
            // 
            this.colSyndicateId.AppearanceCell.Options.UseTextOptions = true;
            this.colSyndicateId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicateId.AppearanceHeader.Options.UseTextOptions = true;
            this.colSyndicateId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicateId.Caption = "الفرعية";
            this.colSyndicateId.ColumnEdit = this.repositoryItemGridLookUpEditWarasaSyndicateId;
            this.colSyndicateId.FieldName = "SyndicateId";
            this.colSyndicateId.Name = "colSyndicateId";
            this.colSyndicateId.OptionsColumn.ReadOnly = true;
            this.colSyndicateId.Visible = true;
            this.colSyndicateId.VisibleIndex = 7;
            // 
            // repositoryItemGridLookUpEditWarasaSyndicateId
            // 
            this.repositoryItemGridLookUpEditWarasaSyndicateId.AutoHeight = false;
            this.repositoryItemGridLookUpEditWarasaSyndicateId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditWarasaSyndicateId.DataSource = this.LSMSCDSyndicate;
            this.repositoryItemGridLookUpEditWarasaSyndicateId.DisplayMember = "Syndicate";
            this.repositoryItemGridLookUpEditWarasaSyndicateId.Name = "repositoryItemGridLookUpEditWarasaSyndicateId";
            this.repositoryItemGridLookUpEditWarasaSyndicateId.NullText = "";
            this.repositoryItemGridLookUpEditWarasaSyndicateId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditWarasaSyndicateId.ValueMember = "SyndicateId";
            this.repositoryItemGridLookUpEditWarasaSyndicateId.View = this.gridView4;
            // 
            // gridView4
            // 
            this.gridView4.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colSyndicate2});
            this.gridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView4.Name = "gridView4";
            this.gridView4.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView4.OptionsView.ShowGroupPanel = false;
            // 
            // colSyndicate2
            // 
            this.colSyndicate2.AppearanceCell.Options.UseTextOptions = true;
            this.colSyndicate2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicate2.AppearanceHeader.Options.UseTextOptions = true;
            this.colSyndicate2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSyndicate2.Caption = "الفرعية";
            this.colSyndicate2.FieldName = "Syndicate";
            this.colSyndicate2.Name = "colSyndicate2";
            this.colSyndicate2.Visible = true;
            this.colSyndicate2.VisibleIndex = 0;
            // 
            // colSubCommitteId
            // 
            this.colSubCommitteId.AppearanceCell.Options.UseTextOptions = true;
            this.colSubCommitteId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitteId.AppearanceHeader.Options.UseTextOptions = true;
            this.colSubCommitteId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitteId.Caption = "اللجنة";
            this.colSubCommitteId.ColumnEdit = this.repositoryItemGridLookUpEditWarasaSubCommitteId;
            this.colSubCommitteId.FieldName = "SubCommitteId";
            this.colSubCommitteId.Name = "colSubCommitteId";
            this.colSubCommitteId.OptionsColumn.ReadOnly = true;
            this.colSubCommitteId.Visible = true;
            this.colSubCommitteId.VisibleIndex = 8;
            // 
            // repositoryItemGridLookUpEditWarasaSubCommitteId
            // 
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.AutoHeight = false;
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.DataSource = this.LSMSCDSubCommitte;
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.DisplayMember = "SubCommitte";
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.Name = "repositoryItemGridLookUpEditWarasaSubCommitteId";
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.NullText = "";
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.ValueMember = "SubCommitteId";
            this.repositoryItemGridLookUpEditWarasaSubCommitteId.View = this.gridView5;
            // 
            // gridView5
            // 
            this.gridView5.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colSubCommitte2});
            this.gridView5.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView5.Name = "gridView5";
            this.gridView5.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView5.OptionsView.ShowGroupPanel = false;
            // 
            // colSubCommitte2
            // 
            this.colSubCommitte2.AppearanceCell.Options.UseTextOptions = true;
            this.colSubCommitte2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitte2.AppearanceHeader.Options.UseTextOptions = true;
            this.colSubCommitte2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSubCommitte2.Caption = "اللجنة";
            this.colSubCommitte2.FieldName = "SubCommitte";
            this.colSubCommitte2.Name = "colSubCommitte2";
            this.colSubCommitte2.Visible = true;
            this.colSubCommitte2.VisibleIndex = 0;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "حفظ";
            this.gridColumn10.ColumnEdit = this.repositoryItemButtonEditWarasaQuickSave;
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 11;
            // 
            // repositoryItemButtonEditWarasaQuickSave
            // 
            this.repositoryItemButtonEditWarasaQuickSave.AutoHeight = false;
            this.repositoryItemButtonEditWarasaQuickSave.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEditWarasaQuickSave.Name = "repositoryItemButtonEditWarasaQuickSave";
            this.repositoryItemButtonEditWarasaQuickSave.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditWarasaQuickSave.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditWarasaQuickSave_ButtonClick);
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "التعديل";
            this.gridColumn7.ColumnEdit = this.repositoryItemButtonEditWarasaEdit;
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 12;
            this.gridColumn7.Width = 80;
            // 
            // repositoryItemButtonEditWarasaEdit
            // 
            this.repositoryItemButtonEditWarasaEdit.AutoHeight = false;
            this.repositoryItemButtonEditWarasaEdit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEditWarasaEdit.Name = "repositoryItemButtonEditWarasaEdit";
            this.repositoryItemButtonEditWarasaEdit.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditWarasaEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditWarasaEdit_ButtonClick);
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "حذف";
            this.gridColumn3.ColumnEdit = this.repositoryItemButtonEditWarasaDel;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 13;
            // 
            // repositoryItemButtonEditWarasaDel
            // 
            this.repositoryItemButtonEditWarasaDel.AutoHeight = false;
            this.repositoryItemButtonEditWarasaDel.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.repositoryItemButtonEditWarasaDel.Name = "repositoryItemButtonEditWarasaDel";
            this.repositoryItemButtonEditWarasaDel.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditWarasaDel.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditWarasaDel_ButtonClick);
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "تاريخ الادخال";
            this.gridColumn8.ColumnEdit = this.repositoryItemDateEdit5;
            this.gridColumn8.FieldName = "datein";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.OptionsColumn.ReadOnly = true;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 16;
            this.gridColumn8.Width = 108;
            // 
            // repositoryItemDateEdit5
            // 
            this.repositoryItemDateEdit5.AutoHeight = false;
            this.repositoryItemDateEdit5.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit5.DisplayFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit5.EditFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit5.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit5.Mask.EditMask = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit5.Name = "repositoryItemDateEdit5";
            this.repositoryItemDateEdit5.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // colRealName
            // 
            this.colRealName.AppearanceCell.Options.UseTextOptions = true;
            this.colRealName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colRealName.AppearanceHeader.Options.UseTextOptions = true;
            this.colRealName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colRealName.Caption = "مسئول الادخال";
            this.colRealName.ColumnEdit = this.repositoryItemGridLookUpEditWarasauserin;
            this.colRealName.FieldName = "userin";
            this.colRealName.Name = "colRealName";
            this.colRealName.OptionsColumn.ReadOnly = true;
            this.colRealName.Visible = true;
            this.colRealName.VisibleIndex = 17;
            this.colRealName.Width = 109;
            // 
            // repositoryItemGridLookUpEditWarasauserin
            // 
            this.repositoryItemGridLookUpEditWarasauserin.AutoHeight = false;
            this.repositoryItemGridLookUpEditWarasauserin.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditWarasauserin.DataSource = this.usersBindingSource;
            this.repositoryItemGridLookUpEditWarasauserin.DisplayMember = "RealName";
            this.repositoryItemGridLookUpEditWarasauserin.Name = "repositoryItemGridLookUpEditWarasauserin";
            this.repositoryItemGridLookUpEditWarasauserin.NullText = "";
            this.repositoryItemGridLookUpEditWarasauserin.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditWarasauserin.ValueMember = "UserID";
            this.repositoryItemGridLookUpEditWarasauserin.View = this.gridView3;
            // 
            // gridView3
            // 
            this.gridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView3.Name = "gridView3";
            this.gridView3.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView3.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "ملاحظات الصرف";
            this.gridColumn9.ColumnEdit = this.repositoryItemButtonEditWarasaSarf;
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.ReadOnly = true;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 15;
            this.gridColumn9.Width = 100;
            // 
            // repositoryItemButtonEditWarasaSarf
            // 
            this.repositoryItemButtonEditWarasaSarf.AutoHeight = false;
            this.repositoryItemButtonEditWarasaSarf.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEditWarasaSarf.Name = "repositoryItemButtonEditWarasaSarf";
            this.repositoryItemButtonEditWarasaSarf.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditWarasaSarf.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditWarasaSarf_ButtonClick);
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.Caption = "ملاحظات الوريث";
            this.gridColumn11.ColumnEdit = this.repositoryItemButtonEditWarasaRemark;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 14;
            this.gridColumn11.Width = 106;
            // 
            // repositoryItemButtonEditWarasaRemark
            // 
            this.repositoryItemButtonEditWarasaRemark.AutoHeight = false;
            this.repositoryItemButtonEditWarasaRemark.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEditWarasaRemark.Name = "repositoryItemButtonEditWarasaRemark";
            this.repositoryItemButtonEditWarasaRemark.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditWarasaRemark.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditWarasaRemark_ButtonClick);
            // 
            // colresponsiblesarf
            // 
            this.colresponsiblesarf.AppearanceCell.Options.UseTextOptions = true;
            this.colresponsiblesarf.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colresponsiblesarf.AppearanceHeader.Options.UseTextOptions = true;
            this.colresponsiblesarf.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colresponsiblesarf.Caption = "مسئول صرف ";
            this.colresponsiblesarf.ColumnEdit = this.repositoryItemCheckEdit2;
            this.colresponsiblesarf.FieldName = "responsiblesarf";
            this.colresponsiblesarf.Name = "colresponsiblesarf";
            this.colresponsiblesarf.Visible = true;
            this.colresponsiblesarf.VisibleIndex = 9;
            this.colresponsiblesarf.Width = 84;
            // 
            // colresponsiblesarfId
            // 
            this.colresponsiblesarfId.AppearanceCell.Options.UseTextOptions = true;
            this.colresponsiblesarfId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colresponsiblesarfId.AppearanceHeader.Options.UseTextOptions = true;
            this.colresponsiblesarfId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colresponsiblesarfId.Caption = "اسم المسئول";
            this.colresponsiblesarfId.ColumnEdit = this.repositoryItemGridLookUpEditresponsiblesarfId;
            this.colresponsiblesarfId.FieldName = "responsiblesarfId";
            this.colresponsiblesarfId.Name = "colresponsiblesarfId";
            this.colresponsiblesarfId.Visible = true;
            this.colresponsiblesarfId.VisibleIndex = 10;
            this.colresponsiblesarfId.Width = 76;
            // 
            // repositoryItemGridLookUpEditresponsiblesarfId
            // 
            this.repositoryItemGridLookUpEditresponsiblesarfId.AutoHeight = false;
            this.repositoryItemGridLookUpEditresponsiblesarfId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditresponsiblesarfId.DataSource = this.LSMSTBLWarasa;
            this.repositoryItemGridLookUpEditresponsiblesarfId.DisplayMember = "personName";
            this.repositoryItemGridLookUpEditresponsiblesarfId.Name = "repositoryItemGridLookUpEditresponsiblesarfId";
            this.repositoryItemGridLookUpEditresponsiblesarfId.NullText = "";
            this.repositoryItemGridLookUpEditresponsiblesarfId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditresponsiblesarfId.ValueMember = "PersonId";
            this.repositoryItemGridLookUpEditresponsiblesarfId.View = this.gridView6;
            // 
            // LSMSTBLWarasa
            // 
            this.LSMSTBLWarasa.ElementType = typeof(RetirementCenter.DataSources.Linq.vTBLWarasa);
            this.LSMSTBLWarasa.KeyExpression = "PersonId";
            // 
            // gridView6
            // 
            this.gridView6.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colpersonName1});
            this.gridView6.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView6.Name = "gridView6";
            this.gridView6.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView6.OptionsView.ShowGroupPanel = false;
            // 
            // colpersonName1
            // 
            this.colpersonName1.AppearanceCell.Options.UseTextOptions = true;
            this.colpersonName1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonName1.AppearanceHeader.Options.UseTextOptions = true;
            this.colpersonName1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colpersonName1.Caption = "اسم المسئول";
            this.colpersonName1.FieldName = "personName";
            this.colpersonName1.Name = "colpersonName1";
            this.colpersonName1.Visible = true;
            this.colpersonName1.VisibleIndex = 0;
            // 
            // xtraTabPageChangeToWarasa
            // 
            this.xtraTabPageChangeToWarasa.Controls.Add(this.LUEChangeHala);
            this.xtraTabPageChangeToWarasa.Controls.Add(this.btnChangeHala);
            this.xtraTabPageChangeToWarasa.Controls.Add(this.labelControl16);
            this.xtraTabPageChangeToWarasa.Name = "xtraTabPageChangeToWarasa";
            this.xtraTabPageChangeToWarasa.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPageChangeToWarasa.Text = "تحويل من اعضاء لورثة";
            // 
            // LUEChangeHala
            // 
            this.LUEChangeHala.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LUEChangeHala.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.dsRetirementCenter, "TBLMashat.MashHalaId", true));
            this.LUEChangeHala.EnterMoveNextControl = true;
            this.LUEChangeHala.Location = new System.Drawing.Point(301, 84);
            this.LUEChangeHala.Margin = new System.Windows.Forms.Padding(0);
            this.LUEChangeHala.Name = "LUEChangeHala";
            this.LUEChangeHala.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.LUEChangeHala.Properties.Appearance.Options.UseFont = true;
            this.LUEChangeHala.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LUEChangeHala.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MashHala", "الاسم", 40, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.LUEChangeHala.Properties.DataSource = this.LSMSCDMashHala;
            this.LUEChangeHala.Properties.DisplayMember = "MashHala";
            this.LUEChangeHala.Properties.NullText = "";
            this.LUEChangeHala.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.LUEChangeHala.Properties.ValueMember = "MashHalaId";
            this.LUEChangeHala.Size = new System.Drawing.Size(200, 22);
            this.LUEChangeHala.TabIndex = 32;
            conditionValidationRule14.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule14.ErrorText = "يجب ادخال الوظيفه";
            conditionValidationRule14.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Warning;
            this.dxValidationProviderMain.SetValidationRule(this.LUEChangeHala, conditionValidationRule14);
            // 
            // btnChangeHala
            // 
            this.btnChangeHala.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnChangeHala.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnChangeHala.Appearance.Options.UseFont = true;
            this.btnChangeHala.Location = new System.Drawing.Point(301, 131);
            this.btnChangeHala.Margin = new System.Windows.Forms.Padding(0);
            this.btnChangeHala.Name = "btnChangeHala";
            this.btnChangeHala.Size = new System.Drawing.Size(272, 32);
            this.btnChangeHala.TabIndex = 1;
            this.btnChangeHala.Tag = "new";
            this.btnChangeHala.Text = "تحويل الحالة";
            this.btnChangeHala.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.btnChangeHala.ToolTipTitle = "اضافة F5";
            this.btnChangeHala.Click += new System.EventHandler(this.btnChangeHala_Click);
            // 
            // labelControl16
            // 
            this.labelControl16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.labelControl16.Location = new System.Drawing.Point(521, 83);
            this.labelControl16.Margin = new System.Windows.Forms.Padding(0);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(52, 17);
            this.labelControl16.TabIndex = 33;
            this.labelControl16.Text = "نوع البيان";
            // 
            // xtraTabPageReSarf
            // 
            this.xtraTabPageReSarf.Controls.Add(this.gridControlResarf);
            this.xtraTabPageReSarf.Name = "xtraTabPageReSarf";
            this.xtraTabPageReSarf.Size = new System.Drawing.Size(874, 246);
            this.xtraTabPageReSarf.Text = "اعادة الصرف";
            // 
            // gridControlResarf
            // 
            this.gridControlResarf.DataSource = this.tBLReSarfBindingSource;
            this.gridControlResarf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlResarf.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gridControlResarf.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlResarf.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlResarf.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlResarf.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gridControlResarf.Location = new System.Drawing.Point(0, 0);
            this.gridControlResarf.MainView = this.gridViewResarf;
            this.gridControlResarf.Name = "gridControlResarf";
            this.gridControlResarf.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit4,
            this.repositoryItemButtonEditResarfSave,
            this.repositoryItemDateEdit6,
            this.repositoryItemLookUpEdit3,
            this.repositoryItemButtonEditResarfDel,
            this.repositoryItemGridLookUpEditDofatSarfId,
            this.repositoryItemMemoExEdit2,
            this.repositoryItemTextEditResarff2,
            this.repositoryItemDateEditResarfDMY});
            this.gridControlResarf.Size = new System.Drawing.Size(874, 246);
            this.gridControlResarf.TabIndex = 1;
            this.gridControlResarf.UseEmbeddedNavigator = true;
            this.gridControlResarf.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewResarf});
            // 
            // tBLReSarfBindingSource
            // 
            this.tBLReSarfBindingSource.DataMember = "TBLReSarf";
            this.tBLReSarfBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // gridViewResarf
            // 
            this.gridViewResarf.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colDofatSarfId,
            this.coldatefrom,
            this.coldateto,
            this.colreestktaa,
            this.colremarks,
            this.gridColumn14,
            this.gridColumn15,
            this.gridColumn13,
            this.gridColumn12});
            this.gridViewResarf.GridControl = this.gridControlResarf;
            this.gridViewResarf.Name = "gridViewResarf";
            this.gridViewResarf.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewResarf.OptionsView.ColumnAutoWidth = false;
            this.gridViewResarf.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            this.gridViewResarf.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.gridViewResarf_InitNewRow);
            // 
            // colDofatSarfId
            // 
            this.colDofatSarfId.AppearanceCell.Options.UseTextOptions = true;
            this.colDofatSarfId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDofatSarfId.AppearanceHeader.Options.UseTextOptions = true;
            this.colDofatSarfId.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDofatSarfId.Caption = "الدفعة";
            this.colDofatSarfId.ColumnEdit = this.repositoryItemGridLookUpEditDofatSarfId;
            this.colDofatSarfId.FieldName = "DofatSarfId";
            this.colDofatSarfId.Name = "colDofatSarfId";
            this.colDofatSarfId.Visible = true;
            this.colDofatSarfId.VisibleIndex = 0;
            this.colDofatSarfId.Width = 136;
            // 
            // repositoryItemGridLookUpEditDofatSarfId
            // 
            this.repositoryItemGridLookUpEditDofatSarfId.AutoHeight = false;
            this.repositoryItemGridLookUpEditDofatSarfId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditDofatSarfId.DataSource = this.LSMSTBLDofatSarf;
            this.repositoryItemGridLookUpEditDofatSarfId.DisplayMember = "DofatSarf";
            this.repositoryItemGridLookUpEditDofatSarfId.Name = "repositoryItemGridLookUpEditDofatSarfId";
            this.repositoryItemGridLookUpEditDofatSarfId.NullText = "";
            this.repositoryItemGridLookUpEditDofatSarfId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditDofatSarfId.ValueMember = "DofatSarfId";
            this.repositoryItemGridLookUpEditDofatSarfId.View = this.gridView7;
            // 
            // gridView7
            // 
            this.gridView7.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colDofatSarf});
            this.gridView7.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView7.Name = "gridView7";
            this.gridView7.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView7.OptionsView.ShowGroupPanel = false;
            // 
            // colDofatSarf
            // 
            this.colDofatSarf.AppearanceCell.Options.UseTextOptions = true;
            this.colDofatSarf.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDofatSarf.AppearanceHeader.Options.UseTextOptions = true;
            this.colDofatSarf.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDofatSarf.Caption = "الاسم";
            this.colDofatSarf.FieldName = "DofatSarf";
            this.colDofatSarf.Name = "colDofatSarf";
            this.colDofatSarf.Visible = true;
            this.colDofatSarf.VisibleIndex = 0;
            // 
            // coldatefrom
            // 
            this.coldatefrom.AppearanceCell.Options.UseTextOptions = true;
            this.coldatefrom.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatefrom.AppearanceHeader.Options.UseTextOptions = true;
            this.coldatefrom.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldatefrom.Caption = "من تاريخ";
            this.coldatefrom.ColumnEdit = this.repositoryItemDateEditResarfDMY;
            this.coldatefrom.FieldName = "datefrom";
            this.coldatefrom.Name = "coldatefrom";
            this.coldatefrom.Visible = true;
            this.coldatefrom.VisibleIndex = 1;
            this.coldatefrom.Width = 83;
            // 
            // repositoryItemDateEditResarfDMY
            // 
            this.repositoryItemDateEditResarfDMY.AutoHeight = false;
            this.repositoryItemDateEditResarfDMY.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEditResarfDMY.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditResarfDMY.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditResarfDMY.EditFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditResarfDMY.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditResarfDMY.Mask.EditMask = "dd/MM/yyyy";
            this.repositoryItemDateEditResarfDMY.Name = "repositoryItemDateEditResarfDMY";
            this.repositoryItemDateEditResarfDMY.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // coldateto
            // 
            this.coldateto.AppearanceCell.Options.UseTextOptions = true;
            this.coldateto.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldateto.AppearanceHeader.Options.UseTextOptions = true;
            this.coldateto.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coldateto.Caption = "الي تاريخ";
            this.coldateto.ColumnEdit = this.repositoryItemDateEditResarfDMY;
            this.coldateto.FieldName = "dateto";
            this.coldateto.Name = "coldateto";
            this.coldateto.Visible = true;
            this.coldateto.VisibleIndex = 2;
            this.coldateto.Width = 80;
            // 
            // colreestktaa
            // 
            this.colreestktaa.AppearanceCell.Options.UseTextOptions = true;
            this.colreestktaa.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colreestktaa.AppearanceHeader.Options.UseTextOptions = true;
            this.colreestktaa.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colreestktaa.Caption = "الاستقطاع";
            this.colreestktaa.ColumnEdit = this.repositoryItemTextEditResarff2;
            this.colreestktaa.FieldName = "reestktaa";
            this.colreestktaa.Name = "colreestktaa";
            this.colreestktaa.Visible = true;
            this.colreestktaa.VisibleIndex = 3;
            // 
            // repositoryItemTextEditResarff2
            // 
            this.repositoryItemTextEditResarff2.AutoHeight = false;
            this.repositoryItemTextEditResarff2.DisplayFormat.FormatString = "f2";
            this.repositoryItemTextEditResarff2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemTextEditResarff2.EditFormat.FormatString = "f2";
            this.repositoryItemTextEditResarff2.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemTextEditResarff2.Mask.EditMask = "f2";
            this.repositoryItemTextEditResarff2.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEditResarff2.Name = "repositoryItemTextEditResarff2";
            // 
            // colremarks
            // 
            this.colremarks.AppearanceCell.Options.UseTextOptions = true;
            this.colremarks.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colremarks.AppearanceHeader.Options.UseTextOptions = true;
            this.colremarks.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colremarks.Caption = "ملاحظات";
            this.colremarks.ColumnEdit = this.repositoryItemMemoExEdit2;
            this.colremarks.FieldName = "remarks";
            this.colremarks.Name = "colremarks";
            this.colremarks.Visible = true;
            this.colremarks.VisibleIndex = 4;
            // 
            // repositoryItemMemoExEdit2
            // 
            this.repositoryItemMemoExEdit2.AutoHeight = false;
            this.repositoryItemMemoExEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit2.Name = "repositoryItemMemoExEdit2";
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "تاريخ الادخال";
            this.gridColumn14.ColumnEdit = this.repositoryItemDateEdit6;
            this.gridColumn14.FieldName = "datein";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            this.gridColumn14.OptionsColumn.ReadOnly = true;
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 7;
            this.gridColumn14.Width = 108;
            // 
            // repositoryItemDateEdit6
            // 
            this.repositoryItemDateEdit6.AutoHeight = false;
            this.repositoryItemDateEdit6.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit6.DisplayFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit6.EditFormat.FormatString = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit6.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit6.Mask.EditMask = "dd/MM/yyyy - hh:mm:ss";
            this.repositoryItemDateEdit6.Name = "repositoryItemDateEdit6";
            this.repositoryItemDateEdit6.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "مسئول الادخال";
            this.gridColumn15.ColumnEdit = this.repositoryItemLookUpEdit3;
            this.gridColumn15.FieldName = "userin";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsColumn.ReadOnly = true;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 8;
            this.gridColumn15.Width = 134;
            // 
            // repositoryItemLookUpEdit3
            // 
            this.repositoryItemLookUpEdit3.AutoHeight = false;
            this.repositoryItemLookUpEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit3.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("RealName", "الاسم", 20, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center)});
            this.repositoryItemLookUpEdit3.DataSource = this.usersBindingSource;
            this.repositoryItemLookUpEdit3.DisplayMember = "RealName";
            this.repositoryItemLookUpEdit3.Name = "repositoryItemLookUpEdit3";
            this.repositoryItemLookUpEdit3.NullText = "";
            this.repositoryItemLookUpEdit3.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemLookUpEdit3.ValueMember = "UserID";
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "حفظ";
            this.gridColumn13.ColumnEdit = this.repositoryItemButtonEditResarfSave;
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 5;
            this.gridColumn13.Width = 80;
            // 
            // repositoryItemButtonEditResarfSave
            // 
            this.repositoryItemButtonEditResarfSave.AutoHeight = false;
            this.repositoryItemButtonEditResarfSave.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEditResarfSave.Name = "repositoryItemButtonEditResarfSave";
            this.repositoryItemButtonEditResarfSave.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditResarfSave.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditResarfSave_ButtonClick);
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "حذف";
            this.gridColumn12.ColumnEdit = this.repositoryItemButtonEditResarfDel;
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 6;
            // 
            // repositoryItemButtonEditResarfDel
            // 
            this.repositoryItemButtonEditResarfDel.AutoHeight = false;
            this.repositoryItemButtonEditResarfDel.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.repositoryItemButtonEditResarfDel.Name = "repositoryItemButtonEditResarfDel";
            this.repositoryItemButtonEditResarfDel.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditResarfDel.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditResarfDel_ButtonClick);
            // 
            // repositoryItemMemoEdit4
            // 
            this.repositoryItemMemoEdit4.Name = "repositoryItemMemoEdit4";
            // 
            // LSMSCDsarfType
            // 
            this.LSMSCDsarfType.ElementType = typeof(RetirementCenter.DataSources.Linq.CDsarfType);
            this.LSMSCDsarfType.KeyExpression = "[sarfTypeId]";
            // 
            // tBLEdafatBindingSource
            // 
            this.tBLEdafatBindingSource.DataMember = "TBLEdafat";
            this.tBLEdafatBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // tblMashatTableAdapter
            // 
            this.tblMashatTableAdapter.ClearBeforeFill = true;
            // 
            // tBLMashatTablebbindingSource
            // 
            this.tBLMashatTablebbindingSource.DataMember = "TBLMashat";
            this.tBLMashatTablebbindingSource.DataSource = this.dsRetirementCenter;
            // 
            // tblNoSarfDetelsTableAdapter
            // 
            this.tblNoSarfDetelsTableAdapter.ClearBeforeFill = true;
            // 
            // tBLMRemarksTableAdapter
            // 
            this.tBLMRemarksTableAdapter.ClearBeforeFill = true;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // cDEndworkTableAdapter
            // 
            this.cDEndworkTableAdapter.ClearBeforeFill = true;
            // 
            // tblMashatLOGTableAdapter
            // 
            this.tblMashatLOGTableAdapter.ClearBeforeFill = true;
            // 
            // tBLEdafatTableAdapter
            // 
            this.tBLEdafatTableAdapter.ClearBeforeFill = true;
            // 
            // tBLSyndicateTransferTableAdapter
            // 
            this.tBLSyndicateTransferTableAdapter.ClearBeforeFill = true;
            // 
            // tBLWarasaTableAdapter
            // 
            this.tBLWarasaTableAdapter.ClearBeforeFill = true;
            // 
            // tblNoSarfWarsaTableAdapter
            // 
            this.tblNoSarfWarsaTableAdapter.ClearBeforeFill = true;
            // 
            // tblEdafatWarsaTableAdapter
            // 
            this.tblEdafatWarsaTableAdapter.ClearBeforeFill = true;
            // 
            // tBLEdafatWarsaBindingSource
            // 
            this.tBLEdafatWarsaBindingSource.DataMember = "TBLEdafatWarsa";
            this.tBLEdafatWarsaBindingSource.DataSource = this.dsRetirementCenter;
            // 
            // colWarasaType
            // 
            this.colWarasaType.AppearanceCell.Options.UseTextOptions = true;
            this.colWarasaType.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWarasaType.AppearanceHeader.Options.UseTextOptions = true;
            this.colWarasaType.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWarasaType.Caption = "النوع";
            this.colWarasaType.FieldName = "WarasaType";
            this.colWarasaType.Name = "colWarasaType";
            this.colWarasaType.Visible = true;
            this.colWarasaType.VisibleIndex = 0;
            // 
            // tBLReSarfTableAdapter
            // 
            this.tBLReSarfTableAdapter.ClearBeforeFill = true;
            // 
            // TBLMashatFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 461);
            this.Controls.Add(this.xtraTabControlMain);
            this.Controls.Add(this.gcCommands);
            this.Controls.Add(this.groupControlMain);
            this.Name = "TBLMashatFrm";
            this.Text = "بيانات الاعضاء";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TBL_EmpFrm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            ((System.ComponentModel.ISupportInitialize)(this.groupControlMain)).EndInit();
            this.groupControlMain.ResumeLayout(false);
            this.groupControlMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LUEEmp.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSDATA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditSyndicateId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbMMashatName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsRetirementCenter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcCommands)).EndInit();
            this.gcCommands.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LUESubCommitteId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSubCommitte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LUESyndicateId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSyndicate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LUEMashHalaId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDMashHala)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlMain)).EndInit();
            this.xtraTabControlMain.ResumeLayout(false);
            this.xtraTabPageMain.ResumeLayout(false);
            this.xtraTabPageMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ceEnableEdafat.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlEdafat)).EndInit();
            this.pnlEdafat.ResumeLayout(false);
            this.pnlEdafat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lueDofatSarfId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSTBLDofatSarf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luesarfTypeId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbestktaa.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.defiledate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.defiledate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMashatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deWorkeEndDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deWorkeEndDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceSarfExpetion.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceyasref.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueEndworkId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDEndworkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsQueries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbMMashatNId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbKideNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbsarfnumber.Properties)).EndInit();
            this.xtraTabPageNoSarf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlTBLNoSarfDetels)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSTBLNoSarfDetels)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTBLNoSarfDetels)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            this.xtraTabPagePrivateSarf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cemcompletesarf.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlPrivateSarf)).EndInit();
            this.pnlPrivateSarf.ResumeLayout(false);
            this.pnlPrivateSarf.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbmelrasm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmmony.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmestktaat.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmeshtrakat.Properties)).EndInit();
            this.xtraTabPageRemarks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlRemarks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMRemarksBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewRemarks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditeRemarkuserin)).EndInit();
            this.xtraTabPageSyndicateTransfer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlSyndicateTransfer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLSyndicateTransferBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSyndicateTransfer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSyndicateId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSyndicateTransfer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSubCommitteId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDSubCommitteTransfer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEditTransferrem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit4.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditTransferSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).EndInit();
            this.xtraTabPageWarasa.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlTBLWarasa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLWarasaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTBLWarasa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasaWarasaTypeId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDWarasaType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditWarasaDMY.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditWarasaDMY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasaSyndicateId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasaSubCommitteId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaQuickSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaDel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit5.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditWarasauserin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaSarf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditWarasaRemark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditresponsiblesarfId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSTBLWarasa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).EndInit();
            this.xtraTabPageChangeToWarasa.ResumeLayout(false);
            this.xtraTabPageChangeToWarasa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LUEChangeHala.Properties)).EndInit();
            this.xtraTabPageReSarf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlResarf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLReSarfBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewResarf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditDofatSarfId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditResarfDMY.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditResarfDMY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEditResarff2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit6.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditResarfSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditResarfDel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LSMSCDsarfType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLEdafatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProviderMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMashatTablebbindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblNoSarfDetelsTablebindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProviderEdafat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLEdafatWarsaBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton btnDelete;
        private DevExpress.XtraEditors.SimpleButton btnNew;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit tbMMashatName;
        private DevExpress.XtraEditors.GroupControl gcCommands;
        private DevExpress.XtraEditors.SimpleButton btnUpdate;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraGrid.Views.Grid.GridView gridLookUpEdit1View;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LookUpEdit LUESubCommitteId;
        private DevExpress.XtraEditors.LookUpEdit LUESyndicateId;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LookUpEdit LUEMashHalaId;
        private DevExpress.XtraTab.XtraTabControl xtraTabControlMain;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageMain;
        public DevExpress.XtraEditors.GroupControl groupControlMain;
        public DevExpress.XtraEditors.GridLookUpEdit LUEEmp;
        private DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider dxValidationProviderMain;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit tbMMashatNId;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditSyndicateId;
        private DevExpress.XtraEditors.TextEdit tbsarfnumber;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.CheckEdit ceyasref;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageNoSarf;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSDATA;
        private DevExpress.XtraGrid.Columns.GridColumn colMMashatName;
        private DevExpress.XtraGrid.Columns.GridColumn colSyndicate;
        private DevExpress.XtraGrid.Columns.GridColumn colSubCommitte;
        private DevExpress.XtraGrid.Columns.GridColumn colsarfnumber;
        private DevExpress.XtraGrid.Columns.GridColumn colMashHala;
        private DevExpress.XtraGrid.Columns.GridColumn colyasref;
        private DevExpress.XtraGrid.Columns.GridColumn colMMashatNId;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSCDSyndicate;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSCDSubCommitte;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSCDMashHala;
        private DataSources.dsRetirementCenter dsRetirementCenter;
        private DataSources.dsRetirementCenterTableAdapters.TBLMashatTableAdapter tblMashatTableAdapter;
        private System.Windows.Forms.BindingSource tBLMashatTablebbindingSource;
        private DataSources.dsRetirementCenterTableAdapters.TBLNoSarfDetelsTableAdapter tblNoSarfDetelsTableAdapter;
        private System.Windows.Forms.BindingSource tblNoSarfDetelsTablebindingSource;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageRemarks;
        private DevExpress.XtraGrid.GridControl gridControlRemarks;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewRemarks;
        private System.Windows.Forms.BindingSource tBLMRemarksBindingSource;
        private DataSources.dsRetirementCenterTableAdapters.TBLMRemarksTableAdapter tBLMRemarksTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn colmewmark;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSave;
        private DevExpress.XtraGrid.GridControl gridControlTBLNoSarfDetels;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewTBLNoSarfDetels;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSTBLNoSarfDetels;
        private DevExpress.XtraGrid.Columns.GridColumn coldatehala;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn coldatein;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn coluserin;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditeRemarkuserin;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private DataSources.dsRetirementCenterTableAdapters.UsersTableAdapter usersTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn colyasref1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn coldatein1;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn coluserin1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraEditors.DateEdit deWorkeEndDate;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LookUpEdit lueEndworkId;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit tbKideNumber;
        private DataSources.dsQueries dsQueries;
        private System.Windows.Forms.BindingSource cDEndworkBindingSource;
        private DataSources.dsQueriesTableAdapters.CDEndworkTableAdapter cDEndworkTableAdapter;
        private DevExpress.XtraEditors.DateEdit defiledate;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private System.Windows.Forms.BindingSource tBLMashatBindingSource;
        private DataSources.dsRetirementCenterTableAdapters.TBLMashatLOGTableAdapter tblMashatLOGTableAdapter;
        private System.Windows.Forms.BindingSource tBLEdafatBindingSource;
        private DataSources.dsRetirementCenterTableAdapters.TBLEdafatTableAdapter tBLEdafatTableAdapter;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSTBLDofatSarf;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSCDsarfType;
        private DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider dxValidationProviderEdafat;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageSyndicateTransfer;
        private DevExpress.XtraGrid.GridControl gridControlSyndicateTransfer;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewSyndicateTransfer;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditTransferSave;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit2;
        private System.Windows.Forms.BindingSource tBLSyndicateTransferBindingSource;
        private DataSources.dsRetirementCenterTableAdapters.TBLSyndicateTransferTableAdapter tBLSyndicateTransferTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn colNewSyndicateId;
        private DevExpress.XtraGrid.Columns.GridColumn colNewSubCommitteId;
        private DevExpress.XtraGrid.Columns.GridColumn colOldSubCommitteId;
        private DevExpress.XtraGrid.Columns.GridColumn colOldSyndicateId;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditSyndicateId;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit1View;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditSubCommitteId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn colTransferDate;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSCDSyndicateTransfer;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSCDSubCommitteTransfer;
        private DevExpress.XtraGrid.Columns.GridColumn colSyndicate1;
        private DevExpress.XtraGrid.Columns.GridColumn colSubCommitte1;
        private DevExpress.XtraGrid.Columns.GridColumn colTransferrem;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEditTransferrem;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit textEdit2;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageWarasa;
        private DevExpress.XtraGrid.GridControl gridControlTBLWarasa;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewTBLWarasa;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditWarasaEdit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit5;
        private System.Windows.Forms.BindingSource tBLWarasaBindingSource;
        private DataSources.dsRetirementCenterTableAdapters.TBLWarasaTableAdapter tBLWarasaTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn colpersonName;
        private DevExpress.XtraGrid.Columns.GridColumn colpersonNID;
        private DevExpress.XtraGrid.Columns.GridColumn colpersonbirth;
        private DevExpress.XtraGrid.Columns.GridColumn colpersonmobile;
        private DevExpress.XtraGrid.Columns.GridColumn colpersonAddres;
        private DevExpress.XtraGrid.Columns.GridColumn colyasref2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditWarasaDel;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEditWarasaDMY;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSCDWarasaType;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.SimpleButton btnAddTBLWarasa;
        private DataSources.dsRetirementCenterTableAdapters.TBLNoSarfWarsaTableAdapter tblNoSarfWarsaTableAdapter;
        private DevExpress.Data.Linq.LinqServerModeSource LSMSTBLWarasa;
        private DevExpress.XtraGrid.Columns.GridColumn colWarasaType1;
        private DevExpress.XtraGrid.Columns.GridColumn colRealName;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditWarasaSarf;
        private DataSources.dsRetirementCenterTableAdapters.TBLEdafatWarsaTableAdapter tblEdafatWarsaTableAdapter;
        private System.Windows.Forms.BindingSource tBLEdafatWarsaBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditWarasaQuickSave;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditWarasaWarasaTypeId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditWarasauserin;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraGrid.Columns.GridColumn colWarasaType;
        private DevExpress.XtraEditors.CheckEdit ceEnableEdafat;
        private DevExpress.XtraEditors.PanelControl pnlEdafat;
        private DevExpress.XtraEditors.LookUpEdit lueDofatSarfId;
        private DevExpress.XtraEditors.LookUpEdit luesarfTypeId;
        private DevExpress.XtraEditors.TextEdit tbestktaa;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraGrid.Columns.GridColumn colSyndicateId;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditWarasaSyndicateId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private DevExpress.XtraGrid.Columns.GridColumn colSyndicate2;
        private DevExpress.XtraGrid.Columns.GridColumn colSubCommitteId;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditWarasaSubCommitteId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView5;
        private DevExpress.XtraGrid.Columns.GridColumn colSubCommitte2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditWarasaRemark;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageChangeToWarasa;
        private DevExpress.XtraEditors.LookUpEdit LUEChangeHala;
        private DevExpress.XtraEditors.SimpleButton btnChangeHala;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraGrid.Columns.GridColumn colresponsiblesarf;
        private DevExpress.XtraGrid.Columns.GridColumn colresponsiblesarfId;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditresponsiblesarfId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView6;
        private DevExpress.XtraGrid.Columns.GridColumn colpersonName1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageReSarf;
        private DevExpress.XtraGrid.GridControl gridControlResarf;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewResarf;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditResarfSave;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit3;
        private System.Windows.Forms.BindingSource tBLReSarfBindingSource;
        private DataSources.dsRetirementCenterTableAdapters.TBLReSarfTableAdapter tBLReSarfTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditResarfDel;
        private DevExpress.XtraGrid.Columns.GridColumn colDofatSarfId;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditDofatSarfId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView7;
        private DevExpress.XtraGrid.Columns.GridColumn colDofatSarf;
        private DevExpress.XtraGrid.Columns.GridColumn coldatefrom;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEditResarfDMY;
        private DevExpress.XtraGrid.Columns.GridColumn coldateto;
        private DevExpress.XtraGrid.Columns.GridColumn colreestktaa;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEditResarff2;
        private DevExpress.XtraGrid.Columns.GridColumn colremarks;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit2;
        private DevExpress.XtraEditors.CheckEdit ceSarfExpetion;
        private DevExpress.XtraTab.XtraTabPage xtraTabPagePrivateSarf;
        private DevExpress.XtraEditors.CheckEdit cemcompletesarf;
        private DevExpress.XtraEditors.PanelControl pnlPrivateSarf;
        private DevExpress.XtraEditors.TextEdit tbmelrasm;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.TextEdit tbmestktaat;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.TextEdit tbmeshtrakat;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit tbmmony;
        private DevExpress.XtraEditors.LabelControl labelControl20;
    }
}