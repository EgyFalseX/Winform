﻿namespace RetirementCenter.DataSources {
    
    
    public partial class dsQueries {
    }
}
