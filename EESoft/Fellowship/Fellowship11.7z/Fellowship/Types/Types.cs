﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fellowship.Types
{
    public enum TablesNames
    {
        All,
        CDSyndicate,
        CDModerea,
        CDEDARET,
        CDMonth,
        TBLEdaraMandop,
        TBLNkapaMandop,
        TBLSheekWared,
        CDState,
        CDJob,
        CDAttach,
        TblMember,
        TblSarf
    }

}
