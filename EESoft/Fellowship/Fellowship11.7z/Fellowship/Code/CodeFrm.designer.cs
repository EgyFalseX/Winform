﻿namespace Fellowship
{
    partial class CodeFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode2 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode3 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode4 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode5 = new DevExpress.XtraGrid.GridLevelNode();
            this.gridViewCDEDARET = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditModereaId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.cDModereaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dSFellowship = new Fellowship.DataSources.DSFellowship();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn56 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditSyndicateId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.cDSyndicateBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView5 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn60 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSave = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditDel = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridControlCode = new DevExpress.XtraGrid.GridControl();
            this.cDAttachBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewCDModerea = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewCDState = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewCDJob = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewCDAttach = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewCDSyndicate = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn106 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn116 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn117 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEditCheckMe = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemGridLookUpEditSPOS = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn112 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn113 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditqualId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn36 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditPayTypeId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.repositoryItemGridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn54 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditalsofof_code = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.repositoryItemCalcEditf2 = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.repositoryItemGridLookUpEditKastNoId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView6 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditmarhala_code = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView8 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn64 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn65 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditdaycode = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView9 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn67 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn68 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEdithasa_code = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView10 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn69 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn70 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTimeEditT = new DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit();
            this.repositoryItemGridLookUpEditSubjectId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView11 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn71 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn73 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCalcEditn0 = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.repositoryItemGridLookUpEditEmpID = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView12 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn75 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEditBigTxt = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.repositoryItemGridLookUpEditfasl_code = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView13 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn80 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn81 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditEsthkakTypeId = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn62 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCalcEditPer = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.cDJobBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cDStateBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cDEDARETBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridColumn57 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn84 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cDSyndicateTableAdapter = new Fellowship.DataSources.DSFellowshipTableAdapters.CDSyndicateTableAdapter();
            this.cDEDARETTableAdapter = new Fellowship.DataSources.DSFellowshipTableAdapters.CDEDARETTableAdapter();
            this.cDModereaTableAdapter = new Fellowship.DataSources.DSFellowshipTableAdapters.CDModereaTableAdapter();
            this.cDStateTableAdapter = new Fellowship.DataSources.DSFellowshipTableAdapters.CDStateTableAdapter();
            this.cDJobTableAdapter = new Fellowship.DataSources.DSFellowshipTableAdapters.CDJobTableAdapter();
            this.cDAttachTableAdapter = new Fellowship.DataSources.DSFellowshipTableAdapters.CDAttachTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDEDARET)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditModereaId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDModereaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSFellowship)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSyndicateId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDSyndicateBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditDel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDAttachBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDModerea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDJob)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDAttach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDSyndicate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEditCheckMe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSPOS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditqualId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditPayTypeId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditalsofof_code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEditf2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditKastNoId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditmarhala_code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditdaycode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdithasa_code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEditT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSubjectId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEditn0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditEmpID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEditBigTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditfasl_code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditEsthkakTypeId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEditPer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDJobBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDStateBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDEDARETBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // gridViewCDEDARET
            // 
            this.gridViewCDEDARET.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn3,
            this.gridColumn4});
            this.gridViewCDEDARET.GridControl = this.gridControlCode;
            this.gridViewCDEDARET.Name = "gridViewCDEDARET";
            this.gridViewCDEDARET.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewCDEDARET.OptionsView.ColumnAutoWidth = false;
            this.gridViewCDEDARET.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            this.gridViewCDEDARET.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(this.gridViewX_InvalidRowException);
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "اسم الادارة";
            this.gridColumn2.FieldName = "EDARET";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            this.gridColumn2.Width = 222;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "اسم المديرية";
            this.gridColumn8.ColumnEdit = this.repositoryItemGridLookUpEditModereaId;
            this.gridColumn8.FieldName = "ModereaId";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 1;
            this.gridColumn8.Width = 109;
            // 
            // repositoryItemGridLookUpEditModereaId
            // 
            this.repositoryItemGridLookUpEditModereaId.AutoHeight = false;
            this.repositoryItemGridLookUpEditModereaId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditModereaId.DataSource = this.cDModereaBindingSource;
            this.repositoryItemGridLookUpEditModereaId.DisplayMember = "Moderea";
            this.repositoryItemGridLookUpEditModereaId.Name = "repositoryItemGridLookUpEditModereaId";
            this.repositoryItemGridLookUpEditModereaId.NullText = "";
            this.repositoryItemGridLookUpEditModereaId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditModereaId.ValueMember = "ModereaId";
            this.repositoryItemGridLookUpEditModereaId.View = this.gridView2;
            // 
            // cDModereaBindingSource
            // 
            this.cDModereaBindingSource.DataMember = "CDModerea";
            this.cDModereaBindingSource.DataSource = this.dSFellowship;
            // 
            // dSFellowship
            // 
            this.dSFellowship.DataSetName = "DSFellowship";
            this.dSFellowship.Locale = new System.Globalization.CultureInfo("en-US");
            this.dSFellowship.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gridView2
            // 
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn56});
            this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn56
            // 
            this.gridColumn56.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn56.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn56.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn56.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn56.Caption = "اسم المديرية";
            this.gridColumn56.FieldName = "Moderea";
            this.gridColumn56.Name = "gridColumn56";
            this.gridColumn56.Visible = true;
            this.gridColumn56.VisibleIndex = 0;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "اسم النقابة";
            this.gridColumn9.ColumnEdit = this.repositoryItemGridLookUpEditSyndicateId;
            this.gridColumn9.FieldName = "SyndicateId";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 2;
            this.gridColumn9.Width = 104;
            // 
            // repositoryItemGridLookUpEditSyndicateId
            // 
            this.repositoryItemGridLookUpEditSyndicateId.AutoHeight = false;
            this.repositoryItemGridLookUpEditSyndicateId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditSyndicateId.DataSource = this.cDSyndicateBindingSource;
            this.repositoryItemGridLookUpEditSyndicateId.DisplayMember = "Syndicate";
            this.repositoryItemGridLookUpEditSyndicateId.Name = "repositoryItemGridLookUpEditSyndicateId";
            this.repositoryItemGridLookUpEditSyndicateId.NullText = "";
            this.repositoryItemGridLookUpEditSyndicateId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditSyndicateId.ValueMember = "SyndicateId";
            this.repositoryItemGridLookUpEditSyndicateId.View = this.gridView5;
            // 
            // cDSyndicateBindingSource
            // 
            this.cDSyndicateBindingSource.DataMember = "CDSyndicate";
            this.cDSyndicateBindingSource.DataSource = this.dSFellowship;
            // 
            // gridView5
            // 
            this.gridView5.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn60});
            this.gridView5.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView5.Name = "gridView5";
            this.gridView5.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView5.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn60
            // 
            this.gridColumn60.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn60.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn60.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn60.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn60.Caption = "اسم النقابة";
            this.gridColumn60.FieldName = "Syndicate";
            this.gridColumn60.Name = "gridColumn60";
            this.gridColumn60.Visible = true;
            this.gridColumn60.VisibleIndex = 0;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "حفظ";
            this.gridColumn3.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 3;
            // 
            // repositoryItemButtonEditSave
            // 
            this.repositoryItemButtonEditSave.AutoHeight = false;
            this.repositoryItemButtonEditSave.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEditSave.Name = "repositoryItemButtonEditSave";
            this.repositoryItemButtonEditSave.Tag = "save";
            this.repositoryItemButtonEditSave.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSave.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSave_ButtonClick);
            this.repositoryItemButtonEditSave.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "حذف";
            this.gridColumn4.ColumnEdit = this.repositoryItemButtonEditDel;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            // 
            // repositoryItemButtonEditDel
            // 
            this.repositoryItemButtonEditDel.AutoHeight = false;
            this.repositoryItemButtonEditDel.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.repositoryItemButtonEditDel.Name = "repositoryItemButtonEditDel";
            this.repositoryItemButtonEditDel.Tag = "delete";
            this.repositoryItemButtonEditDel.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditDel.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditDel_ButtonClick);
            this.repositoryItemButtonEditDel.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // gridControlCode
            // 
            this.gridControlCode.DataSource = this.cDAttachBindingSource;
            this.gridControlCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlCode.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlCode.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlCode.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlCode.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gridControlCode.EmbeddedNavigator.ButtonClick += new DevExpress.XtraEditors.NavigatorButtonClickEventHandler(this.gridControlCode_EmbeddedNavigator_ButtonClick);
            gridLevelNode1.LevelTemplate = this.gridViewCDEDARET;
            gridLevelNode1.RelationName = "Level1";
            gridLevelNode2.LevelTemplate = this.gridViewCDModerea;
            gridLevelNode2.RelationName = "Level2";
            gridLevelNode3.LevelTemplate = this.gridViewCDState;
            gridLevelNode3.RelationName = "Level3";
            gridLevelNode4.LevelTemplate = this.gridViewCDJob;
            gridLevelNode4.RelationName = "Level4";
            gridLevelNode5.LevelTemplate = this.gridViewCDAttach;
            gridLevelNode5.RelationName = "Level5";
            this.gridControlCode.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1,
            gridLevelNode2,
            gridLevelNode3,
            gridLevelNode4,
            gridLevelNode5});
            this.gridControlCode.Location = new System.Drawing.Point(0, 0);
            this.gridControlCode.MainView = this.gridViewCDSyndicate;
            this.gridControlCode.Name = "gridControlCode";
            this.gridControlCode.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditSave,
            this.repositoryItemButtonEditDel,
            this.repositoryItemCheckEditCheckMe,
            this.repositoryItemGridLookUpEditSPOS,
            this.repositoryItemGridLookUpEditqualId,
            this.repositoryItemGridLookUpEditPayTypeId,
            this.repositoryItemGridLookUpEditalsofof_code,
            this.repositoryItemCalcEditf2,
            this.repositoryItemGridLookUpEditKastNoId,
            this.repositoryItemGridLookUpEditmarhala_code,
            this.repositoryItemGridLookUpEditdaycode,
            this.repositoryItemGridLookUpEdithasa_code,
            this.repositoryItemTimeEditT,
            this.repositoryItemGridLookUpEditSubjectId,
            this.repositoryItemCalcEditn0,
            this.repositoryItemGridLookUpEditEmpID,
            this.repositoryItemMemoExEditBigTxt,
            this.repositoryItemGridLookUpEditfasl_code,
            this.repositoryItemGridLookUpEditEsthkakTypeId,
            this.repositoryItemCalcEditPer,
            this.repositoryItemGridLookUpEditModereaId,
            this.repositoryItemGridLookUpEditSyndicateId});
            this.gridControlCode.Size = new System.Drawing.Size(534, 362);
            this.gridControlCode.TabIndex = 0;
            this.gridControlCode.UseEmbeddedNavigator = true;
            this.gridControlCode.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewCDModerea,
            this.gridViewCDState,
            this.gridViewCDJob,
            this.gridViewCDAttach,
            this.gridViewCDSyndicate,
            this.gridViewCDEDARET});
            this.gridControlCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // cDAttachBindingSource
            // 
            this.cDAttachBindingSource.DataMember = "CDAttach";
            this.cDAttachBindingSource.DataSource = this.dSFellowship;
            // 
            // gridViewCDModerea
            // 
            this.gridViewCDModerea.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn5,
            this.gridColumn10,
            this.gridColumn11});
            this.gridViewCDModerea.GridControl = this.gridControlCode;
            this.gridViewCDModerea.Name = "gridViewCDModerea";
            this.gridViewCDModerea.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewCDModerea.OptionsView.ColumnAutoWidth = false;
            this.gridViewCDModerea.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            this.gridViewCDModerea.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(this.gridViewX_InvalidRowException);
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "اسم المديرية";
            this.gridColumn5.FieldName = "Moderea";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 0;
            this.gridColumn5.Width = 160;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "حفظ";
            this.gridColumn10.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 1;
            this.gridColumn10.Width = 68;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.Caption = "حذف";
            this.gridColumn11.ColumnEdit = this.repositoryItemButtonEditDel;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 2;
            this.gridColumn11.Width = 54;
            // 
            // gridViewCDState
            // 
            this.gridViewCDState.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn6,
            this.gridColumn7});
            this.gridViewCDState.GridControl = this.gridControlCode;
            this.gridViewCDState.Name = "gridViewCDState";
            this.gridViewCDState.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewCDState.OptionsView.ColumnAutoWidth = false;
            this.gridViewCDState.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "اسم النوع";
            this.gridColumn1.FieldName = "StateName";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 206;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "حفظ";
            this.gridColumn6.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 1;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "حذف";
            this.gridColumn7.ColumnEdit = this.repositoryItemButtonEditDel;
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 2;
            // 
            // gridViewCDJob
            // 
            this.gridViewCDJob.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14});
            this.gridViewCDJob.GridControl = this.gridControlCode;
            this.gridViewCDJob.Name = "gridViewCDJob";
            this.gridViewCDJob.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewCDJob.OptionsView.ColumnAutoWidth = false;
            this.gridViewCDJob.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "اسم الوظيفة";
            this.gridColumn12.FieldName = "Jobtitle";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 0;
            this.gridColumn12.Width = 203;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "حفظ";
            this.gridColumn13.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 1;
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "حذف";
            this.gridColumn14.ColumnEdit = this.repositoryItemButtonEditDel;
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 2;
            // 
            // gridViewCDAttach
            // 
            this.gridViewCDAttach.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn15,
            this.gridColumn16,
            this.gridColumn17});
            this.gridViewCDAttach.GridControl = this.gridControlCode;
            this.gridViewCDAttach.Name = "gridViewCDAttach";
            this.gridViewCDAttach.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewCDAttach.OptionsView.ColumnAutoWidth = false;
            this.gridViewCDAttach.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            this.gridViewCDAttach.OptionsView.ShowDetailButtons = false;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "اسم المرفق";
            this.gridColumn15.FieldName = "AttachName";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 0;
            this.gridColumn15.Width = 187;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "حفظ";
            this.gridColumn16.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 1;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "حذف";
            this.gridColumn17.ColumnEdit = this.repositoryItemButtonEditDel;
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 2;
            // 
            // gridViewCDSyndicate
            // 
            this.gridViewCDSyndicate.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn106,
            this.gridColumn116,
            this.gridColumn117});
            this.gridViewCDSyndicate.GridControl = this.gridControlCode;
            this.gridViewCDSyndicate.Name = "gridViewCDSyndicate";
            this.gridViewCDSyndicate.NewItemRowText = "اضغط لاضافة جديد";
            this.gridViewCDSyndicate.OptionsNavigation.AutoFocusNewRow = true;
            this.gridViewCDSyndicate.OptionsView.ColumnAutoWidth = false;
            this.gridViewCDSyndicate.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top;
            this.gridViewCDSyndicate.OptionsView.ShowDetailButtons = false;
            this.gridViewCDSyndicate.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(this.gridViewX_InvalidRowException);
            // 
            // gridColumn106
            // 
            this.gridColumn106.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn106.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn106.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn106.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn106.Caption = "اسم النقابة";
            this.gridColumn106.FieldName = "Syndicate";
            this.gridColumn106.Name = "gridColumn106";
            this.gridColumn106.Visible = true;
            this.gridColumn106.VisibleIndex = 0;
            this.gridColumn106.Width = 243;
            // 
            // gridColumn116
            // 
            this.gridColumn116.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn116.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn116.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn116.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn116.Caption = "حفظ";
            this.gridColumn116.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn116.Name = "gridColumn116";
            this.gridColumn116.Visible = true;
            this.gridColumn116.VisibleIndex = 1;
            this.gridColumn116.Width = 69;
            // 
            // gridColumn117
            // 
            this.gridColumn117.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn117.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn117.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn117.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn117.Caption = "حذف";
            this.gridColumn117.ColumnEdit = this.repositoryItemButtonEditDel;
            this.gridColumn117.Name = "gridColumn117";
            this.gridColumn117.Visible = true;
            this.gridColumn117.VisibleIndex = 2;
            this.gridColumn117.Width = 63;
            // 
            // repositoryItemCheckEditCheckMe
            // 
            this.repositoryItemCheckEditCheckMe.AutoHeight = false;
            this.repositoryItemCheckEditCheckMe.Name = "repositoryItemCheckEditCheckMe";
            this.repositoryItemCheckEditCheckMe.ValueGrayed = false;
            this.repositoryItemCheckEditCheckMe.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ActiveKeyDownEvent);
            // 
            // repositoryItemGridLookUpEditSPOS
            // 
            this.repositoryItemGridLookUpEditSPOS.AutoHeight = false;
            this.repositoryItemGridLookUpEditSPOS.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditSPOS.DisplayMember = "school_allname";
            this.repositoryItemGridLookUpEditSPOS.Name = "repositoryItemGridLookUpEditSPOS";
            this.repositoryItemGridLookUpEditSPOS.NullText = "";
            this.repositoryItemGridLookUpEditSPOS.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditSPOS.ValueMember = "school_allcode";
            this.repositoryItemGridLookUpEditSPOS.View = this.gridView3;
            // 
            // gridView3
            // 
            this.gridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn112,
            this.gridColumn113});
            this.gridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView3.Name = "gridView3";
            this.gridView3.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView3.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn112
            // 
            this.gridColumn112.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn112.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn112.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn112.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn112.Caption = "اسم المدرسه بالعربيه";
            this.gridColumn112.FieldName = "school_allname";
            this.gridColumn112.Name = "gridColumn112";
            this.gridColumn112.Visible = true;
            this.gridColumn112.VisibleIndex = 0;
            // 
            // gridColumn113
            // 
            this.gridColumn113.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn113.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn113.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn113.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn113.Caption = "اسم المدرسه بالانجليزيه";
            this.gridColumn113.FieldName = "school_allname_e";
            this.gridColumn113.Name = "gridColumn113";
            this.gridColumn113.Visible = true;
            this.gridColumn113.VisibleIndex = 1;
            // 
            // repositoryItemGridLookUpEditqualId
            // 
            this.repositoryItemGridLookUpEditqualId.AutoHeight = false;
            this.repositoryItemGridLookUpEditqualId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditqualId.DisplayMember = "qualName";
            this.repositoryItemGridLookUpEditqualId.Name = "repositoryItemGridLookUpEditqualId";
            this.repositoryItemGridLookUpEditqualId.NullText = "";
            this.repositoryItemGridLookUpEditqualId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditqualId.ValueMember = "qualId";
            this.repositoryItemGridLookUpEditqualId.View = this.gridView4;
            // 
            // gridView4
            // 
            this.gridView4.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn36});
            this.gridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView4.Name = "gridView4";
            this.gridView4.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView4.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn36
            // 
            this.gridColumn36.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn36.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn36.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn36.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn36.Caption = "المؤهل";
            this.gridColumn36.FieldName = "qualName";
            this.gridColumn36.Name = "gridColumn36";
            this.gridColumn36.Visible = true;
            this.gridColumn36.VisibleIndex = 0;
            // 
            // repositoryItemGridLookUpEditPayTypeId
            // 
            this.repositoryItemGridLookUpEditPayTypeId.AutoHeight = false;
            this.repositoryItemGridLookUpEditPayTypeId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditPayTypeId.DisplayMember = "PayType";
            this.repositoryItemGridLookUpEditPayTypeId.Name = "repositoryItemGridLookUpEditPayTypeId";
            this.repositoryItemGridLookUpEditPayTypeId.NullText = "";
            this.repositoryItemGridLookUpEditPayTypeId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditPayTypeId.ValueMember = "PayTypeId";
            this.repositoryItemGridLookUpEditPayTypeId.View = this.repositoryItemGridLookUpEdit1View;
            // 
            // repositoryItemGridLookUpEdit1View
            // 
            this.repositoryItemGridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn54});
            this.repositoryItemGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemGridLookUpEdit1View.Name = "repositoryItemGridLookUpEdit1View";
            this.repositoryItemGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemGridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn54
            // 
            this.gridColumn54.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn54.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn54.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn54.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn54.Caption = "الاسم";
            this.gridColumn54.FieldName = "PayType";
            this.gridColumn54.Name = "gridColumn54";
            this.gridColumn54.Visible = true;
            this.gridColumn54.VisibleIndex = 0;
            // 
            // repositoryItemGridLookUpEditalsofof_code
            // 
            this.repositoryItemGridLookUpEditalsofof_code.AutoHeight = false;
            this.repositoryItemGridLookUpEditalsofof_code.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditalsofof_code.DisplayMember = "alsofof_name";
            this.repositoryItemGridLookUpEditalsofof_code.Name = "repositoryItemGridLookUpEditalsofof_code";
            this.repositoryItemGridLookUpEditalsofof_code.NullText = "";
            this.repositoryItemGridLookUpEditalsofof_code.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditalsofof_code.ValueMember = "alsofof_code";
            // 
            // repositoryItemCalcEditf2
            // 
            this.repositoryItemCalcEditf2.AutoHeight = false;
            this.repositoryItemCalcEditf2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemCalcEditf2.DisplayFormat.FormatString = "f2";
            this.repositoryItemCalcEditf2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemCalcEditf2.EditFormat.FormatString = "f2";
            this.repositoryItemCalcEditf2.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemCalcEditf2.Mask.EditMask = "f2";
            this.repositoryItemCalcEditf2.Name = "repositoryItemCalcEditf2";
            // 
            // repositoryItemGridLookUpEditKastNoId
            // 
            this.repositoryItemGridLookUpEditKastNoId.AutoHeight = false;
            this.repositoryItemGridLookUpEditKastNoId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditKastNoId.DisplayMember = "KastName";
            this.repositoryItemGridLookUpEditKastNoId.Name = "repositoryItemGridLookUpEditKastNoId";
            this.repositoryItemGridLookUpEditKastNoId.NullText = "";
            this.repositoryItemGridLookUpEditKastNoId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditKastNoId.ValueMember = "KastNoId";
            this.repositoryItemGridLookUpEditKastNoId.View = this.gridView6;
            // 
            // gridView6
            // 
            this.gridView6.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn23});
            this.gridView6.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView6.Name = "gridView6";
            this.gridView6.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView6.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn23
            // 
            this.gridColumn23.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.Caption = "القســـــــط";
            this.gridColumn23.FieldName = "KastName";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 0;
            // 
            // repositoryItemGridLookUpEditmarhala_code
            // 
            this.repositoryItemGridLookUpEditmarhala_code.AutoHeight = false;
            this.repositoryItemGridLookUpEditmarhala_code.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditmarhala_code.DisplayMember = "marhala_name";
            this.repositoryItemGridLookUpEditmarhala_code.Name = "repositoryItemGridLookUpEditmarhala_code";
            this.repositoryItemGridLookUpEditmarhala_code.NullText = "";
            this.repositoryItemGridLookUpEditmarhala_code.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditmarhala_code.ValueMember = "marhala_code";
            this.repositoryItemGridLookUpEditmarhala_code.View = this.gridView8;
            // 
            // gridView8
            // 
            this.gridView8.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn64,
            this.gridColumn65});
            this.gridView8.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView8.Name = "gridView8";
            this.gridView8.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView8.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn64
            // 
            this.gridColumn64.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn64.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn64.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn64.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn64.Caption = "الاسم بالعربيه";
            this.gridColumn64.FieldName = "marhala_name";
            this.gridColumn64.Name = "gridColumn64";
            this.gridColumn64.Visible = true;
            this.gridColumn64.VisibleIndex = 0;
            // 
            // gridColumn65
            // 
            this.gridColumn65.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn65.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn65.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn65.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn65.Caption = "الاسم بالانجليزيه";
            this.gridColumn65.FieldName = "marhala_name_e";
            this.gridColumn65.Name = "gridColumn65";
            this.gridColumn65.Visible = true;
            this.gridColumn65.VisibleIndex = 1;
            // 
            // repositoryItemGridLookUpEditdaycode
            // 
            this.repositoryItemGridLookUpEditdaycode.AutoHeight = false;
            this.repositoryItemGridLookUpEditdaycode.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditdaycode.DisplayMember = "dayname";
            this.repositoryItemGridLookUpEditdaycode.Name = "repositoryItemGridLookUpEditdaycode";
            this.repositoryItemGridLookUpEditdaycode.NullText = "";
            this.repositoryItemGridLookUpEditdaycode.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditdaycode.ValueMember = "daycode";
            this.repositoryItemGridLookUpEditdaycode.View = this.gridView9;
            // 
            // gridView9
            // 
            this.gridView9.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn67,
            this.gridColumn68});
            this.gridView9.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView9.Name = "gridView9";
            this.gridView9.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView9.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn67
            // 
            this.gridColumn67.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn67.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn67.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn67.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn67.Caption = "اليوم بالعربيه";
            this.gridColumn67.FieldName = "dayname";
            this.gridColumn67.Name = "gridColumn67";
            this.gridColumn67.Visible = true;
            this.gridColumn67.VisibleIndex = 0;
            // 
            // gridColumn68
            // 
            this.gridColumn68.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn68.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn68.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn68.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn68.Caption = "اليوم بالانجليزيه";
            this.gridColumn68.FieldName = "dayname_e";
            this.gridColumn68.Name = "gridColumn68";
            this.gridColumn68.Visible = true;
            this.gridColumn68.VisibleIndex = 1;
            // 
            // repositoryItemGridLookUpEdithasa_code
            // 
            this.repositoryItemGridLookUpEdithasa_code.AutoHeight = false;
            this.repositoryItemGridLookUpEdithasa_code.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEdithasa_code.DisplayMember = "hasa_name";
            this.repositoryItemGridLookUpEdithasa_code.Name = "repositoryItemGridLookUpEdithasa_code";
            this.repositoryItemGridLookUpEdithasa_code.NullText = "";
            this.repositoryItemGridLookUpEdithasa_code.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEdithasa_code.ValueMember = "hasa_code";
            this.repositoryItemGridLookUpEdithasa_code.View = this.gridView10;
            // 
            // gridView10
            // 
            this.gridView10.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn69,
            this.gridColumn70});
            this.gridView10.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView10.Name = "gridView10";
            this.gridView10.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView10.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn69
            // 
            this.gridColumn69.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn69.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn69.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn69.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn69.Caption = "الحصه بالعربيه";
            this.gridColumn69.FieldName = "hasa_name";
            this.gridColumn69.Name = "gridColumn69";
            this.gridColumn69.Visible = true;
            this.gridColumn69.VisibleIndex = 0;
            // 
            // gridColumn70
            // 
            this.gridColumn70.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn70.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn70.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn70.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn70.Caption = "الحصه بالانجليزيه";
            this.gridColumn70.FieldName = "hasa_name_e";
            this.gridColumn70.Name = "gridColumn70";
            this.gridColumn70.Visible = true;
            this.gridColumn70.VisibleIndex = 1;
            // 
            // repositoryItemTimeEditT
            // 
            this.repositoryItemTimeEditT.AutoHeight = false;
            this.repositoryItemTimeEditT.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemTimeEditT.DisplayFormat.FormatString = "hh:mm:ss t";
            this.repositoryItemTimeEditT.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemTimeEditT.EditFormat.FormatString = "hh:mm:ss t";
            this.repositoryItemTimeEditT.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemTimeEditT.Mask.EditMask = "hh:mm:ss t";
            this.repositoryItemTimeEditT.Name = "repositoryItemTimeEditT";
            // 
            // repositoryItemGridLookUpEditSubjectId
            // 
            this.repositoryItemGridLookUpEditSubjectId.AutoHeight = false;
            this.repositoryItemGridLookUpEditSubjectId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditSubjectId.DisplayMember = "Subject";
            this.repositoryItemGridLookUpEditSubjectId.Name = "repositoryItemGridLookUpEditSubjectId";
            this.repositoryItemGridLookUpEditSubjectId.NullText = "";
            this.repositoryItemGridLookUpEditSubjectId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditSubjectId.ValueMember = "SubjectId";
            this.repositoryItemGridLookUpEditSubjectId.View = this.gridView11;
            // 
            // gridView11
            // 
            this.gridView11.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn71,
            this.gridColumn73});
            this.gridView11.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView11.Name = "gridView11";
            this.gridView11.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView11.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn71
            // 
            this.gridColumn71.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn71.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn71.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn71.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn71.Caption = "الاسم بالعربيه";
            this.gridColumn71.FieldName = "Subject";
            this.gridColumn71.Name = "gridColumn71";
            this.gridColumn71.Visible = true;
            this.gridColumn71.VisibleIndex = 0;
            // 
            // gridColumn73
            // 
            this.gridColumn73.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn73.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn73.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn73.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn73.Caption = "الاسم بالانجليزيه";
            this.gridColumn73.FieldName = "Subject_e";
            this.gridColumn73.Name = "gridColumn73";
            this.gridColumn73.Visible = true;
            this.gridColumn73.VisibleIndex = 1;
            // 
            // repositoryItemCalcEditn0
            // 
            this.repositoryItemCalcEditn0.AutoHeight = false;
            this.repositoryItemCalcEditn0.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemCalcEditn0.DisplayFormat.FormatString = "n0";
            this.repositoryItemCalcEditn0.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemCalcEditn0.EditFormat.FormatString = "n0";
            this.repositoryItemCalcEditn0.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemCalcEditn0.Mask.EditMask = "n0";
            this.repositoryItemCalcEditn0.Name = "repositoryItemCalcEditn0";
            // 
            // repositoryItemGridLookUpEditEmpID
            // 
            this.repositoryItemGridLookUpEditEmpID.AutoHeight = false;
            this.repositoryItemGridLookUpEditEmpID.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditEmpID.DisplayMember = "emp_name";
            this.repositoryItemGridLookUpEditEmpID.Name = "repositoryItemGridLookUpEditEmpID";
            this.repositoryItemGridLookUpEditEmpID.NullText = "";
            this.repositoryItemGridLookUpEditEmpID.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditEmpID.ValueMember = "EmpID";
            this.repositoryItemGridLookUpEditEmpID.View = this.gridView12;
            // 
            // gridView12
            // 
            this.gridView12.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn75});
            this.gridView12.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView12.Name = "gridView12";
            this.gridView12.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView12.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn75
            // 
            this.gridColumn75.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn75.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn75.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn75.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn75.Caption = "الاسم";
            this.gridColumn75.FieldName = "emp_name";
            this.gridColumn75.Name = "gridColumn75";
            this.gridColumn75.Visible = true;
            this.gridColumn75.VisibleIndex = 0;
            // 
            // repositoryItemMemoExEditBigTxt
            // 
            this.repositoryItemMemoExEditBigTxt.AutoHeight = false;
            this.repositoryItemMemoExEditBigTxt.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEditBigTxt.Name = "repositoryItemMemoExEditBigTxt";
            // 
            // repositoryItemGridLookUpEditfasl_code
            // 
            this.repositoryItemGridLookUpEditfasl_code.AutoHeight = false;
            this.repositoryItemGridLookUpEditfasl_code.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditfasl_code.DisplayMember = "fasl_name";
            this.repositoryItemGridLookUpEditfasl_code.Name = "repositoryItemGridLookUpEditfasl_code";
            this.repositoryItemGridLookUpEditfasl_code.NullText = "";
            this.repositoryItemGridLookUpEditfasl_code.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditfasl_code.ValueMember = "fasl_code";
            this.repositoryItemGridLookUpEditfasl_code.View = this.gridView13;
            // 
            // gridView13
            // 
            this.gridView13.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn80,
            this.gridColumn81});
            this.gridView13.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView13.Name = "gridView13";
            this.gridView13.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView13.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn80
            // 
            this.gridColumn80.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn80.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn80.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn80.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn80.Caption = "الاسم بالعربيه";
            this.gridColumn80.FieldName = "fasl_name";
            this.gridColumn80.Name = "gridColumn80";
            this.gridColumn80.Visible = true;
            this.gridColumn80.VisibleIndex = 0;
            // 
            // gridColumn81
            // 
            this.gridColumn81.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn81.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn81.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn81.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn81.Caption = "الاسم بالانجليزيه";
            this.gridColumn81.FieldName = "fasl_name_e";
            this.gridColumn81.Name = "gridColumn81";
            this.gridColumn81.Visible = true;
            this.gridColumn81.VisibleIndex = 1;
            // 
            // repositoryItemGridLookUpEditEsthkakTypeId
            // 
            this.repositoryItemGridLookUpEditEsthkakTypeId.AutoHeight = false;
            this.repositoryItemGridLookUpEditEsthkakTypeId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditEsthkakTypeId.DisplayMember = "EsthkakType";
            this.repositoryItemGridLookUpEditEsthkakTypeId.Name = "repositoryItemGridLookUpEditEsthkakTypeId";
            this.repositoryItemGridLookUpEditEsthkakTypeId.NullText = "";
            this.repositoryItemGridLookUpEditEsthkakTypeId.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemGridLookUpEditEsthkakTypeId.ValueMember = "EsthkakTypeId";
            this.repositoryItemGridLookUpEditEsthkakTypeId.View = this.gridView1;
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn62});
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn62
            // 
            this.gridColumn62.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn62.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn62.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn62.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn62.Caption = "اسم النوع";
            this.gridColumn62.FieldName = "EsthkakType";
            this.gridColumn62.Name = "gridColumn62";
            this.gridColumn62.Visible = true;
            this.gridColumn62.VisibleIndex = 0;
            // 
            // repositoryItemCalcEditPer
            // 
            this.repositoryItemCalcEditPer.AutoHeight = false;
            this.repositoryItemCalcEditPer.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemCalcEditPer.DisplayFormat.FormatString = "p0";
            this.repositoryItemCalcEditPer.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemCalcEditPer.EditFormat.FormatString = "p0";
            this.repositoryItemCalcEditPer.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemCalcEditPer.Mask.EditMask = "p0";
            this.repositoryItemCalcEditPer.Name = "repositoryItemCalcEditPer";
            // 
            // cDJobBindingSource
            // 
            this.cDJobBindingSource.DataMember = "CDJob";
            this.cDJobBindingSource.DataSource = this.dSFellowship;
            // 
            // cDStateBindingSource
            // 
            this.cDStateBindingSource.DataMember = "CDState";
            this.cDStateBindingSource.DataSource = this.dSFellowship;
            // 
            // cDEDARETBindingSource
            // 
            this.cDEDARETBindingSource.DataMember = "CDEDARET";
            this.cDEDARETBindingSource.DataSource = this.dSFellowship;
            // 
            // gridColumn57
            // 
            this.gridColumn57.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn57.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn57.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn57.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn57.Caption = "الاسم بالعربيه";
            this.gridColumn57.FieldName = "alsofof_name";
            this.gridColumn57.Name = "gridColumn57";
            this.gridColumn57.Visible = true;
            this.gridColumn57.VisibleIndex = 0;
            // 
            // gridColumn84
            // 
            this.gridColumn84.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn84.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn84.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn84.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn84.Caption = "الاسم بالانجليزيه";
            this.gridColumn84.FieldName = "alsofof_name_e";
            this.gridColumn84.Name = "gridColumn84";
            this.gridColumn84.Visible = true;
            this.gridColumn84.VisibleIndex = 1;
            // 
            // cDSyndicateTableAdapter
            // 
            this.cDSyndicateTableAdapter.ClearBeforeFill = true;
            // 
            // cDEDARETTableAdapter
            // 
            this.cDEDARETTableAdapter.ClearBeforeFill = true;
            // 
            // cDModereaTableAdapter
            // 
            this.cDModereaTableAdapter.ClearBeforeFill = true;
            // 
            // cDStateTableAdapter
            // 
            this.cDStateTableAdapter.ClearBeforeFill = true;
            // 
            // cDJobTableAdapter
            // 
            this.cDJobTableAdapter.ClearBeforeFill = true;
            // 
            // cDAttachTableAdapter
            // 
            this.cDAttachTableAdapter.ClearBeforeFill = true;
            // 
            // CodeFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 362);
            this.Controls.Add(this.gridControlCode);
            this.Name = "CodeFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "اكواد";
            this.Load += new System.EventHandler(this.CodeFrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDEDARET)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditModereaId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDModereaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSFellowship)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSyndicateId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDSyndicateBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditDel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDAttachBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDModerea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDJob)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDAttach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCDSyndicate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEditCheckMe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSPOS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditqualId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditPayTypeId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditalsofof_code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEditf2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditKastNoId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditmarhala_code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditdaycode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdithasa_code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEditT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditSubjectId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEditn0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditEmpID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEditBigTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditfasl_code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditEsthkakTypeId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEditPer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDJobBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDStateBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDEDARETBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gridControlCode;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewCDSyndicate;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewCDEDARET;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSave;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditDel;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewCDModerea;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEditCheckMe;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn106;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditSPOS;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn112;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn113;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn116;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn117;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditqualId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn36;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditPayTypeId;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn54;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditalsofof_code;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn57;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEditf2;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditKastNoId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditmarhala_code;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn64;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn65;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditdaycode;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn67;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn68;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEdithasa_code;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn69;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn70;
        private DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit repositoryItemTimeEditT;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditSubjectId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn71;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn73;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEditn0;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditEmpID;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView12;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEditBigTxt;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn75;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditfasl_code;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn80;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn81;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn84;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditEsthkakTypeId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEditPer;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn62;
        private DataSources.DSFellowship dSFellowship;
        private System.Windows.Forms.BindingSource cDSyndicateBindingSource;
        private DataSources.DSFellowshipTableAdapters.CDSyndicateTableAdapter cDSyndicateTableAdapter;
        private System.Windows.Forms.BindingSource cDEDARETBindingSource;
        private DataSources.DSFellowshipTableAdapters.CDEDARETTableAdapter cDEDARETTableAdapter;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditModereaId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditSyndicateId;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView5;
        private System.Windows.Forms.BindingSource cDModereaBindingSource;
        private DataSources.DSFellowshipTableAdapters.CDModereaTableAdapter cDModereaTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn56;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn60;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewCDState;
        private System.Windows.Forms.BindingSource cDStateBindingSource;
        private DataSources.DSFellowshipTableAdapters.CDStateTableAdapter cDStateTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewCDJob;
        private System.Windows.Forms.BindingSource cDJobBindingSource;
        private DataSources.DSFellowshipTableAdapters.CDJobTableAdapter cDJobTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewCDAttach;
        private System.Windows.Forms.BindingSource cDAttachBindingSource;
        private DataSources.DSFellowshipTableAdapters.CDAttachTableAdapter cDAttachTableAdapter;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
    }
}