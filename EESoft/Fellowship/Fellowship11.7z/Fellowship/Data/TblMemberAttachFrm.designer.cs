﻿namespace Fellowship
{
    partial class TblMemberAttachFrm
    {
        private DevExpress.XtraEditors.GroupControl gcOptions;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.GridLookUpEdit LUEMembers;
        private System.ComponentModel.IContainer components;
        private DevExpress.XtraGrid.Views.Grid.GridView gridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn colMemberName;
        private DevExpress.XtraGrid.Columns.GridColumn colSyndicate;
        private DevExpress.XtraGrid.Columns.GridColumn colKideNumber;
        private DevExpress.XtraGrid.Columns.GridColumn colesalno;
        private DevExpress.XtraEditors.GroupControl gcDetails;
        private DevExpress.XtraGrid.GridControl gridControlData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewData;
        private DevExpress.XtraGrid.Columns.GridColumn colAttachmentTypeId;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditAttahcmentTypeId;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn colAttachInfo;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEditAttachInfo;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditEdit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditDel;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemImageComboBox1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private System.Windows.Forms.OpenFileDialog ofd;
        private DevExpress.XtraGrid.Columns.GridColumn colAttachmentName;
        private DevExpress.Utils.ImageCollection imageCollection1;

        #region Windows Form Designer generated code


        #endregion

        private DataSources.DSFellowshipQuery dSFellowshipQuery;
        private System.Windows.Forms.BindingSource tblMemberBindingSource;
        private DataSources.DSFellowshipQueryTableAdapters.TblMemberTableAdapter tblMemberTableAdapter;
        private DataSources.DSFellowship dSFellowship;
        private System.Windows.Forms.BindingSource tblHafzaEstlamAttatchBindingSource;
        private DataSources.DSFellowshipTableAdapters.TblHafzaEstlamAttatchTableAdapter tblHafzaEstlamAttatchTableAdapter;
        private System.Windows.Forms.BindingSource cDAttachBindingSource;
        private DataSources.DSFellowshipTableAdapters.CDAttachTableAdapter cDAttachTableAdapter;
    }
}