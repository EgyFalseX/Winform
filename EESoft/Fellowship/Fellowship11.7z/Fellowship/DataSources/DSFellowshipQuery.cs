﻿namespace Fellowship.DataSources {
    
    
    public partial class DSFellowshipQuery {
    }
}

namespace Fellowship.DataSources.DSFellowshipQueryTableAdapters {
    
    
    public partial class TblMemberTableAdapter {
    }
}
