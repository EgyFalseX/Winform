using System;

namespace ATCommands
{
    [Serializable]
    public class UserSettings
    {
        public string SkinName;
    }
}
