namespace ATCommands
{
    partial class MainFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode2 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode3 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode4 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode5 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode6 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode7 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode8 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode9 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode10 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode11 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode12 = new DevExpress.XtraGrid.GridLevelNode();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrm));
            this.gridViewGroups = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCGroupsGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCGroupUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSettingUse = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.GCGroupsSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSave = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.GCGroupDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSettingDel = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridControlMain = new DevExpress.XtraGrid.GridControl();
            this.CMSdataschool = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemSelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItemAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.gridViewMessages = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCMessagesnumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesmessageBody = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesstatus = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesSendTime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEditDate = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.GCMessagesUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessageSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewTemplates = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCTemplateTemplateBody = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCTemplateSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCTemplateUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCTemplateDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewUsers = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCUsersUserName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCUsersPassWord = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCUsersSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCUsersDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewContacts = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCContactsContactName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsContactNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsGroupID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditGroupName = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.repositoryItemGridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.layoutViewSkinStyle = new DevExpress.XtraGrid.Views.Layout.LayoutView();
            this.layoutViewColumnSkinStyle = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumnSkinStyle = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumnUse = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumnUse = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewCard1 = new DevExpress.XtraGrid.Views.Layout.LayoutViewCard();
            this.gridViewLogDetails = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cardViewe_schoolDB = new DevExpress.XtraGrid.Views.Card.CardView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditStu_DB_Path = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditResult_DB_Path = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditacc_sms_DB_Path = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditmalafatSms_DB_Path = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewdataschool = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCstu_Dayz = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCstu_BirthDay = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCstu_age = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCstu_eyab_date_from = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCstu_codeCheckBox = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEditstu_code = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridViewDatanet = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEditperm = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridViewacc_sms = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewSetting = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCServiceNum = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCSettingSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCSettingUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCSettingDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.splitContainerControl = new DevExpress.XtraEditors.SplitContainerControl();
            this.navBarControl = new DevExpress.XtraNavBar.NavBarControl();
            this.navBarGroupStudent = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItemdataschool = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemBirthday = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemAbsent = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemAbsentCount = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemDatanet = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemacc_sms = new DevExpress.XtraNavBar.NavBarItem();
            this.msmGroup = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItemContacts = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemGroups = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemTemplates = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemMessages = new DevExpress.XtraNavBar.NavBarItem();
            this.AdminGroup = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItemUsers = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemSetting = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarIteme_schoolDB = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemStyles = new DevExpress.XtraNavBar.NavBarItem();
            this.navbarImageListLarge = new System.Windows.Forms.ImageList(this.components);
            this.navbarImageList = new System.Windows.Forms.ImageList(this.components);
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.BtnDisconnect = new DevExpress.XtraEditors.SimpleButton();
            this.PnlConnection = new DevExpress.XtraEditors.PanelControl();
            this.TxtServiceNum = new DevExpress.XtraEditors.TextEdit();
            this.BtnConnect = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.CBEPort = new DevExpress.XtraEditors.ComboBoxEdit();
            this.PBSignal = new DevExpress.XtraEditors.ProgressBarControl();
            this.LblMsg = new DevExpress.XtraEditors.LabelControl();
            this.PnlSend = new DevExpress.XtraEditors.PanelControl();
            this.BtnDelSendTo = new DevExpress.XtraEditors.DropDownButton();
            this.popupMenuDeleteBtn = new DevExpress.XtraBars.PopupMenu(this.components);
            this.barButtonItemDelAll = new DevExpress.XtraBars.BarButtonItem();
            this.barManagerMain = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.PBSend = new DevExpress.XtraEditors.ProgressBarControl();
            this.LblMsgCounter = new System.Windows.Forms.Label();
            this.LblCharCounter = new System.Windows.Forms.Label();
            this.BtnSaveMsg = new DevExpress.XtraEditors.SimpleButton();
            this.CBAddVar = new DevExpress.XtraEditors.ComboBoxEdit();
            this.btnSend = new DevExpress.XtraEditors.SimpleButton();
            this.LBCSendTo = new DevExpress.XtraEditors.ListBoxControl();
            this.TxtMsg = new DevExpress.XtraEditors.MemoEdit();
            this.USBserialPort = new System.IO.Ports.SerialPort(this.components);
            this.TmrSignal = new System.Windows.Forms.Timer(this.components);
            this.gridViewmalafatSms = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.navBarItemmalafatSms = new DevExpress.XtraNavBar.NavBarItem();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingDel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMain)).BeginInit();
            this.CMSdataschool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTemplates)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewContacts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditGroupName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewSkinStyle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnSkinStyle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewLogDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardViewe_schoolDB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditStu_DB_Path)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditResult_DB_Path)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditacc_sms_DB_Path)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditmalafatSms_DB_Path)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewdataschool)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEditstu_code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDatanet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEditperm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewacc_sms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSetting)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl)).BeginInit();
            this.splitContainerControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PnlConnection)).BeginInit();
            this.PnlConnection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtServiceNum.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CBEPort.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSignal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PnlSend)).BeginInit();
            this.PnlSend.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuDeleteBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManagerMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSend.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CBAddVar.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LBCSendTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMsg.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewmalafatSms)).BeginInit();
            this.SuspendLayout();
            // 
            // gridViewGroups
            // 
            this.gridViewGroups.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.gridViewGroups.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCGroupsGroupName,
            this.GCGroupUse,
            this.GCGroupsSave,
            this.GCGroupDel});
            this.gridViewGroups.GridControl = this.gridControlMain;
            this.gridViewGroups.Name = "gridViewGroups";
            this.gridViewGroups.OptionsView.ColumnAutoWidth = false;
            // 
            // GCGroupsGroupName
            // 
            this.GCGroupsGroupName.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupsGroupName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsGroupName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupsGroupName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsGroupName.Caption = "��� ������";
            this.GCGroupsGroupName.FieldName = "GroupName";
            this.GCGroupsGroupName.Name = "GCGroupsGroupName";
            this.GCGroupsGroupName.Visible = true;
            this.GCGroupsGroupName.VisibleIndex = 0;
            this.GCGroupsGroupName.Width = 406;
            // 
            // GCGroupUse
            // 
            this.GCGroupUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupUse.Caption = "�������";
            this.GCGroupUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCGroupUse.Name = "GCGroupUse";
            this.GCGroupUse.Visible = true;
            this.GCGroupUse.VisibleIndex = 1;
            this.GCGroupUse.Width = 126;
            // 
            // repositoryItemButtonEditSettingUse
            // 
            this.repositoryItemButtonEditSettingUse.AutoHeight = false;
            this.repositoryItemButtonEditSettingUse.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)});
            this.repositoryItemButtonEditSettingUse.Name = "repositoryItemButtonEditSettingUse";
            this.repositoryItemButtonEditSettingUse.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSettingUse.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSettingUse_ButtonClick);
            // 
            // GCGroupsSave
            // 
            this.GCGroupsSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupsSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupsSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsSave.Caption = "���";
            this.GCGroupsSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCGroupsSave.Name = "GCGroupsSave";
            this.GCGroupsSave.Visible = true;
            this.GCGroupsSave.VisibleIndex = 2;
            // 
            // repositoryItemButtonEditSave
            // 
            this.repositoryItemButtonEditSave.AutoHeight = false;
            this.repositoryItemButtonEditSave.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEditSave.Name = "repositoryItemButtonEditSave";
            this.repositoryItemButtonEditSave.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSave.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSave_ButtonClick);
            // 
            // GCGroupDel
            // 
            this.GCGroupDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupDel.Caption = "���";
            this.GCGroupDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCGroupDel.Name = "GCGroupDel";
            this.GCGroupDel.Visible = true;
            this.GCGroupDel.VisibleIndex = 3;
            this.GCGroupDel.Width = 98;
            // 
            // repositoryItemButtonEditSettingDel
            // 
            this.repositoryItemButtonEditSettingDel.AutoHeight = false;
            this.repositoryItemButtonEditSettingDel.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.repositoryItemButtonEditSettingDel.Name = "repositoryItemButtonEditSettingDel";
            this.repositoryItemButtonEditSettingDel.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSettingDel.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSettingDel_ButtonClick);
            // 
            // gridControlMain
            // 
            this.gridControlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gridControlMain.ContextMenuStrip = this.CMSdataschool;
            this.gridControlMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlMain.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlMain.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlMain.EmbeddedNavigator.Buttons.Remove.Visible = false;
            gridLevelNode1.LevelTemplate = this.gridViewGroups;
            gridLevelNode1.RelationName = "Level1";
            gridLevelNode2.LevelTemplate = this.gridViewMessages;
            gridLevelNode2.RelationName = "Level2";
            gridLevelNode3.LevelTemplate = this.gridViewTemplates;
            gridLevelNode3.RelationName = "Level3";
            gridLevelNode4.LevelTemplate = this.gridViewUsers;
            gridLevelNode4.RelationName = "Level5";
            gridLevelNode5.LevelTemplate = this.gridViewContacts;
            gridLevelNode5.RelationName = "Level4";
            gridLevelNode6.LevelTemplate = this.layoutViewSkinStyle;
            gridLevelNode6.RelationName = "Level6";
            gridLevelNode7.LevelTemplate = this.gridViewLogDetails;
            gridLevelNode7.RelationName = "Level7";
            gridLevelNode8.LevelTemplate = this.cardViewe_schoolDB;
            gridLevelNode8.RelationName = "Level8";
            gridLevelNode9.LevelTemplate = this.gridViewdataschool;
            gridLevelNode9.RelationName = "Level9";
            gridLevelNode10.LevelTemplate = this.gridViewDatanet;
            gridLevelNode10.RelationName = "Level10";
            gridLevelNode11.LevelTemplate = this.gridViewacc_sms;
            gridLevelNode11.RelationName = "Level11";
            gridLevelNode12.LevelTemplate = this.gridViewmalafatSms;
            gridLevelNode12.RelationName = "Level12";
            this.gridControlMain.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1,
            gridLevelNode2,
            gridLevelNode3,
            gridLevelNode4,
            gridLevelNode5,
            gridLevelNode6,
            gridLevelNode7,
            gridLevelNode8,
            gridLevelNode9,
            gridLevelNode10,
            gridLevelNode11,
            gridLevelNode12});
            this.gridControlMain.Location = new System.Drawing.Point(0, 250);
            this.gridControlMain.MainView = this.gridViewSetting;
            this.gridControlMain.Name = "gridControlMain";
            this.gridControlMain.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditSettingUse,
            this.repositoryItemButtonEditSettingDel,
            this.repositoryItemDateEditDate,
            this.repositoryItemButtonEditSave,
            this.repositoryItemGridLookUpEditGroupName,
            this.repositoryItemButtonEditStu_DB_Path,
            this.repositoryItemButtonEditResult_DB_Path,
            this.repositoryItemCheckEditstu_code,
            this.repositoryItemCheckEditperm,
            this.repositoryItemButtonEditacc_sms_DB_Path,
            this.repositoryItemButtonEditmalafatSms_DB_Path});
            this.gridControlMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gridControlMain.Size = new System.Drawing.Size(724, 350);
            this.gridControlMain.TabIndex = 2;
            this.gridControlMain.UseEmbeddedNavigator = true;
            this.gridControlMain.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewMessages,
            this.gridViewTemplates,
            this.gridViewUsers,
            this.gridViewContacts,
            this.layoutViewSkinStyle,
            this.gridViewLogDetails,
            this.cardViewe_schoolDB,
            this.gridViewdataschool,
            this.gridViewDatanet,
            this.gridViewacc_sms,
            this.gridViewSetting,
            this.gridViewGroups,
            this.gridViewmalafatSms});
            // 
            // CMSdataschool
            // 
            this.CMSdataschool.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemSelectAll,
            this.toolStripSeparator1,
            this.toolStripMenuItemAdd});
            this.CMSdataschool.Name = "CMSdataschool";
            this.CMSdataschool.ShowImageMargin = false;
            this.CMSdataschool.Size = new System.Drawing.Size(100, 54);
            this.CMSdataschool.Opening += new System.ComponentModel.CancelEventHandler(this.CMSdataschool_Opening);
            // 
            // toolStripMenuItemSelectAll
            // 
            this.toolStripMenuItemSelectAll.Name = "toolStripMenuItemSelectAll";
            this.toolStripMenuItemSelectAll.Size = new System.Drawing.Size(99, 22);
            this.toolStripMenuItemSelectAll.Text = "������ ����";
            this.toolStripMenuItemSelectAll.Click += new System.EventHandler(this.toolStripMenuItemSelectAll_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(96, 6);
            // 
            // toolStripMenuItemAdd
            // 
            this.toolStripMenuItemAdd.Name = "toolStripMenuItemAdd";
            this.toolStripMenuItemAdd.Size = new System.Drawing.Size(99, 22);
            this.toolStripMenuItemAdd.Text = "�����";
            this.toolStripMenuItemAdd.Click += new System.EventHandler(this.toolStripMenuItemAdd_Click);
            // 
            // gridViewMessages
            // 
            this.gridViewMessages.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.gridViewMessages.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCMessagesnumber,
            this.GCMessagesmessageBody,
            this.GCMessagesstatus,
            this.GCMessagesSendTime,
            this.GCMessagesUse,
            this.GCMessageSave,
            this.GCMessagesDel});
            this.gridViewMessages.GridControl = this.gridControlMain;
            this.gridViewMessages.Name = "gridViewMessages";
            this.gridViewMessages.OptionsView.ColumnAutoWidth = false;
            // 
            // GCMessagesnumber
            // 
            this.GCMessagesnumber.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesnumber.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesnumber.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesnumber.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesnumber.Caption = "������ ����";
            this.GCMessagesnumber.FieldName = "number";
            this.GCMessagesnumber.Name = "GCMessagesnumber";
            this.GCMessagesnumber.Visible = true;
            this.GCMessagesnumber.VisibleIndex = 0;
            this.GCMessagesnumber.Width = 107;
            // 
            // GCMessagesmessageBody
            // 
            this.GCMessagesmessageBody.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesmessageBody.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesmessageBody.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.GCMessagesmessageBody.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesmessageBody.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesmessageBody.Caption = "����� �������";
            this.GCMessagesmessageBody.FieldName = "messageBody";
            this.GCMessagesmessageBody.Name = "GCMessagesmessageBody";
            this.GCMessagesmessageBody.Visible = true;
            this.GCMessagesmessageBody.VisibleIndex = 1;
            this.GCMessagesmessageBody.Width = 299;
            // 
            // GCMessagesstatus
            // 
            this.GCMessagesstatus.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesstatus.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesstatus.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesstatus.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesstatus.Caption = "������";
            this.GCMessagesstatus.FieldName = "status";
            this.GCMessagesstatus.Name = "GCMessagesstatus";
            this.GCMessagesstatus.Visible = true;
            this.GCMessagesstatus.VisibleIndex = 2;
            this.GCMessagesstatus.Width = 99;
            // 
            // GCMessagesSendTime
            // 
            this.GCMessagesSendTime.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesSendTime.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesSendTime.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesSendTime.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesSendTime.Caption = "�������";
            this.GCMessagesSendTime.ColumnEdit = this.repositoryItemDateEditDate;
            this.GCMessagesSendTime.FieldName = "SendTime";
            this.GCMessagesSendTime.Name = "GCMessagesSendTime";
            this.GCMessagesSendTime.Visible = true;
            this.GCMessagesSendTime.VisibleIndex = 3;
            this.GCMessagesSendTime.Width = 90;
            // 
            // repositoryItemDateEditDate
            // 
            this.repositoryItemDateEditDate.AutoHeight = false;
            this.repositoryItemDateEditDate.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEditDate.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditDate.EditFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditDate.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditDate.Mask.EditMask = "dd/MM/yyyy";
            this.repositoryItemDateEditDate.Name = "repositoryItemDateEditDate";
            this.repositoryItemDateEditDate.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // GCMessagesUse
            // 
            this.GCMessagesUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesUse.Caption = "�������";
            this.GCMessagesUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCMessagesUse.Name = "GCMessagesUse";
            this.GCMessagesUse.Visible = true;
            this.GCMessagesUse.VisibleIndex = 4;
            this.GCMessagesUse.Width = 106;
            // 
            // GCMessageSave
            // 
            this.GCMessageSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessageSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessageSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessageSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessageSave.Caption = "���";
            this.GCMessageSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCMessageSave.Name = "GCMessageSave";
            this.GCMessageSave.Visible = true;
            this.GCMessageSave.VisibleIndex = 5;
            // 
            // GCMessagesDel
            // 
            this.GCMessagesDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesDel.Caption = "���";
            this.GCMessagesDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCMessagesDel.Name = "GCMessagesDel";
            this.GCMessagesDel.Visible = true;
            this.GCMessagesDel.VisibleIndex = 6;
            // 
            // gridViewTemplates
            // 
            this.gridViewTemplates.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCTemplateTemplateBody,
            this.GCTemplateSave,
            this.GCTemplateUse,
            this.GCTemplateDel});
            this.gridViewTemplates.GridControl = this.gridControlMain;
            this.gridViewTemplates.Name = "gridViewTemplates";
            this.gridViewTemplates.OptionsView.ColumnAutoWidth = false;
            // 
            // GCTemplateTemplateBody
            // 
            this.GCTemplateTemplateBody.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateTemplateBody.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateTemplateBody.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateTemplateBody.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateTemplateBody.Caption = "�� �������";
            this.GCTemplateTemplateBody.FieldName = "TemplateBody";
            this.GCTemplateTemplateBody.Name = "GCTemplateTemplateBody";
            this.GCTemplateTemplateBody.Visible = true;
            this.GCTemplateTemplateBody.VisibleIndex = 0;
            this.GCTemplateTemplateBody.Width = 389;
            // 
            // GCTemplateSave
            // 
            this.GCTemplateSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateSave.Caption = "���";
            this.GCTemplateSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCTemplateSave.Name = "GCTemplateSave";
            this.GCTemplateSave.Visible = true;
            this.GCTemplateSave.VisibleIndex = 2;
            this.GCTemplateSave.Width = 110;
            // 
            // GCTemplateUse
            // 
            this.GCTemplateUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateUse.Caption = "�������";
            this.GCTemplateUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCTemplateUse.Name = "GCTemplateUse";
            this.GCTemplateUse.Visible = true;
            this.GCTemplateUse.VisibleIndex = 1;
            this.GCTemplateUse.Width = 88;
            // 
            // GCTemplateDel
            // 
            this.GCTemplateDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateDel.Caption = "���";
            this.GCTemplateDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCTemplateDel.Name = "GCTemplateDel";
            this.GCTemplateDel.Visible = true;
            this.GCTemplateDel.VisibleIndex = 3;
            this.GCTemplateDel.Width = 82;
            // 
            // gridViewUsers
            // 
            this.gridViewUsers.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCUsersUserName,
            this.GCUsersPassWord,
            this.GCUsersSave,
            this.GCUsersDel});
            this.gridViewUsers.GridControl = this.gridControlMain;
            this.gridViewUsers.Name = "gridViewUsers";
            this.gridViewUsers.OptionsView.ColumnAutoWidth = false;
            // 
            // GCUsersUserName
            // 
            this.GCUsersUserName.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersUserName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersUserName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersUserName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersUserName.Caption = "��� ��������";
            this.GCUsersUserName.FieldName = "UserName";
            this.GCUsersUserName.Name = "GCUsersUserName";
            this.GCUsersUserName.Visible = true;
            this.GCUsersUserName.VisibleIndex = 0;
            this.GCUsersUserName.Width = 271;
            // 
            // GCUsersPassWord
            // 
            this.GCUsersPassWord.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersPassWord.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersPassWord.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersPassWord.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersPassWord.Caption = "���� ������";
            this.GCUsersPassWord.FieldName = "PassWord";
            this.GCUsersPassWord.Name = "GCUsersPassWord";
            this.GCUsersPassWord.Visible = true;
            this.GCUsersPassWord.VisibleIndex = 1;
            this.GCUsersPassWord.Width = 188;
            // 
            // GCUsersSave
            // 
            this.GCUsersSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersSave.Caption = "���";
            this.GCUsersSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCUsersSave.Name = "GCUsersSave";
            this.GCUsersSave.Visible = true;
            this.GCUsersSave.VisibleIndex = 2;
            this.GCUsersSave.Width = 105;
            // 
            // GCUsersDel
            // 
            this.GCUsersDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersDel.Caption = "���";
            this.GCUsersDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCUsersDel.Name = "GCUsersDel";
            this.GCUsersDel.Visible = true;
            this.GCUsersDel.VisibleIndex = 3;
            this.GCUsersDel.Width = 90;
            // 
            // gridViewContacts
            // 
            this.gridViewContacts.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCContactsContactName,
            this.GCContactsContactNumber,
            this.GCContactsGroupID,
            this.GCContactsUse,
            this.GCContactSave,
            this.GCContactsDel});
            this.gridViewContacts.GridControl = this.gridControlMain;
            this.gridViewContacts.Name = "gridViewContacts";
            this.gridViewContacts.OptionsView.ColumnAutoWidth = false;
            // 
            // GCContactsContactName
            // 
            this.GCContactsContactName.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsContactName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsContactName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactName.Caption = "�����";
            this.GCContactsContactName.FieldName = "ContactName";
            this.GCContactsContactName.Name = "GCContactsContactName";
            this.GCContactsContactName.Visible = true;
            this.GCContactsContactName.VisibleIndex = 0;
            this.GCContactsContactName.Width = 259;
            // 
            // GCContactsContactNumber
            // 
            this.GCContactsContactNumber.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsContactNumber.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactNumber.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsContactNumber.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactNumber.Caption = "��� �������";
            this.GCContactsContactNumber.FieldName = "ContactNumber";
            this.GCContactsContactNumber.Name = "GCContactsContactNumber";
            this.GCContactsContactNumber.Visible = true;
            this.GCContactsContactNumber.VisibleIndex = 1;
            this.GCContactsContactNumber.Width = 156;
            // 
            // GCContactsGroupID
            // 
            this.GCContactsGroupID.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsGroupID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsGroupID.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsGroupID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsGroupID.Caption = "������";
            this.GCContactsGroupID.ColumnEdit = this.repositoryItemGridLookUpEditGroupName;
            this.GCContactsGroupID.FieldName = "GroupID";
            this.GCContactsGroupID.Name = "GCContactsGroupID";
            this.GCContactsGroupID.Visible = true;
            this.GCContactsGroupID.VisibleIndex = 2;
            this.GCContactsGroupID.Width = 131;
            // 
            // repositoryItemGridLookUpEditGroupName
            // 
            this.repositoryItemGridLookUpEditGroupName.AutoHeight = false;
            this.repositoryItemGridLookUpEditGroupName.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditGroupName.Name = "repositoryItemGridLookUpEditGroupName";
            this.repositoryItemGridLookUpEditGroupName.NullText = "";
            this.repositoryItemGridLookUpEditGroupName.View = this.repositoryItemGridLookUpEdit1View;
            // 
            // repositoryItemGridLookUpEdit1View
            // 
            this.repositoryItemGridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCGroupName});
            this.repositoryItemGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemGridLookUpEdit1View.Name = "repositoryItemGridLookUpEdit1View";
            this.repositoryItemGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemGridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // GCGroupName
            // 
            this.GCGroupName.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupName.Caption = "��� ������";
            this.GCGroupName.FieldName = "GroupName";
            this.GCGroupName.Name = "GCGroupName";
            this.GCGroupName.Visible = true;
            this.GCGroupName.VisibleIndex = 0;
            // 
            // GCContactsUse
            // 
            this.GCContactsUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsUse.Caption = "�������";
            this.GCContactsUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCContactsUse.Name = "GCContactsUse";
            this.GCContactsUse.Visible = true;
            this.GCContactsUse.VisibleIndex = 3;
            this.GCContactsUse.Width = 118;
            // 
            // GCContactSave
            // 
            this.GCContactSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactSave.Caption = "���";
            this.GCContactSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCContactSave.Name = "GCContactSave";
            this.GCContactSave.Visible = true;
            this.GCContactSave.VisibleIndex = 4;
            this.GCContactSave.Width = 84;
            // 
            // GCContactsDel
            // 
            this.GCContactsDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsDel.Caption = "���";
            this.GCContactsDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCContactsDel.Name = "GCContactsDel";
            this.GCContactsDel.Visible = true;
            this.GCContactsDel.VisibleIndex = 5;
            this.GCContactsDel.Width = 85;
            // 
            // layoutViewSkinStyle
            // 
            this.layoutViewSkinStyle.CardMinSize = new System.Drawing.Size(268, 116);
            this.layoutViewSkinStyle.Columns.AddRange(new DevExpress.XtraGrid.Columns.LayoutViewColumn[] {
            this.layoutViewColumnSkinStyle,
            this.layoutViewColumnUse});
            this.layoutViewSkinStyle.GridControl = this.gridControlMain;
            this.layoutViewSkinStyle.Name = "layoutViewSkinStyle";
            this.layoutViewSkinStyle.OptionsView.ShowCardFieldBorders = true;
            this.layoutViewSkinStyle.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.layoutViewSkinStyle.OptionsView.ViewMode = DevExpress.XtraGrid.Views.Layout.LayoutViewMode.Carousel;
            this.layoutViewSkinStyle.TemplateCard = this.layoutViewCard1;
            // 
            // layoutViewColumnSkinStyle
            // 
            this.layoutViewColumnSkinStyle.AppearanceCell.Options.UseTextOptions = true;
            this.layoutViewColumnSkinStyle.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnSkinStyle.AppearanceHeader.Options.UseTextOptions = true;
            this.layoutViewColumnSkinStyle.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnSkinStyle.Caption = "��� �����";
            this.layoutViewColumnSkinStyle.FieldName = "StykeName";
            this.layoutViewColumnSkinStyle.LayoutViewField = this.layoutViewField_layoutViewColumnSkinStyle;
            this.layoutViewColumnSkinStyle.Name = "layoutViewColumnSkinStyle";
            this.layoutViewColumnSkinStyle.OptionsColumn.AllowEdit = false;
            this.layoutViewColumnSkinStyle.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumnSkinStyle
            // 
            this.layoutViewField_layoutViewColumnSkinStyle.EditorPreferredWidth = 172;
            this.layoutViewField_layoutViewColumnSkinStyle.Location = new System.Drawing.Point(0, 0);
            this.layoutViewField_layoutViewColumnSkinStyle.Name = "layoutViewField_layoutViewColumnSkinStyle";
            this.layoutViewField_layoutViewColumnSkinStyle.Size = new System.Drawing.Size(262, 40);
            this.layoutViewField_layoutViewColumnSkinStyle.Spacing = new DevExpress.XtraLayout.Utils.Padding(10, 10, 10, 10);
            this.layoutViewField_layoutViewColumnSkinStyle.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutViewField_layoutViewColumnSkinStyle.TextSize = new System.Drawing.Size(61, 13);
            this.layoutViewField_layoutViewColumnSkinStyle.TextToControlDistance = 5;
            // 
            // layoutViewColumnUse
            // 
            this.layoutViewColumnUse.AppearanceCell.Options.UseTextOptions = true;
            this.layoutViewColumnUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnUse.AppearanceHeader.Options.UseTextOptions = true;
            this.layoutViewColumnUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnUse.Caption = "�������";
            this.layoutViewColumnUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.layoutViewColumnUse.LayoutViewField = this.layoutViewField_layoutViewColumnUse;
            this.layoutViewColumnUse.Name = "layoutViewColumnUse";
            // 
            // layoutViewField_layoutViewColumnUse
            // 
            this.layoutViewField_layoutViewColumnUse.EditorPreferredWidth = 172;
            this.layoutViewField_layoutViewColumnUse.Location = new System.Drawing.Point(0, 40);
            this.layoutViewField_layoutViewColumnUse.Name = "layoutViewField_layoutViewColumnUse";
            this.layoutViewField_layoutViewColumnUse.Size = new System.Drawing.Size(262, 40);
            this.layoutViewField_layoutViewColumnUse.Spacing = new DevExpress.XtraLayout.Utils.Padding(10, 10, 10, 10);
            this.layoutViewField_layoutViewColumnUse.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutViewField_layoutViewColumnUse.TextSize = new System.Drawing.Size(61, 13);
            this.layoutViewField_layoutViewColumnUse.TextToControlDistance = 5;
            // 
            // layoutViewCard1
            // 
            this.layoutViewCard1.CustomizationFormText = "TemplateCard";
            this.layoutViewCard1.ExpandButtonLocation = DevExpress.Utils.GroupElementLocation.AfterText;
            this.layoutViewCard1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutViewField_layoutViewColumnSkinStyle,
            this.layoutViewField_layoutViewColumnUse});
            this.layoutViewCard1.Name = "layoutViewCard1";
            this.layoutViewCard1.OptionsItemText.TextToControlDistance = 5;
            this.layoutViewCard1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutViewCard1.Text = "TemplateCard";
            // 
            // gridViewLogDetails
            // 
            this.gridViewLogDetails.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1});
            this.gridViewLogDetails.GridControl = this.gridControlMain;
            this.gridViewLogDetails.Name = "gridViewLogDetails";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "��������";
            this.gridColumn1.FieldName = "details";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // cardViewe_schoolDB
            // 
            this.cardViewe_schoolDB.CardWidth = 400;
            this.cardViewe_schoolDB.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn4});
            this.cardViewe_schoolDB.FocusedCardTopFieldIndex = 0;
            this.cardViewe_schoolDB.GridControl = this.gridControlMain;
            this.cardViewe_schoolDB.Name = "cardViewe_schoolDB";
            this.cardViewe_schoolDB.OptionsView.ShowCardCaption = false;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "����� ������ �������";
            this.gridColumn2.ColumnEdit = this.repositoryItemButtonEditStu_DB_Path;
            this.gridColumn2.FieldName = "Stu_DB_Path";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            // 
            // repositoryItemButtonEditStu_DB_Path
            // 
            this.repositoryItemButtonEditStu_DB_Path.AutoHeight = false;
            this.repositoryItemButtonEditStu_DB_Path.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEditStu_DB_Path.Name = "repositoryItemButtonEditStu_DB_Path";
            this.repositoryItemButtonEditStu_DB_Path.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditStu_DB_Path_ButtonClick);
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "����� ������ �������";
            this.gridColumn3.ColumnEdit = this.repositoryItemButtonEditResult_DB_Path;
            this.gridColumn3.FieldName = "Result_DB_Path";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.ReadOnly = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            // 
            // repositoryItemButtonEditResult_DB_Path
            // 
            this.repositoryItemButtonEditResult_DB_Path.AutoHeight = false;
            this.repositoryItemButtonEditResult_DB_Path.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEditResult_DB_Path.Name = "repositoryItemButtonEditResult_DB_Path";
            this.repositoryItemButtonEditResult_DB_Path.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditResult_DB_Path_ButtonClick);
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "����� ������ ��������";
            this.gridColumn17.ColumnEdit = this.repositoryItemButtonEditacc_sms_DB_Path;
            this.gridColumn17.FieldName = "acc_sms_DB_Path";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 2;
            // 
            // repositoryItemButtonEditacc_sms_DB_Path
            // 
            this.repositoryItemButtonEditacc_sms_DB_Path.AutoHeight = false;
            this.repositoryItemButtonEditacc_sms_DB_Path.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEditacc_sms_DB_Path.Name = "repositoryItemButtonEditacc_sms_DB_Path";
            this.repositoryItemButtonEditacc_sms_DB_Path.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditacc_sms_DB_Path_ButtonClick);
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "����� ������ ��������";
            this.gridColumn18.ColumnEdit = this.repositoryItemButtonEditmalafatSms_DB_Path;
            this.gridColumn18.FieldName = "malafatSms_DB_Path";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 3;
            // 
            // repositoryItemButtonEditmalafatSms_DB_Path
            // 
            this.repositoryItemButtonEditmalafatSms_DB_Path.AutoHeight = false;
            this.repositoryItemButtonEditmalafatSms_DB_Path.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEditmalafatSms_DB_Path.Name = "repositoryItemButtonEditmalafatSms_DB_Path";
            this.repositoryItemButtonEditmalafatSms_DB_Path.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditmalafatSms_DB_Path_ButtonClick);
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "���";
            this.gridColumn4.ColumnEdit = this.repositoryItemButtonEditSave;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            // 
            // gridViewdataschool
            // 
            this.gridViewdataschool.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn5,
            this.gridColumn9,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.GCstu_Dayz,
            this.GCstu_BirthDay,
            this.GCstu_age,
            this.GCstu_eyab_date_from,
            this.GCstu_codeCheckBox});
            this.gridViewdataschool.GridControl = this.gridControlMain;
            this.gridViewdataschool.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.None, "check", this.GCstu_codeCheckBox, "")});
            this.gridViewdataschool.Name = "gridViewdataschool";
            this.gridViewdataschool.OptionsView.AutoCalcPreviewLineCount = true;
            this.gridViewdataschool.OptionsView.ColumnAutoWidth = false;
            this.gridViewdataschool.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.ShowAlways;
            this.gridViewdataschool.OptionsView.ShowFooter = true;
            this.gridViewdataschool.OptionsView.ShowGroupedColumns = true;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "����";
            this.gridColumn5.FieldName = "alsofof_code_Name";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 0;
            this.gridColumn5.Width = 91;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "�����";
            this.gridColumn9.FieldName = "fasl_code_Name";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 1;
            this.gridColumn9.Width = 67;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "��� ������";
            this.gridColumn6.FieldName = "stu_name";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 2;
            this.gridColumn6.Width = 207;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "��� ��� �����";
            this.gridColumn7.FieldName = "walealkmrname";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 3;
            this.gridColumn7.Width = 188;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "�������";
            this.gridColumn8.FieldName = "waleaalkamr_mobile";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 4;
            this.gridColumn8.Width = 105;
            // 
            // GCstu_Dayz
            // 
            this.GCstu_Dayz.AppearanceCell.Options.UseTextOptions = true;
            this.GCstu_Dayz.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_Dayz.AppearanceHeader.Options.UseTextOptions = true;
            this.GCstu_Dayz.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_Dayz.Caption = "��� ���� ������";
            this.GCstu_Dayz.FieldName = "Dayz";
            this.GCstu_Dayz.Name = "GCstu_Dayz";
            this.GCstu_Dayz.OptionsColumn.ReadOnly = true;
            this.GCstu_Dayz.Visible = true;
            this.GCstu_Dayz.VisibleIndex = 5;
            // 
            // GCstu_BirthDay
            // 
            this.GCstu_BirthDay.AppearanceCell.Options.UseTextOptions = true;
            this.GCstu_BirthDay.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_BirthDay.AppearanceHeader.Options.UseTextOptions = true;
            this.GCstu_BirthDay.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_BirthDay.Caption = "����� �������";
            this.GCstu_BirthDay.ColumnEdit = this.repositoryItemDateEditDate;
            this.GCstu_BirthDay.FieldName = "BirthDay";
            this.GCstu_BirthDay.Name = "GCstu_BirthDay";
            this.GCstu_BirthDay.Visible = true;
            this.GCstu_BirthDay.VisibleIndex = 6;
            this.GCstu_BirthDay.Width = 96;
            // 
            // GCstu_age
            // 
            this.GCstu_age.AppearanceCell.Options.UseTextOptions = true;
            this.GCstu_age.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_age.AppearanceHeader.Options.UseTextOptions = true;
            this.GCstu_age.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_age.Caption = "����";
            this.GCstu_age.FieldName = "age";
            this.GCstu_age.Name = "GCstu_age";
            this.GCstu_age.Visible = true;
            this.GCstu_age.VisibleIndex = 7;
            this.GCstu_age.Width = 56;
            // 
            // GCstu_eyab_date_from
            // 
            this.GCstu_eyab_date_from.AppearanceCell.Options.UseTextOptions = true;
            this.GCstu_eyab_date_from.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_eyab_date_from.AppearanceHeader.Options.UseTextOptions = true;
            this.GCstu_eyab_date_from.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_eyab_date_from.Caption = "����� ������";
            this.GCstu_eyab_date_from.ColumnEdit = this.repositoryItemDateEditDate;
            this.GCstu_eyab_date_from.FieldName = "eyab_date_from";
            this.GCstu_eyab_date_from.Name = "GCstu_eyab_date_from";
            this.GCstu_eyab_date_from.Visible = true;
            this.GCstu_eyab_date_from.VisibleIndex = 8;
            this.GCstu_eyab_date_from.Width = 79;
            // 
            // GCstu_codeCheckBox
            // 
            this.GCstu_codeCheckBox.AppearanceCell.Options.UseTextOptions = true;
            this.GCstu_codeCheckBox.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_codeCheckBox.AppearanceHeader.Options.UseTextOptions = true;
            this.GCstu_codeCheckBox.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCstu_codeCheckBox.Caption = "������";
            this.GCstu_codeCheckBox.ColumnEdit = this.repositoryItemCheckEditstu_code;
            this.GCstu_codeCheckBox.FieldName = "checked";
            this.GCstu_codeCheckBox.Name = "GCstu_codeCheckBox";
            this.GCstu_codeCheckBox.Visible = true;
            this.GCstu_codeCheckBox.VisibleIndex = 9;
            this.GCstu_codeCheckBox.Width = 77;
            // 
            // repositoryItemCheckEditstu_code
            // 
            this.repositoryItemCheckEditstu_code.AutoHeight = false;
            this.repositoryItemCheckEditstu_code.DisplayValueChecked = "True";
            this.repositoryItemCheckEditstu_code.DisplayValueUnchecked = "False";
            this.repositoryItemCheckEditstu_code.Name = "repositoryItemCheckEditstu_code";
            this.repositoryItemCheckEditstu_code.ValueChecked = "True";
            this.repositoryItemCheckEditstu_code.ValueUnchecked = "False";
            // 
            // gridViewDatanet
            // 
            this.gridViewDatanet.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn15,
            this.gridColumn10,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn16,
            this.gridColumn14,
            this.gridColumn11});
            this.gridViewDatanet.GridControl = this.gridControlMain;
            this.gridViewDatanet.Name = "gridViewDatanet";
            this.gridViewDatanet.OptionsView.ColumnAutoWidth = false;
            this.gridViewDatanet.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.ShowAlways;
            this.gridViewDatanet.OptionsView.ShowFooter = true;
            this.gridViewDatanet.OptionsView.ShowGroupedColumns = true;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "��������";
            this.gridColumn15.FieldName = "manth_code_Name";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 0;
            this.gridColumn15.Width = 120;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "��� ������";
            this.gridColumn10.FieldName = "stu_name";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 3;
            this.gridColumn10.Width = 182;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "������";
            this.gridColumn12.FieldName = "sumd";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 4;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "����";
            this.gridColumn13.FieldName = "alsofof_code_Name";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 1;
            this.gridColumn13.Width = 110;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "�������";
            this.gridColumn16.FieldName = "mobil";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 5;
            this.gridColumn16.Width = 87;
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "�����";
            this.gridColumn14.FieldName = "fasl_code_Name";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 2;
            this.gridColumn14.Width = 80;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.Caption = "�����";
            this.gridColumn11.ColumnEdit = this.repositoryItemCheckEditperm;
            this.gridColumn11.FieldName = "perm";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 6;
            this.gridColumn11.Width = 59;
            // 
            // repositoryItemCheckEditperm
            // 
            this.repositoryItemCheckEditperm.AutoHeight = false;
            this.repositoryItemCheckEditperm.Name = "repositoryItemCheckEditperm";
            this.repositoryItemCheckEditperm.ValueChecked = "True";
            this.repositoryItemCheckEditperm.ValueUnchecked = "False";
            // 
            // gridViewacc_sms
            // 
            this.gridViewacc_sms.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn19,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn24});
            this.gridViewacc_sms.GridControl = this.gridControlMain;
            this.gridViewacc_sms.Name = "gridViewacc_sms";
            this.gridViewacc_sms.OptionsView.ColumnAutoWidth = false;
            this.gridViewacc_sms.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.ShowAlways;
            this.gridViewacc_sms.OptionsView.ShowFooter = true;
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "����";
            this.gridColumn19.FieldName = "alsofof_code_Name";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 0;
            this.gridColumn19.Width = 87;
            // 
            // gridColumn20
            // 
            this.gridColumn20.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.Caption = "�����";
            this.gridColumn20.FieldName = "fasl_code_Name";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 1;
            // 
            // gridColumn21
            // 
            this.gridColumn21.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn21.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn21.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn21.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn21.Caption = "��� ������";
            this.gridColumn21.FieldName = "stu_name";
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 2;
            this.gridColumn21.Width = 161;
            // 
            // gridColumn22
            // 
            this.gridColumn22.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn22.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn22.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn22.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn22.Caption = "������";
            this.gridColumn22.FieldName = "summony";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 3;
            this.gridColumn22.Width = 95;
            // 
            // gridColumn23
            // 
            this.gridColumn23.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.Caption = "�������";
            this.gridColumn23.FieldName = "mobil";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 4;
            this.gridColumn23.Width = 100;
            // 
            // gridColumn24
            // 
            this.gridColumn24.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn24.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn24.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn24.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn24.Caption = "�������";
            this.gridColumn24.ColumnEdit = this.repositoryItemCheckEditstu_code;
            this.gridColumn24.FieldName = "checked";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 5;
            // 
            // gridViewSetting
            // 
            this.gridViewSetting.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCServiceNum,
            this.GCSettingSave,
            this.GCSettingUse,
            this.GCSettingDel});
            this.gridViewSetting.GridControl = this.gridControlMain;
            this.gridViewSetting.Name = "gridViewSetting";
            this.gridViewSetting.OptionsView.ColumnAutoWidth = false;
            // 
            // GCServiceNum
            // 
            this.GCServiceNum.AppearanceCell.Options.UseTextOptions = true;
            this.GCServiceNum.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCServiceNum.AppearanceHeader.Options.UseTextOptions = true;
            this.GCServiceNum.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCServiceNum.Caption = "��� ������ ������";
            this.GCServiceNum.FieldName = "ServiceNum";
            this.GCServiceNum.Name = "GCServiceNum";
            this.GCServiceNum.Visible = true;
            this.GCServiceNum.VisibleIndex = 0;
            this.GCServiceNum.Width = 326;
            // 
            // GCSettingSave
            // 
            this.GCSettingSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCSettingSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCSettingSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingSave.Caption = "���";
            this.GCSettingSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCSettingSave.Name = "GCSettingSave";
            this.GCSettingSave.Visible = true;
            this.GCSettingSave.VisibleIndex = 2;
            // 
            // GCSettingUse
            // 
            this.GCSettingUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCSettingUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCSettingUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingUse.Caption = "�������";
            this.GCSettingUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCSettingUse.Name = "GCSettingUse";
            this.GCSettingUse.Visible = true;
            this.GCSettingUse.VisibleIndex = 1;
            this.GCSettingUse.Width = 148;
            // 
            // GCSettingDel
            // 
            this.GCSettingDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCSettingDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCSettingDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingDel.Caption = "���";
            this.GCSettingDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCSettingDel.Name = "GCSettingDel";
            this.GCSettingDel.Visible = true;
            this.GCSettingDel.VisibleIndex = 3;
            // 
            // splitContainerControl
            // 
            this.splitContainerControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl.Name = "splitContainerControl";
            this.splitContainerControl.Padding = new System.Windows.Forms.Padding(6);
            this.splitContainerControl.Panel1.Controls.Add(this.navBarControl);
            this.splitContainerControl.Panel1.Text = "Panel1";
            this.splitContainerControl.Panel2.Controls.Add(this.groupControl1);
            this.splitContainerControl.Panel2.Controls.Add(this.gridControlMain);
            this.splitContainerControl.Panel2.Text = "Panel2";
            this.splitContainerControl.Size = new System.Drawing.Size(909, 612);
            this.splitContainerControl.SplitterPosition = 165;
            this.splitContainerControl.TabIndex = 0;
            this.splitContainerControl.Text = "splitContainerControl1";
            // 
            // navBarControl
            // 
            this.navBarControl.ActiveGroup = this.navBarGroupStudent;
            this.navBarControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navBarControl.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.msmGroup,
            this.navBarGroupStudent,
            this.AdminGroup});
            this.navBarControl.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.navBarItemMessages,
            this.navBarItemSetting,
            this.navBarItemTemplates,
            this.navBarItemUsers,
            this.navBarItemGroups,
            this.navBarItemContacts,
            this.navBarItemStyles,
            this.navBarIteme_schoolDB,
            this.navBarItemdataschool,
            this.navBarItemAbsentCount,
            this.navBarItemAbsent,
            this.navBarItemBirthday,
            this.navBarItemDatanet,
            this.navBarItemacc_sms,
            this.navBarItemmalafatSms});
            this.navBarControl.LargeImages = this.navbarImageListLarge;
            this.navBarControl.Location = new System.Drawing.Point(0, 0);
            this.navBarControl.Name = "navBarControl";
            this.navBarControl.OptionsNavPane.ExpandedWidth = 322;
            this.navBarControl.PaintStyleKind = DevExpress.XtraNavBar.NavBarViewKind.NavigationPane;
            this.navBarControl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.navBarControl.Size = new System.Drawing.Size(165, 600);
            this.navBarControl.SmallImages = this.navbarImageList;
            this.navBarControl.StoreDefaultPaintStyleName = true;
            this.navBarControl.TabIndex = 0;
            this.navBarControl.Text = "navBarControl1";
            // 
            // navBarGroupStudent
            // 
            this.navBarGroupStudent.Caption = "������";
            this.navBarGroupStudent.Expanded = true;
            this.navBarGroupStudent.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemdataschool),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemBirthday),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemAbsent),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemAbsentCount),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemDatanet),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemacc_sms),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemmalafatSms)});
            this.navBarGroupStudent.LargeImageIndex = 8;
            this.navBarGroupStudent.Name = "navBarGroupStudent";
            // 
            // navBarItemdataschool
            // 
            this.navBarItemdataschool.Caption = "������";
            this.navBarItemdataschool.Name = "navBarItemdataschool";
            this.navBarItemdataschool.SmallImageIndex = 9;
            this.navBarItemdataschool.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemdataschool_LinkClicked);
            // 
            // navBarItemBirthday
            // 
            this.navBarItemBirthday.Caption = "��� �������";
            this.navBarItemBirthday.Name = "navBarItemBirthday";
            this.navBarItemBirthday.SmallImageIndex = 12;
            this.navBarItemBirthday.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemBirthday_LinkClicked);
            // 
            // navBarItemAbsent
            // 
            this.navBarItemAbsent.Caption = "������ ������";
            this.navBarItemAbsent.Name = "navBarItemAbsent";
            this.navBarItemAbsent.SmallImageIndex = 10;
            this.navBarItemAbsent.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemAbsent_LinkClicked);
            // 
            // navBarItemAbsentCount
            // 
            this.navBarItemAbsentCount.Caption = "��� ������";
            this.navBarItemAbsentCount.Name = "navBarItemAbsentCount";
            this.navBarItemAbsentCount.SmallImageIndex = 11;
            this.navBarItemAbsentCount.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemAbsentCount_LinkClicked);
            // 
            // navBarItemDatanet
            // 
            this.navBarItemDatanet.Caption = "��� �������";
            this.navBarItemDatanet.Name = "navBarItemDatanet";
            this.navBarItemDatanet.SmallImageIndex = 13;
            this.navBarItemDatanet.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemDatanet_LinkClicked);
            // 
            // navBarItemacc_sms
            // 
            this.navBarItemacc_sms.Caption = "��������";
            this.navBarItemacc_sms.Name = "navBarItemacc_sms";
            this.navBarItemacc_sms.SmallImageIndex = 14;
            this.navBarItemacc_sms.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemacc_sms_LinkClicked);
            // 
            // msmGroup
            // 
            this.msmGroup.Caption = "�������";
            this.msmGroup.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemContacts),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemGroups),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemTemplates),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemMessages)});
            this.msmGroup.LargeImageIndex = 0;
            this.msmGroup.Name = "msmGroup";
            // 
            // navBarItemContacts
            // 
            this.navBarItemContacts.Caption = "�������";
            this.navBarItemContacts.Name = "navBarItemContacts";
            this.navBarItemContacts.SmallImageIndex = 5;
            this.navBarItemContacts.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemContacts_LinkClicked);
            // 
            // navBarItemGroups
            // 
            this.navBarItemGroups.Caption = "���������";
            this.navBarItemGroups.Name = "navBarItemGroups";
            this.navBarItemGroups.SmallImageIndex = 6;
            this.navBarItemGroups.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemGroups_LinkClicked);
            // 
            // navBarItemTemplates
            // 
            this.navBarItemTemplates.Caption = "����� �����";
            this.navBarItemTemplates.Name = "navBarItemTemplates";
            this.navBarItemTemplates.SmallImageIndex = 2;
            this.navBarItemTemplates.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemTemplates_LinkClicked);
            // 
            // navBarItemMessages
            // 
            this.navBarItemMessages.Caption = "�������";
            this.navBarItemMessages.Name = "navBarItemMessages";
            this.navBarItemMessages.SmallImageIndex = 4;
            this.navBarItemMessages.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemMessages_LinkClicked);
            // 
            // AdminGroup
            // 
            this.AdminGroup.Caption = "������";
            this.AdminGroup.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemUsers),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemSetting),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarIteme_schoolDB),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemStyles)});
            this.AdminGroup.LargeImageIndex = 1;
            this.AdminGroup.Name = "AdminGroup";
            // 
            // navBarItemUsers
            // 
            this.navBarItemUsers.Caption = "����������";
            this.navBarItemUsers.Name = "navBarItemUsers";
            this.navBarItemUsers.SmallImageIndex = 3;
            this.navBarItemUsers.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemUsers_LinkClicked);
            // 
            // navBarItemSetting
            // 
            this.navBarItemSetting.Caption = "����� ����� ������";
            this.navBarItemSetting.Name = "navBarItemSetting";
            this.navBarItemSetting.SmallImageIndex = 1;
            this.navBarItemSetting.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemSetting_LinkClicked);
            // 
            // navBarIteme_schoolDB
            // 
            this.navBarIteme_schoolDB.Caption = "������ ����� ��������";
            this.navBarIteme_schoolDB.Name = "navBarIteme_schoolDB";
            this.navBarIteme_schoolDB.SmallImageIndex = 8;
            this.navBarIteme_schoolDB.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarIteme_schoolDB_LinkClicked);
            // 
            // navBarItemStyles
            // 
            this.navBarItemStyles.Caption = "����� ��������";
            this.navBarItemStyles.Name = "navBarItemStyles";
            this.navBarItemStyles.SmallImageIndex = 7;
            this.navBarItemStyles.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemStyles_LinkClicked);
            // 
            // navbarImageListLarge
            // 
            this.navbarImageListLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("navbarImageListLarge.ImageStream")));
            this.navbarImageListLarge.TransparentColor = System.Drawing.Color.Transparent;
            this.navbarImageListLarge.Images.SetKeyName(0, "Mail_32x32.png");
            this.navbarImageListLarge.Images.SetKeyName(1, "Organizer_32x32.png");
            this.navbarImageListLarge.Images.SetKeyName(2, "connect.png");
            this.navbarImageListLarge.Images.SetKeyName(3, "disconnect.png");
            this.navbarImageListLarge.Images.SetKeyName(4, "ports.png");
            this.navbarImageListLarge.Images.SetKeyName(5, "ServiceNo.png");
            this.navbarImageListLarge.Images.SetKeyName(6, "Send.png");
            this.navbarImageListLarge.Images.SetKeyName(7, "SaveMsg.png");
            this.navbarImageListLarge.Images.SetKeyName(8, "dataschool.gif");
            // 
            // navbarImageList
            // 
            this.navbarImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("navbarImageList.ImageStream")));
            this.navbarImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.navbarImageList.Images.SetKeyName(0, "delete.png");
            this.navbarImageList.Images.SetKeyName(1, "setting.ico");
            this.navbarImageList.Images.SetKeyName(2, "Templates.ico");
            this.navbarImageList.Images.SetKeyName(3, "User.ico");
            this.navbarImageList.Images.SetKeyName(4, "Send.png");
            this.navbarImageList.Images.SetKeyName(5, "Contacts.ico");
            this.navbarImageList.Images.SetKeyName(6, "Groups.ico");
            this.navbarImageList.Images.SetKeyName(7, "styles.ico");
            this.navbarImageList.Images.SetKeyName(8, "e_schoolDB.png");
            this.navbarImageList.Images.SetKeyName(9, "dataschool.gif");
            this.navbarImageList.Images.SetKeyName(10, "Absent.png");
            this.navbarImageList.Images.SetKeyName(11, "AbsentCount.png");
            this.navbarImageList.Images.SetKeyName(12, "birthday.png");
            this.navbarImageList.Images.SetKeyName(13, "Datanet.png");
            this.navbarImageList.Images.SetKeyName(14, "acc_sms.png");
            this.navbarImageList.Images.SetKeyName(15, "malafatSms.png");
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.Options.UseTextOptions = true;
            this.groupControl1.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupControl1.Controls.Add(this.BtnDisconnect);
            this.groupControl1.Controls.Add(this.PnlConnection);
            this.groupControl1.Controls.Add(this.LblMsg);
            this.groupControl1.Controls.Add(this.PnlSend);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl1.Location = new System.Drawing.Point(0, 0);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(727, 244);
            this.groupControl1.TabIndex = 1;
            this.groupControl1.Text = "�������";
            // 
            // BtnDisconnect
            // 
            this.BtnDisconnect.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnDisconnect.ImageIndex = 3;
            this.BtnDisconnect.ImageList = this.navbarImageListLarge;
            this.BtnDisconnect.Location = new System.Drawing.Point(483, 160);
            this.BtnDisconnect.Name = "BtnDisconnect";
            this.BtnDisconnect.Size = new System.Drawing.Size(157, 33);
            this.BtnDisconnect.TabIndex = 1;
            this.BtnDisconnect.Text = "��� �������";
            this.BtnDisconnect.Visible = false;
            this.BtnDisconnect.Click += new System.EventHandler(this.BtnDisconnect_Click);
            // 
            // PnlConnection
            // 
            this.PnlConnection.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PnlConnection.Controls.Add(this.TxtServiceNum);
            this.PnlConnection.Controls.Add(this.BtnConnect);
            this.PnlConnection.Controls.Add(this.labelControl2);
            this.PnlConnection.Controls.Add(this.labelControl1);
            this.PnlConnection.Controls.Add(this.CBEPort);
            this.PnlConnection.Controls.Add(this.PBSignal);
            this.PnlConnection.Location = new System.Drawing.Point(424, 24);
            this.PnlConnection.Name = "PnlConnection";
            this.PnlConnection.Size = new System.Drawing.Size(298, 130);
            this.PnlConnection.TabIndex = 0;
            // 
            // TxtServiceNum
            // 
            this.TxtServiceNum.Location = new System.Drawing.Point(59, 64);
            this.TxtServiceNum.Name = "TxtServiceNum";
            this.TxtServiceNum.Size = new System.Drawing.Size(157, 19);
            this.TxtServiceNum.TabIndex = 1;
            // 
            // BtnConnect
            // 
            this.BtnConnect.ImageIndex = 2;
            this.BtnConnect.ImageList = this.navbarImageListLarge;
            this.BtnConnect.Location = new System.Drawing.Point(59, 89);
            this.BtnConnect.Name = "BtnConnect";
            this.BtnConnect.Size = new System.Drawing.Size(157, 33);
            this.BtnConnect.TabIndex = 2;
            this.BtnConnect.Text = "�����";
            this.BtnConnect.Click += new System.EventHandler(this.BtnConnect_Click);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ImageIndex = 5;
            this.labelControl2.Appearance.ImageList = this.navbarImageListLarge;
            this.labelControl2.ImageAlignToText = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            this.labelControl2.Location = new System.Drawing.Point(222, 56);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(37, 36);
            this.labelControl2.TabIndex = 2;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ImageIndex = 4;
            this.labelControl1.Appearance.ImageList = this.navbarImageListLarge;
            this.labelControl1.ImageAlignToText = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            this.labelControl1.Location = new System.Drawing.Point(222, 14);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(37, 36);
            this.labelControl1.TabIndex = 2;
            // 
            // CBEPort
            // 
            this.CBEPort.Location = new System.Drawing.Point(59, 22);
            this.CBEPort.Name = "CBEPort";
            this.CBEPort.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.CBEPort.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.CBEPort.Size = new System.Drawing.Size(157, 19);
            this.CBEPort.TabIndex = 0;
            // 
            // PBSignal
            // 
            this.PBSignal.Dock = System.Windows.Forms.DockStyle.Left;
            this.PBSignal.Location = new System.Drawing.Point(2, 2);
            this.PBSignal.Name = "PBSignal";
            this.PBSignal.Properties.Maximum = 31;
            this.PBSignal.Properties.NullText = "������";
            this.PBSignal.Properties.ProgressKind = DevExpress.XtraEditors.Controls.ProgressKind.Vertical;
            this.PBSignal.Properties.ShowTitle = true;
            this.PBSignal.Properties.Step = 1;
            this.PBSignal.Size = new System.Drawing.Size(28, 126);
            this.PBSignal.TabIndex = 5;
            // 
            // LblMsg
            // 
            this.LblMsg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LblMsg.Appearance.Font = new System.Drawing.Font("Tahoma", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.LblMsg.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.LblMsg.Location = new System.Drawing.Point(10, 226);
            this.LblMsg.Name = "LblMsg";
            this.LblMsg.Size = new System.Drawing.Size(51, 13);
            this.LblMsg.TabIndex = 4;
            this.LblMsg.Text = "��� ����";
            this.LblMsg.DoubleClick += new System.EventHandler(this.LblMsg_DoubleClick);
            // 
            // PnlSend
            // 
            this.PnlSend.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PnlSend.Controls.Add(this.BtnDelSendTo);
            this.PnlSend.Controls.Add(this.PBSend);
            this.PnlSend.Controls.Add(this.LblMsgCounter);
            this.PnlSend.Controls.Add(this.LblCharCounter);
            this.PnlSend.Controls.Add(this.BtnSaveMsg);
            this.PnlSend.Controls.Add(this.CBAddVar);
            this.PnlSend.Controls.Add(this.btnSend);
            this.PnlSend.Controls.Add(this.LBCSendTo);
            this.PnlSend.Controls.Add(this.TxtMsg);
            this.PnlSend.Enabled = false;
            this.PnlSend.Location = new System.Drawing.Point(10, 24);
            this.PnlSend.Name = "PnlSend";
            this.PnlSend.Size = new System.Drawing.Size(409, 196);
            this.PnlSend.TabIndex = 2;
            // 
            // BtnDelSendTo
            // 
            this.BtnDelSendTo.DropDownControl = this.popupMenuDeleteBtn;
            this.BtnDelSendTo.ImageIndex = 0;
            this.BtnDelSendTo.ImageList = this.navbarImageList;
            this.BtnDelSendTo.Location = new System.Drawing.Point(255, 121);
            this.BtnDelSendTo.Name = "BtnDelSendTo";
            this.BtnDelSendTo.Size = new System.Drawing.Size(149, 23);
            this.BtnDelSendTo.TabIndex = 5;
            this.BtnDelSendTo.Text = "���";
            this.BtnDelSendTo.Click += new System.EventHandler(this.BtnDelSendTo_Click);
            // 
            // popupMenuDeleteBtn
            // 
            this.popupMenuDeleteBtn.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItemDelAll)});
            this.popupMenuDeleteBtn.Manager = this.barManagerMain;
            this.popupMenuDeleteBtn.Name = "popupMenuDeleteBtn";
            // 
            // barButtonItemDelAll
            // 
            this.barButtonItemDelAll.Caption = "��� ����";
            this.barButtonItemDelAll.Id = 1;
            this.barButtonItemDelAll.ImageIndex = 0;
            this.barButtonItemDelAll.Name = "barButtonItemDelAll";
            this.barButtonItemDelAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemDelAll_ItemClick);
            // 
            // barManagerMain
            // 
            this.barManagerMain.DockControls.Add(this.barDockControlTop);
            this.barManagerMain.DockControls.Add(this.barDockControlBottom);
            this.barManagerMain.DockControls.Add(this.barDockControlLeft);
            this.barManagerMain.DockControls.Add(this.barDockControlRight);
            this.barManagerMain.Form = this;
            this.barManagerMain.Images = this.navbarImageList;
            this.barManagerMain.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItemDelAll});
            this.barManagerMain.MaxItemId = 2;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(909, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 612);
            this.barDockControlBottom.Size = new System.Drawing.Size(909, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 612);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(909, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 612);
            // 
            // PBSend
            // 
            this.PBSend.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PBSend.Location = new System.Drawing.Point(2, 179);
            this.PBSend.Name = "PBSend";
            this.PBSend.Properties.ShowTitle = true;
            this.PBSend.Properties.Step = 1;
            this.PBSend.Size = new System.Drawing.Size(405, 15);
            this.PBSend.TabIndex = 6;
            // 
            // LblMsgCounter
            // 
            this.LblMsgCounter.AutoSize = true;
            this.LblMsgCounter.Location = new System.Drawing.Point(5, 163);
            this.LblMsgCounter.Name = "LblMsgCounter";
            this.LblMsgCounter.Size = new System.Drawing.Size(13, 13);
            this.LblMsgCounter.TabIndex = 5;
            this.LblMsgCounter.Text = "0";
            // 
            // LblCharCounter
            // 
            this.LblCharCounter.AutoSize = true;
            this.LblCharCounter.Location = new System.Drawing.Point(120, 163);
            this.LblCharCounter.Name = "LblCharCounter";
            this.LblCharCounter.Size = new System.Drawing.Size(13, 13);
            this.LblCharCounter.TabIndex = 5;
            this.LblCharCounter.Text = "0";
            // 
            // BtnSaveMsg
            // 
            this.BtnSaveMsg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnSaveMsg.ImageIndex = 7;
            this.BtnSaveMsg.ImageList = this.navbarImageListLarge;
            this.BtnSaveMsg.Location = new System.Drawing.Point(183, 121);
            this.BtnSaveMsg.Name = "BtnSaveMsg";
            this.BtnSaveMsg.Size = new System.Drawing.Size(66, 38);
            this.BtnSaveMsg.TabIndex = 4;
            this.BtnSaveMsg.Text = "���";
            this.BtnSaveMsg.Click += new System.EventHandler(this.BtnSaveMsg_Click);
            // 
            // CBAddVar
            // 
            this.CBAddVar.Location = new System.Drawing.Point(5, 5);
            this.CBAddVar.Name = "CBAddVar";
            this.CBAddVar.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.CBAddVar.Properties.Items.AddRange(new object[] {
            "[�����]",
            "[��� ����]",
            "[��� ������]"});
            this.CBAddVar.Properties.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.CBAddVar_Properties_ButtonClick);
            this.CBAddVar.Size = new System.Drawing.Size(245, 19);
            this.CBAddVar.TabIndex = 0;
            // 
            // btnSend
            // 
            this.btnSend.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSend.ImageIndex = 6;
            this.btnSend.ImageList = this.navbarImageListLarge;
            this.btnSend.Location = new System.Drawing.Point(5, 121);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(175, 38);
            this.btnSend.TabIndex = 3;
            this.btnSend.Text = "�����";
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // LBCSendTo
            // 
            this.LBCSendTo.Appearance.Options.UseTextOptions = true;
            this.LBCSendTo.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.LBCSendTo.Location = new System.Drawing.Point(255, 28);
            this.LBCSendTo.Name = "LBCSendTo";
            this.LBCSendTo.Size = new System.Drawing.Size(150, 87);
            this.LBCSendTo.TabIndex = 2;
            // 
            // TxtMsg
            // 
            this.TxtMsg.Location = new System.Drawing.Point(5, 28);
            this.TxtMsg.Name = "TxtMsg";
            this.TxtMsg.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TxtMsg.Size = new System.Drawing.Size(245, 87);
            this.TxtMsg.TabIndex = 1;
            this.TxtMsg.EditValueChanged += new System.EventHandler(this.TxtMsg_EditValueChanged);
            // 
            // USBserialPort
            // 
            this.USBserialPort.ReadTimeout = 1000;
            this.USBserialPort.WriteTimeout = 1000;
            this.USBserialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.USBserialPort_DataReceived);
            // 
            // TmrSignal
            // 
            this.TmrSignal.Interval = 2000;
            this.TmrSignal.Tick += new System.EventHandler(this.TmrSignal_Tick);
            // 
            // gridViewmalafatSms
            // 
            this.gridViewmalafatSms.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn25,
            this.gridColumn26,
            this.gridColumn27,
            this.gridColumn28,
            this.gridColumn29});
            this.gridViewmalafatSms.GridControl = this.gridControlMain;
            this.gridViewmalafatSms.Name = "gridViewmalafatSms";
            this.gridViewmalafatSms.OptionsView.ColumnAutoWidth = false;
            this.gridViewmalafatSms.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.ShowAlways;
            this.gridViewmalafatSms.OptionsView.ShowFooter = true;
            // 
            // gridColumn25
            // 
            this.gridColumn25.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn25.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn25.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn25.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn25.Caption = "��� ������";
            this.gridColumn25.FieldName = "empname";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 0;
            this.gridColumn25.Width = 211;
            // 
            // gridColumn26
            // 
            this.gridColumn26.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn26.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn26.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn26.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn26.Caption = "�������";
            this.gridColumn26.FieldName = "job";
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.Visible = true;
            this.gridColumn26.VisibleIndex = 1;
            this.gridColumn26.Width = 126;
            // 
            // gridColumn27
            // 
            this.gridColumn27.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn27.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn27.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn27.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn27.Caption = "������";
            this.gridColumn27.FieldName = "mada";
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.Visible = true;
            this.gridColumn27.VisibleIndex = 2;
            this.gridColumn27.Width = 93;
            // 
            // gridColumn28
            // 
            this.gridColumn28.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn28.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn28.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn28.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn28.Caption = "�������";
            this.gridColumn28.FieldName = "mobil";
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.Visible = true;
            this.gridColumn28.VisibleIndex = 3;
            this.gridColumn28.Width = 81;
            // 
            // gridColumn29
            // 
            this.gridColumn29.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn29.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn29.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn29.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn29.Caption = "�������";
            this.gridColumn29.ColumnEdit = this.repositoryItemCheckEditstu_code;
            this.gridColumn29.FieldName = "checked";
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 4;
            this.gridColumn29.Width = 86;
            // 
            // navBarItemmalafatSms
            // 
            this.navBarItemmalafatSms.Caption = "��������";
            this.navBarItemmalafatSms.Name = "navBarItemmalafatSms";
            this.navBarItemmalafatSms.SmallImageIndex = 15;
            this.navBarItemmalafatSms.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemmalafatSms_LinkClicked);
            // 
            // MainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 612);
            this.Controls.Add(this.splitContainerControl);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "School Messages";
            this.Load += new System.EventHandler(this.MainFrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingDel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMain)).EndInit();
            this.CMSdataschool.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTemplates)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewContacts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditGroupName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewSkinStyle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnSkinStyle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewLogDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardViewe_schoolDB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditStu_DB_Path)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditResult_DB_Path)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditacc_sms_DB_Path)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditmalafatSms_DB_Path)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewdataschool)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEditstu_code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDatanet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEditperm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewacc_sms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSetting)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl)).EndInit();
            this.splitContainerControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PnlConnection)).EndInit();
            this.PnlConnection.ResumeLayout(false);
            this.PnlConnection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtServiceNum.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CBEPort.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSignal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PnlSend)).EndInit();
            this.PnlSend.ResumeLayout(false);
            this.PnlSend.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuDeleteBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManagerMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSend.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CBAddVar.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LBCSendTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMsg.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewmalafatSms)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl;
        private DevExpress.XtraGrid.GridControl gridControlMain;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewGroups;
        private DevExpress.XtraNavBar.NavBarControl navBarControl;
        private DevExpress.XtraNavBar.NavBarGroup msmGroup;
        private DevExpress.XtraNavBar.NavBarGroup AdminGroup;
        private System.Windows.Forms.ImageList navbarImageList;
        private System.Windows.Forms.ImageList navbarImageListLarge;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.PanelControl PnlSend;
        private DevExpress.XtraEditors.MemoEdit TxtMsg;
        private DevExpress.XtraEditors.ListBoxControl LBCSendTo;
        private DevExpress.XtraEditors.PanelControl PnlConnection;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.ComboBoxEdit CBEPort;
        private DevExpress.XtraEditors.SimpleButton BtnConnect;
        private DevExpress.XtraEditors.SimpleButton BtnDisconnect;
        public DevExpress.XtraEditors.LabelControl LblMsg;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewMessages;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewContacts;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewTemplates;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewUsers;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewSetting;
        private DevExpress.XtraEditors.TextEdit TxtServiceNum;
        private DevExpress.XtraGrid.Columns.GridColumn GCServiceNum;
        private DevExpress.XtraGrid.Columns.GridColumn GCSettingUse;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSettingUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCSettingDel;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSettingDel;
        private DevExpress.XtraEditors.SimpleButton btnSend;
        private System.IO.Ports.SerialPort USBserialPort;
        private DevExpress.XtraNavBar.NavBarItem navBarItemUsers;
        private DevExpress.XtraNavBar.NavBarItem navBarItemTemplates;
        private DevExpress.XtraNavBar.NavBarItem navBarItemSetting;
        private DevExpress.XtraNavBar.NavBarItem navBarItemMessages;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupsGroupName;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesnumber;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesmessageBody;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesstatus;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesSendTime;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEditDate;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsContactName;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsContactNumber;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsDel;
        private DevExpress.XtraNavBar.NavBarItem navBarItemGroups;
        private DevExpress.XtraNavBar.NavBarItem navBarItemContacts;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupsSave;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessageSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCSettingSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateTemplateBody;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersUserName;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersPassWord;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsGroupID;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditGroupName;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupName;
        private DevExpress.XtraGrid.Views.Layout.LayoutView layoutViewSkinStyle;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumnSkinStyle;
        
        private DevExpress.XtraNavBar.NavBarItem navBarItemStyles;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumnUse;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumnSkinStyle;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumnUse;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewCard layoutViewCard1;
        private DevExpress.XtraEditors.ProgressBarControl PBSignal;
        private System.Windows.Forms.Timer TmrSignal;
        private System.Windows.Forms.Label LblCharCounter;
        private System.Windows.Forms.Label LblMsgCounter;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewLogDetails;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.ProgressBarControl PBSend;
        private DevExpress.XtraEditors.SimpleButton BtnSaveMsg;
        private DevExpress.XtraEditors.ComboBoxEdit CBAddVar;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditStu_DB_Path;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditResult_DB_Path;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Views.Card.CardView cardViewe_schoolDB;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewdataschool;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn GCstu_codeCheckBox;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEditstu_code;
        private DevExpress.XtraNavBar.NavBarItem navBarIteme_schoolDB;
        private DevExpress.XtraNavBar.NavBarItem navBarItemdataschool;
        private System.Windows.Forms.ContextMenuStrip CMSdataschool;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemSelectAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAdd;
        private DevExpress.XtraEditors.DropDownButton BtnDelSendTo;
        private DevExpress.XtraBars.PopupMenu popupMenuDeleteBtn;
        private DevExpress.XtraBars.BarManager barManagerMain;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraBars.BarButtonItem barButtonItemDelAll;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroupStudent;
        private DevExpress.XtraNavBar.NavBarItem navBarItemAbsent;
        private DevExpress.XtraNavBar.NavBarItem navBarItemAbsentCount;
        private DevExpress.XtraGrid.Columns.GridColumn GCstu_Dayz;
        private DevExpress.XtraGrid.Columns.GridColumn GCstu_BirthDay;
        private DevExpress.XtraGrid.Columns.GridColumn GCstu_age;
        private DevExpress.XtraGrid.Columns.GridColumn GCstu_eyab_date_from;
        private DevExpress.XtraNavBar.NavBarItem navBarItemBirthday;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDatanet;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraNavBar.NavBarItem navBarItemDatanet;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEditperm;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditacc_sms_DB_Path;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditmalafatSms_DB_Path;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewacc_sms;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraNavBar.NavBarItem navBarItemacc_sms;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewmalafatSms;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private DevExpress.XtraNavBar.NavBarItem navBarItemmalafatSms;

    }
}
